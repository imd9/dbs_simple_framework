# iDEE for Databricks — What We Accomplished

**Framework version:** 0.1.0 · **Config schema version:** 0.1
**Status:** working end to end in the Databricks workspace
**Prepared for:** review with Ojoma Ali, ahead of any demo to Rashid

---

## 1. Executive summary

We built a working metadata-driven ELT framework skeleton for Databricks and
proved it end to end.

A data engineer onboards a dataset by filling out **one YAML file**. The
framework validates it against a versioned schema, parses it into metadata
actions, and loads those into Unity Catalog. No new pipeline, no new notebook,
no code change.

The guidance was to stop building disconnected pieces and deliver one complete
unit of work. That is what this is: a small, finished, tested path — not a
half-built collection of parts.

**Deliberately in scope:** config → validate → parse → load metadata.
**Deliberately not in scope:** the ingestion engine that moves Bronze/Silver
data, asset bundles, CI/CD. Those are the next increments, and we say so
plainly rather than implying more than we built.

---

## 2. What was asked for, and what was delivered

Every item below traces to a specific instruction from the sync meeting.

### 2.1 Structure and hygiene

| Asked for | Delivered | Status |
|---|---|---|
| Clean the working folders; remove unrelated/experimental files | Removed the broken `databricks.yml`, its duplicate template, five overlapping guides, and `dry_run_test.py` | ✅ |
| Rename folders using DBX-oriented names to avoid conflict with existing iDEE names | `idee_dbx_framework` and `idee_dbx_app` | ✅ |
| Create a parent folder for both | `idee_for_databricks/` | ✅ |
| Create the application folder | `idee_dbx_app/` with `config/`, `ddl/`, `data/`, `notebooks/`, `output/` | ✅ |
| Consistent folder naming, file naming, casing, terminology from the beginning | `docs/NAMING_CONVENTIONS.md` — a written standard, applied throughout | ✅ |
| No vague names (`lightweight`, `root`, `dry run test`, mixed styles) | All removed. Every file name states what it is | ✅ |

### 2.2 Framework and application separation

The instruction was that the framework owns reusable logic and the application
folder owns one team's artifacts. Concretely:

| Artifact | Asked to live in | Where it is | Status |
|---|---|---|---|
| YAML template | Framework, under a templates folder | `idee_dbx_framework/templates/idee_pipeline_config_template.yaml` | ✅ |
| Filled config (no longer a template) | Application folder | `idee_dbx_app/config/customer_full_refresh_config.yaml` | ✅ |
| Config parsing | Framework, not application | `idee_dbx_framework/src/idee_dbx/config_parser.py` | ✅ |
| Application DDL (app/story specific) | Application folder | `idee_dbx_app/ddl/` — bronze, silver, quarantine | ✅ |
| Metadata DDL (framework-owned, run at setup) | Framework setup | `idee_dbx_framework/ddl/metadata/` — five tables | ✅ |
| Sample data | Application folder | `idee_dbx_app/data/` | ✅ |
| Unit tests, primarily for framework code | Framework | `idee_dbx_framework/tests/` | ✅ |

**The DDL split is deliberate and follows the guidance directly.** Application
DDL is Jira-story specific and belongs to the team that requested it. Metadata
DDL is framework-owned: every application team that adopts this framework gets
the same five metadata tables, and no application team should be defining them.

### 2.3 The validator and the parser

Two distinct framework components, as specified:

| Component | Question it answers | File |
|---|---|---|
| **Config validator** | Is this filled config legal? Does it match the expected schema and version? | `src/idee_dbx/config_validator.py` |
| **Config parser** | What metadata actions does a valid config produce? | `src/idee_dbx/config_parser.py` |
| Metadata loader | Apply those actions to Unity Catalog | `src/idee_dbx/metadata_loader.py` |
| Orchestrator / main command | One entry point that runs the stages in order | `src/idee_dbx/main.py` |

They are kept separate on purpose. Parsing produces a plan without executing it,
which is what makes a meaningful dry run possible — you see exactly what would
be written before anything is.

### 2.4 The minimal demo path

The requested demo sequence, and where each step is satisfied:

| # | Asked for | Delivered |
|---|---|---|
| 1 | A filled sample YAML config for one simple pipeline | `customer_full_refresh_config.yaml` |
| 2 | Run the framework validator against it | `validate_config_file()` / `main.py validate` |
| 3 | Validator confirms it matches the expected schema and version | Reports `Version: 0.1`, `Schema: v0.1`, `Result: PASSED` |
| 4 | Run the framework parser against the validated config | `parse_config()` / `main.py parse` |
| 5 | Parser produces metadata / insert-DML output for the target tables | Renders `MERGE` statements; `--show-sql` prints them |
| 6 | Show clear log/status messages | Every message below is emitted verbatim |
| 7 | Optionally load the metadata tables after DDL exists | `main.py load`, with `--dry-run` |
| 8 | Demo from a Databricks notebook calling the framework against the YAML | `notebooks/run_config_pipeline.py`, `notebooks/iDEE Framework End to End Validation.py` |

The requested status messages, as emitted:

```
Loading started...
Version     : 0.1
Config schema validation passed.
Parser completed. Metadata action list generated.
Load complete.
```

### 2.5 The sample pipeline was kept small, as instructed

| Requirement | Delivered |
|---|---|
| One source | 1 — cloud files, CSV |
| One target | Bronze + Silver for a single dataset |
| About five columns | Exactly 5 |
| Full refresh / truncate-and-load | `load_type: FULL` |

No incremental, no append, no CDC in the first unit — those come after this path
is signed off.

---

## 3. What we delivered beyond the ask

These were not requested. They were added because they materially reduce risk.

### 3.1 Config schema versioning, made real

An open question from the meeting was where the config version lives and how the
schema is versioned. Our answer:

- Every config declares `config_version: "0.1"`.
- The validator loads the matching `schema/pipeline_config_schema_v0_1.yaml`.
- **Validation rules are data, not code.** Adding a new config format means
  adding a schema file, not editing Python.
- Published schema files are never edited in place. Configs already deployed keep
  validating against the version they declare.

Framework version (`0.1.0`) and config schema version (`0.1`) move independently
and are documented in `docs/CHANGELOG.md`.

### 3.2 Idempotency

The parser emits `MERGE`, not `INSERT`, and derives deterministic rule IDs
(`<object_id>__<slug>`) rather than random UUIDs.

**Consequence: running the same config twice produces identical row counts.** A
framework using `INSERT` or UUIDs would silently double its metadata on a
re-run — a failure mode that stays invisible until someone audits the tables.
This matters more once configs enter CI/CD, where re-runs are routine.

### 3.3 The unfilled-template guard

Writing the tests exposed a real defect: **the blank template passed
validation.** Every placeholder in it (`"enter source code here"`,
`"catalog.schema.table"`) is syntactically legal, so nothing rejected it.
Someone could have deployed an unfilled template and the framework would have
accepted it.

Fixed by adding placeholder detection to the schema, plus a test asserting the
template must fail validation. This is a concrete example of unit tests paying
for themselves before the framework left the workspace.

### 3.4 The framework never creates schemas

`idee_metaschema` and `idee_app` are provisioned by the platform team.
`00_verify_prerequisites.sql` **verifies they exist and creates nothing.**

If someone mistypes a schema name, the framework stops with a clear message
rather than silently creating a second schema and scattering tables across two
places. Failing loudly beats a silent partial success.

### 3.5 Nothing is hardcoded

Catalog and schema are parameters in every layer — SQL uses `${catalog}` /
`${metadata_schema}`, Python takes them as arguments, notebooks expose them as
widgets. The same artifact promotes across dev, QA, and prod unchanged, which is
what makes the eventual asset-bundle work straightforward rather than a
copy-and-modify exercise.

### 3.6 Two role-specific guides

- `idee_dbx_framework/docs/TESTING_GUIDE.md` — framework engineer: running
  PyTest inside Databricks (including the workspace-storage gotchas), installing
  the metadata DDL, and a demo script.
- `idee_dbx_app/docs/DEMO_GUIDE.md` — data engineer: filling out a config,
  validating, loading, troubleshooting.

### 3.7 Sample data that actually fails

`customer_sample.csv` contains three planted defects — a malformed email, a
three-character country code, and untrimmed whitespace. A demo where everything
passes proves nothing; this one lets the quality rules visibly do something.

---

## 4. Quality engineering evidence

| Measure | Result |
|---|---|
| Unit tests | **95**, covering the validator and parser |
| Test fixtures | 4 — one valid, three invalid (missing fields, bad enums, unsupported version) |
| Python modules | 4, each with a single responsibility |
| Metadata tables | 5 (4 config + 1 runtime audit) |
| Hardcoded catalog/schema references | 0 |
| Written standards | Naming conventions, changelog, versioning policy |

What the suite actually checks — worth stating, because "the tests pass" means
little without it:

- A correct config passes; the shipped demo config passes
- `config_version` is required; unknown versions are rejected
- Every required field is enforced; blank strings count as missing
- Types are enforced — including that `bool` is **not** accepted as `int`
  (in Python `True` genuinely is an `int`, so a naive check would let
  `sequence: true` through)
- Illegal enum values are rejected
- `INCREMENTAL` demands a watermark column; `CDC`/`SNAPSHOT` demand a key; each
  DQ engine demands its own field
- Cross-field integrity: `source_id` must match, column names and sequences must
  be unique, table names must be three-part
- Missing, empty, and malformed files fail cleanly
- The blank template does not validate
- MERGE statements are ordered parent-before-child, quote-escaped, and
  catalog-parameterised
- Anything the validator accepts, the parser can handle

---

## 5. Scope — stated plainly

**What v0.1 does:** loads *metadata* about a pipeline.

**What v0.1 does not do:** move data. There is no ingestion engine yet. Bronze
and Silver movement is the next increment.

This boundary is intentional and worth naming out loud in any demo. Proving the
config path end to end before building on top of it is the whole point of
working in small complete units. Claiming more than was built is the fastest way
to lose credibility in a review; naming the boundary is what makes the rest
believable.

Also deferred, and why:

| Deferred | Reason |
|---|---|
| Databricks asset bundles, CI/CD | Waiting on Bitbucket repos and AD groups |
| Data quality runtime enforcement | Needs the ingestion engine first. All three DQ engines validate and parse correctly; nothing executes rules against data yet |
| Append, incremental, CDC runtime | Full refresh proven first |
| Migration tracking table | Later stage |
| Gold layer modelling | After Silver works |

The folder structure is deliberately repo-shaped, so moving into Bitbucket is a
copy rather than a redesign.

---

## 6. Next increment

In priority order:

1. **Bronze ingestion engine** — Auto Loader driven by `object_config`, full
   refresh only.
2. **Silver transformation engine** — rename, cast, trim, driven by
   `column_config`.
3. **`pipeline_audit` writes at run time** — the table exists; nothing populates
   it yet.
4. **DQ runtime enforcement** — execute the rules the config already describes.
5. **Append, then incremental/CDC.**
6. **Asset bundles and CI/CD**, once repos and AD groups exist.

Two people can work in parallel from here: one evolves the ingestion scenarios,
the other picks up data quality or asset bundles.

---

## 7. Open questions for review

Carried forward from the meeting and still worth confirming:

1. **Parser output form.** Should the parser emit insert statements, structured
   objects, or write directly to the metadata tables? We built all three paths —
   `parse` returns a plan object, `--show-sql` prints the DML, and `load` writes.
   Worth confirming which is the intended default.
2. **Metadata tables for the first parser output.** We implemented four config
   tables plus one audit table. Confirm this is the agreed set before the
   ingestion engine is built on top of it.
3. **PyTest coverage expectations** once SonarQube is introduced.
4. **Demo timing** — this review before any formal demo to Rashid.

---

## 8. Known issue in the current package

`idee_dbx_app/config/test_customers_config.yaml` does not parse. Line 37 begins
with `--- ALTERNATIVE SOURCE: ...`, and a bare `---` is a YAML document
separator, so the parser sees two documents in one file.

The validator catches it cleanly and reports a parse error, so nothing is
silently wrong — but that config cannot run until fixed. The same file also has
`dataset.source_id` set to `src_sharepoint_customer_files` while the active
source block declares `src_s3_customer_files`; the validator's integrity check
would flag that once the parse error is resolved.

A corrected copy is supplied alongside this document. The fix is to comment the
separator line with `#` and align the two `source_id` values.
