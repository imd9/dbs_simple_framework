-- =============================================================================
-- 01_create_bronze_customer.sql
-- =============================================================================
-- Bronze target for the customer demo pipeline.
--
-- OWNER      : Application team. This is app-specific, not framework code.
-- SCHEMA     : ${catalog}.${app_schema}   (business data, NOT the metadata schema)
-- LAYER      : Bronze — raw ingest, source fidelity, everything as STRING
--
-- Bronze keeps source column names and STRING types on purpose: casting and
-- renaming happen on the way to Silver, driven by column_config.
-- =============================================================================

-- The ddl scripts should explictly state that feilds cannot be NULL!!!

CREATE TABLE IF NOT EXISTS medtech_md_scion_dev.idee_app.bronze_customer (
    CUSTOMER_ID          STRING    COMMENT 'Raw source value, uncast.',
    CUSTOMER_NAME        STRING    COMMENT 'Raw source value, uncast.',
    EMAIL_ADDRESS        STRING    COMMENT 'Raw source value, uncast.',
    COUNTRY_CODE         STRING    COMMENT 'Raw source value, uncast.',
    CREATED_DATE         STRING    COMMENT 'Raw source value, uncast.',
    _ingest_file_name    STRING    COMMENT 'Source file this row came from.',
    _ingest_timestamp    TIMESTAMP COMMENT 'When the row was ingested.',
    _run_id              STRING    COMMENT 'Pipeline run that produced the row.'
)
USING DELTA
COMMENT 'Bronze: raw customer extracts. Demo pipeline.'
TBLPROPERTIES (
    'idee.table_role' = 'bronze',
    'idee.object_id'  = 'obj_customer',
    'idee.owner'      = 'application'
);
