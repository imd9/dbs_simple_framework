-- =============================================================================
-- 02_create_silver_customer.sql
-- =============================================================================
-- Silver target for the customer demo pipeline.
--
-- OWNER      : Application team.
-- SCHEMA     : ${catalog}.${app_schema}
-- LAYER      : Silver — renamed, cast, trimmed, quality-checked
--
-- Column names and types here mirror column_config for obj_customer. If you
-- change the config, change this DDL to match.
-- =============================================================================

CREATE TABLE IF NOT EXISTS medtech_md_scion_dev.idee_app.silver_customer (
    customer_id        BIGINT    NOT NULL COMMENT 'Business key.',
    customer_name      STRING             COMMENT 'Trimmed. Classified SENSITIVE.',
    email_address      STRING             COMMENT 'Trimmed. Classified PII.',
    country_code       STRING             COMMENT 'Two-character ISO country code.',
    created_date       TIMESTAMP          COMMENT 'Cast from source string.',
    _run_id            STRING             COMMENT 'Pipeline run that produced the row.',
    _processed_at      TIMESTAMP          COMMENT 'When the row was written to Silver.',
    CONSTRAINT pk_silver_customer PRIMARY KEY (customer_id) RELY
)
USING DELTA
COMMENT 'Silver: cleaned customer records. Demo pipeline.'
TBLPROPERTIES (
    'idee.table_role' = 'silver',
    'idee.object_id'  = 'obj_customer',
    'idee.owner'      = 'application'
);
