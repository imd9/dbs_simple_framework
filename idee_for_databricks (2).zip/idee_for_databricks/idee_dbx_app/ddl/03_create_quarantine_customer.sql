-- =============================================================================
-- 03_create_quarantine_customer.sql
-- =============================================================================
-- Quarantine target for rows failing a data quality rule whose action is
-- `quarantine`. Same shape as Silver plus the reason the row was rejected.
--
-- OWNER      : Application team.
-- SCHEMA     : ${catalog}.${app_schema}
-- =============================================================================

CREATE TABLE IF NOT EXISTS medtech_md_scion_dev.idee_app.quarantine_customer (
    customer_id          STRING    COMMENT 'Left as STRING: the value may be why the row failed.',
    customer_name        STRING    COMMENT 'Raw value.',
    email_address        STRING    COMMENT 'Raw value.',
    country_code         STRING    COMMENT 'Raw value.',
    created_date         STRING    COMMENT 'Raw value.',
    _run_id              STRING    COMMENT 'Pipeline run that rejected the row.',
    _quarantined_at      TIMESTAMP COMMENT 'When the row was quarantined.',
    _failed_rule_id      STRING    COMMENT 'FK to quality_rule_config.rule_id.',
    _failed_rule_name    STRING    COMMENT 'Rule name, denormalised for readability.',
    _failed_expression   STRING    COMMENT 'The boolean expression that returned FALSE.'
)
USING DELTA
COMMENT 'Quarantine: customer rows that failed data quality. Demo pipeline.'
TBLPROPERTIES (
    'idee.table_role' = 'quarantine',
    'idee.object_id'  = 'obj_customer',
    'idee.owner'      = 'application'
);
