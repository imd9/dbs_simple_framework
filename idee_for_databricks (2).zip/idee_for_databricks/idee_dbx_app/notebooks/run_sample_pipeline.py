# Databricks notebook source
# MAGIC %md
# MAGIC # Sample Pipeline — customer full refresh
# MAGIC
# MAGIC The application-side view: how a downstream team uses the framework.
# MAGIC
# MAGIC This notebook does **not** contain framework logic. It points the
# MAGIC framework at this team's filled config and reports what happened. All
# MAGIC reusable logic lives in `idee_dbx_framework/src/idee_dbx/`.

# COMMAND ----------

dbutils.widgets.text("catalog", "medtech_md_scion_dev", "1. Catalog")
dbutils.widgets.text("metadata_schema", "idee_metaschema", "2. Metadata schema")
dbutils.widgets.text("app_schema", "idee_app", "3. Application schema")
dbutils.widgets.dropdown("dry_run", "true", ["true", "false"], "4. Dry run")

CATALOG = dbutils.widgets.get("catalog")
METADATA_SCHEMA = dbutils.widgets.get("metadata_schema")
APP_SCHEMA = dbutils.widgets.get("app_schema")
DRY_RUN = dbutils.widgets.get("dry_run") == "true"

#CONFIG_PATH = "../config/customer_full_refresh_config.yaml"

CONFIG_PATH = "../config/test_customers_config.yaml"
# #insert appropite path for the yaml you want

# COMMAND ----------

import sys
from pathlib import Path

FRAMEWORK_SRC = (Path.cwd() / ".." / ".." / "idee_dbx_framework" / "src").resolve()
if str(FRAMEWORK_SRC) not in sys.path:
    sys.path.insert(0, str(FRAMEWORK_SRC))

from idee_dbx.config_parser import parse_config
from idee_dbx.config_validator import validate_config_file
from idee_dbx.metadata_loader import load_plan

# COMMAND ----------

# DBTITLE 1,Reset metadata tables
# %sql
# -- Drop and recreate metadata tables for a clean slate before each run
# DROP TABLE IF EXISTS medtech_md_scion_dev.idee_metaschema.source_config;
# DROP TABLE IF EXISTS medtech_md_scion_dev.idee_metaschema.object_config;
# DROP TABLE IF EXISTS medtech_md_scion_dev.idee_metaschema.column_config;
# DROP TABLE IF EXISTS medtech_md_scion_dev.idee_metaschema.quality_rule_config;
# DROP TABLE IF EXISTS medtech_md_scion_dev.idee_metaschema.pipeline_audit;

# -- Recreate empty metadata tables
# CREATE TABLE medtech_md_scion_dev.idee_metaschema.source_config (
#   source_id        STRING    NOT NULL  COMMENT 'Unique identifier for the source system',
#   source_name      STRING    NOT NULL  COMMENT 'Friendly display name',
#   source_type      STRING    NOT NULL  COMMENT 'cloud_files | jdbc | lakeflow_connect | kafka | api',
#   ingestion_method STRING    NOT NULL  COMMENT 'autoloader | jdbc | lakeflow_connect | kafka | api',
#   landing_required BOOLEAN   NOT NULL  COMMENT 'true = files must land in a volume before Bronze processing',
#   connection_ref   STRING              COMMENT 'UC connection name or Databricks secret scope reference',
#   base_path        STRING              COMMENT 'Root path for file-based sources (cloud storage URI)',
#   active           BOOLEAN   NOT NULL  COMMENT 'false = source is disabled; pipeline skips it entirely',
#   created_at       TIMESTAMP           COMMENT 'Row creation timestamp',
#   updated_at       TIMESTAMP           COMMENT 'Last modification timestamp'
# )
# USING DELTA
# COMMENT 'One row per source system. Defines connection type and ingestion method.'
# TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');

# CREATE TABLE medtech_md_scion_dev.idee_metaschema.object_config (
#   object_id           STRING    NOT NULL  COMMENT 'Unique identifier for this dataset',
#   source_id           STRING    NOT NULL  COMMENT 'FK to source_config.source_id',
#   object_name         STRING    NOT NULL  COMMENT 'Logical business name',
#   source_path         STRING              COMMENT 'Full source path, table name, or API endpoint',
#   file_format         STRING              COMMENT 'csv | json | parquet | delta | avro',
#   load_type           STRING    NOT NULL  COMMENT 'FULL | INCREMENTAL | CDC | SNAPSHOT',
#   primary_key         STRING              COMMENT 'Business key column(s), comma-separated',
#   incremental_column  STRING              COMMENT 'Watermark column used for INCREMENTAL loads',
#   bronze_table        STRING              COMMENT 'Target Bronze table (catalog.schema.table)',
#   silver_table        STRING              COMMENT 'Target Silver table (catalog.schema.table)',
#   execution_order     INT                 COMMENT 'Optional load sequence',
#   parallel_group      STRING              COMMENT 'Optional group tag for parallel execution batches',
#   active              BOOLEAN   NOT NULL  COMMENT 'false = dataset is skipped in all pipeline runs',
#   created_at          TIMESTAMP           COMMENT 'Row creation timestamp',
#   updated_at          TIMESTAMP           COMMENT 'Last modification timestamp'
# )
# USING DELTA
# COMMENT 'One row per dataset. Defines source path, load strategy, keys, and target tables.'
# TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');

# CREATE TABLE medtech_md_scion_dev.idee_metaschema.column_config (
#   object_id              STRING    NOT NULL  COMMENT 'FK to object_config.object_id',
#   source_column          STRING    NOT NULL  COMMENT 'Column name as it appears in the source',
#   target_column          STRING    NOT NULL  COMMENT 'Standardized column name in the target table',
#   target_type            STRING    NOT NULL  COMMENT 'Spark SQL type: STRING | BIGINT | DOUBLE | TIMESTAMP | DATE | BOOLEAN',
#   primary_key_indicator  BOOLEAN   NOT NULL  COMMENT 'true = this column is part of the business key',
#   trim_indicator         BOOLEAN   NOT NULL  COMMENT 'true = strip leading/trailing whitespace',
#   pii_classification     STRING              COMMENT 'PII | SENSITIVE | PUBLIC',
#   nullable               BOOLEAN             COMMENT 'true = column allows nulls (informational; enforce via DQ rules)',
#   sequence               INT                 COMMENT 'Output column order (1-based)',
#   active                 BOOLEAN   NOT NULL  COMMENT 'false = column is excluded from the target table',
#   created_at             TIMESTAMP           COMMENT 'Row creation timestamp'
# )
# USING DELTA
# COMMENT 'One row per column per dataset. Drives schema mapping, type casting, PII tagging, and trimming.'
# TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');

# CREATE TABLE medtech_md_scion_dev.idee_metaschema.quality_rule_config (
#   rule_id          STRING    NOT NULL  COMMENT 'Unique identifier for this rule',
#   object_id        STRING    NOT NULL  COMMENT 'FK to object_config.object_id',
#   rule_name        STRING    NOT NULL  COMMENT 'Human-readable rule description',
#   rule_expression  STRING    NOT NULL  COMMENT 'Spark SQL boolean expression — TRUE means the row passes',
#   action           STRING    NOT NULL  COMMENT 'warn | drop | quarantine | fail',
#   severity         STRING    NOT NULL  COMMENT 'informational | warning | error | critical',
#   active           BOOLEAN   NOT NULL  COMMENT 'false = rule is not evaluated during pipeline runs',
#   rule_source      STRING              COMMENT 'Where the rule came from: inline | native | great_expectations',
#   created_at       TIMESTAMP           COMMENT 'Row creation timestamp',
#   updated_at       TIMESTAMP           COMMENT 'Last modification timestamp'
# )
# USING DELTA
# COMMENT 'One row per DQ rule per dataset. Drives all data quality checks including null enforcement.'
# TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');

# CREATE TABLE medtech_md_scion_dev.idee_metaschema.pipeline_audit (
#   run_id            STRING     NOT NULL  COMMENT 'Framework execution identifier',
#   object_id         STRING     NOT NULL  COMMENT 'FK to object_config.object_id',
#   layer             STRING     NOT NULL  COMMENT 'landing | bronze | silver | gold',
#   start_time        TIMESTAMP  NOT NULL  COMMENT 'Layer execution start time',
#   end_time          TIMESTAMP            COMMENT 'Layer execution end time',
#   rows_read         BIGINT               COMMENT 'Input record count for this layer',
#   rows_written      BIGINT               COMMENT 'Output record count successfully written',
#   rows_rejected     BIGINT               COMMENT 'Records sent to quarantine due to DQ failures',
#   status            STRING     NOT NULL  COMMENT 'STARTED | SUCCESS | FAILED | SKIPPED',
#   error_message     STRING               COMMENT 'Exception details on FAILED status',
#   source_watermark  STRING               COMMENT 'Last watermark value processed (INCREMENTAL loads only)',
#   created_at        TIMESTAMP            COMMENT 'Row insert timestamp'
# )
# USING DELTA
# COMMENT 'Runtime audit log. One row per run + object + layer.'
# PARTITIONED BY (layer)
# TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');

# COMMAND ----------

# DBTITLE 1,Cell 4
# MAGIC %md
# MAGIC ## Create application tables from DDL

# COMMAND ----------

# DBTITLE 1,Run DDL scripts
# Auto runs any DDL files in the ddl folder
from pathlib import Path

DDL_FOLDER = Path.cwd() / ".." / "ddl"
ddl_files = sorted(DDL_FOLDER.glob("*.sql"), key=lambda f: f.name)

print(f"Found {len(ddl_files)} DDL file(s) in {DDL_FOLDER.resolve()}\n")

for ddl_file in ddl_files:
    sql = ddl_file.read_text(encoding="utf-8").strip()
    if sql:
        print(f"  Running: {ddl_file.name}")
        spark.sql(sql)
        print(f"  ✓ Done\n")

print("All DDL executed.")

# COMMAND ----------

# DBTITLE 1,Validate header
# MAGIC %md
# MAGIC ## Validate this team's config

# COMMAND ----------

validation = validate_config_file(CONFIG_PATH)
print(validation.report())
if not validation.is_valid:
    raise ValueError("Config validation failed — see the report above.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Parse it into metadata actions

# COMMAND ----------

plan = parse_config(validation.config, config_path=CONFIG_PATH)
print(plan.summary())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load into the metadata schema

# COMMAND ----------

# This matches each catlog that the user has in their config file with our metadata schema
result = load_plan(
    plan,
    catalog=CATALOG,
    metadata_schema=METADATA_SCHEMA,
    dry_run=DRY_RUN,
    spark=spark,  # noqa: F821
)
print(result.report())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Confirm what landed

# COMMAND ----------

if not DRY_RUN:
    display(  # noqa: F821
        spark.sql(  # noqa: F821
            f"""
            SELECT o.object_id, o.object_name, o.load_type, o.bronze_table,
                   COUNT(c.source_column) AS column_count
            FROM {CATALOG}.{METADATA_SCHEMA}.object_config o
            LEFT JOIN {CATALOG}.{METADATA_SCHEMA}.column_config c
                   ON c.object_id = o.object_id
            WHERE o.object_id = '{plan.object_id}'
            GROUP BY o.object_id, o.object_name, o.load_type, o.bronze_table
            """
        )
    )
else:
    print("Dry run — nothing was written.")