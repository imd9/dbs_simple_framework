-- =============================================================================
-- 00_verify_prerequisites.sql
-- =============================================================================
-- Confirms the catalog and both schemas already exist before any table is
-- created. This script CREATES NOTHING.
--
-- OWNER      : Framework
-- RUNS       : First, before 01-05. Safe to run any time.
-- PARAMETERS : ${catalog}, ${metadata_schema}, ${app_schema}
--
-- WHY THIS DOES NOT CREATE SCHEMAS
--   The catalog and both schemas are provisioned by the platform team as part
--   of environment setup, not by this framework. Creating them here would be
--   wrong twice over: an application workspace usually lacks CREATE SCHEMA
--   privilege, and silently creating a mistyped schema name is worse than
--   failing loudly on it.
--
-- EXPECTED RESULT
--   Two rows, both with schema_status = 'FOUND'.
--   A missing row means that schema does not exist under this catalog -- stop
--   and check the name with the platform team before running 01-05.
-- =============================================================================

SELECT
    catalog_name,
    schema_name,
    'FOUND' AS schema_status
FROM system.information_schema.schemata
WHERE catalog_name = '${catalog}'
  AND schema_name IN ('${metadata_schema}', '${app_schema}')
ORDER BY schema_name;
