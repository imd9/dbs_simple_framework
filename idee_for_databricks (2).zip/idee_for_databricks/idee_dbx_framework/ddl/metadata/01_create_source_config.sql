-- =============================================================================
-- 01_create_source_config.sql
-- =============================================================================
-- One row per physical source system. Populated by the framework parser from
-- the `source:` block of a pipeline config.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.source_config (
    source_id         STRING  NOT NULL COMMENT 'Unique, stable code for this source. Never reused.',
    source_name       STRING  NOT NULL COMMENT 'Friendly display name.',
    source_type       STRING  NOT NULL COMMENT 'cloud_files | jdbc | lakeflow_connect | kafka | api',
    ingestion_method  STRING  NOT NULL COMMENT 'autoloader | jdbc | lakeflow_connect | kafka | api',
    landing_required  BOOLEAN NOT NULL COMMENT 'TRUE = stage into a landing volume before Bronze.',
    connection_ref    STRING  NOT NULL COMMENT 'UC connection name or secret scope reference. Never a raw credential.',
    base_path         STRING           COMMENT 'Root cloud storage path for file sources.',
    active            BOOLEAN NOT NULL COMMENT 'FALSE = skip every dataset on this source.',
    created_at        TIMESTAMP        COMMENT 'Row insert time.',
    updated_at        TIMESTAMP        COMMENT 'Row last update time.',
    CONSTRAINT pk_source_config PRIMARY KEY (source_id) RELY
)
USING DELTA
COMMENT 'iDEE metadata: data sources. One row per source system.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'metadata',
    'idee.owner'                 = 'framework'
);
