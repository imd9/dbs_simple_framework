-- =============================================================================
-- 02_create_object_config.sql
-- =============================================================================
-- One row per dataset (the unit of work). Populated by the framework parser
-- from the `dataset:` block of a pipeline config.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.object_config (
    object_id           STRING  NOT NULL COMMENT 'Unique, stable code for this dataset. Never reused.',
    source_id           STRING  NOT NULL COMMENT 'FK to source_config.source_id.',
    object_name         STRING  NOT NULL COMMENT 'Logical dataset name, e.g. customer.',
    source_path         STRING  NOT NULL COMMENT 'Path under base_path, or fully-qualified source table.',
    file_format         STRING           COMMENT 'csv | json | parquet | delta | avro',
    load_type           STRING  NOT NULL COMMENT 'FULL | INCREMENTAL | CDC | SNAPSHOT',
    primary_key         STRING           COMMENT 'Business key column(s), comma-separated.',
    incremental_column  STRING           COMMENT 'Watermark column. Required for INCREMENTAL.',
    bronze_table        STRING  NOT NULL COMMENT 'Three-part target name for raw ingest.',
    silver_table        STRING           COMMENT 'Three-part target name for cleaned data. NULL stops at Bronze.',
    active              BOOLEAN NOT NULL COMMENT 'FALSE = skip this dataset at run time.',
    execution_order     INT              COMMENT 'Lower runs first. 0 = order does not matter.',
    parallel_group      STRING           COMMENT 'Datasets sharing a group may run concurrently.',
    created_at          TIMESTAMP        COMMENT 'Row insert time.',
    updated_at          TIMESTAMP        COMMENT 'Row last update time.',
    CONSTRAINT pk_object_config PRIMARY KEY (object_id) RELY,
    CONSTRAINT fk_object_source FOREIGN KEY (source_id)
        REFERENCES ${catalog}.${metadata_schema}.source_config (source_id) NOT ENFORCED RELY
)
USING DELTA
COMMENT 'iDEE metadata: datasets. One row per dataset being loaded.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'metadata',
    'idee.owner'                 = 'framework'
);
