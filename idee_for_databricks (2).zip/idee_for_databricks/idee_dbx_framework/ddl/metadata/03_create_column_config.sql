-- =============================================================================
-- 03_create_column_config.sql
-- =============================================================================
-- One row per column per dataset. Drives the Bronze -> Silver transformation:
-- rename, cast, trim, PII tagging, output ordering.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.column_config (
    object_id              STRING  NOT NULL COMMENT 'FK to object_config.object_id.',
    source_column          STRING  NOT NULL COMMENT 'Column name exactly as it appears in the source.',
    target_column          STRING  NOT NULL COMMENT 'Standardised name in Silver.',
    target_type            STRING  NOT NULL COMMENT 'STRING | BIGINT | DOUBLE | TIMESTAMP | DATE | BOOLEAN',
    primary_key_indicator  BOOLEAN NOT NULL COMMENT 'TRUE = part of the business key.',
    trim_indicator         BOOLEAN NOT NULL COMMENT 'TRUE = strip leading/trailing whitespace.',
    pii_classification     STRING  NOT NULL COMMENT 'PII | SENSITIVE | PUBLIC',
    nullable               BOOLEAN NOT NULL COMMENT 'FALSE = null values are invalid.',
    sequence               INT     NOT NULL COMMENT 'Output column order in Silver, 1-based.',
    active                 BOOLEAN NOT NULL COMMENT 'FALSE = exclude the column without deleting the row.',
    created_at             TIMESTAMP        COMMENT 'Row insert time.',
    updated_at             TIMESTAMP        COMMENT 'Row last update time.',
    CONSTRAINT pk_column_config PRIMARY KEY (object_id, source_column) RELY,
    CONSTRAINT fk_column_object FOREIGN KEY (object_id)
        REFERENCES ${catalog}.${metadata_schema}.object_config (object_id) NOT ENFORCED RELY
)
USING DELTA
COMMENT 'iDEE metadata: column definitions. One row per column per dataset.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'metadata',
    'idee.owner'                 = 'framework'
);
