-- =============================================================================
-- 04_create_quality_rule_config.sql
-- =============================================================================
-- One row per data quality rule.
--
-- Populated ONLY when a config sets quality.engine = inline. The other two
-- engines keep their rules elsewhere:
--   native             -> YAML rule pack in the framework dq_rules/ folder
--   great_expectations -> GX expectation suite (JSON) inside Databricks
-- rule_source records which engine a row came from.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.quality_rule_config (
    rule_id          STRING  NOT NULL COMMENT 'Deterministic id: <object_id>__<slugified rule_name>.',
    object_id        STRING  NOT NULL COMMENT 'FK to object_config.object_id.',
    rule_name        STRING  NOT NULL COMMENT 'Human-readable rule name.',
    rule_expression  STRING  NOT NULL COMMENT 'Spark SQL boolean. TRUE = the row passes.',
    action           STRING  NOT NULL COMMENT 'warn | drop | quarantine | fail',
    severity         STRING  NOT NULL COMMENT 'informational | warning | error | critical',
    active           BOOLEAN NOT NULL COMMENT 'FALSE = rule is not enforced.',
    rule_source      STRING           COMMENT 'Which engine produced this row. inline in v0.1.',
    created_at       TIMESTAMP        COMMENT 'Row insert time.',
    updated_at       TIMESTAMP        COMMENT 'Row last update time.',
    CONSTRAINT pk_quality_rule_config PRIMARY KEY (rule_id) RELY,
    CONSTRAINT fk_rule_object FOREIGN KEY (object_id)
        REFERENCES ${catalog}.${metadata_schema}.object_config (object_id) NOT ENFORCED RELY
)
USING DELTA
COMMENT 'iDEE metadata: data quality rules. Populated for the inline engine only.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'metadata',
    'idee.owner'                 = 'framework'
);
