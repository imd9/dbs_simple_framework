-- =============================================================================
-- 05_create_pipeline_audit.sql
-- =============================================================================
-- Runtime log. One row per (run, dataset, layer). Written by the pipeline at
-- execution time, never by a config file and never by hand.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.pipeline_audit (
    run_id            STRING    NOT NULL COMMENT 'Unique identifier for the pipeline run.',
    object_id         STRING    NOT NULL COMMENT 'Which dataset this row describes.',
    layer             STRING    NOT NULL COMMENT 'landing | bronze | silver',
    start_time        TIMESTAMP NOT NULL COMMENT 'When this layer started.',
    end_time          TIMESTAMP          COMMENT 'When this layer finished. NULL while running.',
    rows_read         BIGINT             COMMENT 'Rows read from the source.',
    rows_written      BIGINT             COMMENT 'Rows written to the target.',
    rows_rejected     BIGINT             COMMENT 'Rows that failed data quality.',
    status            STRING    NOT NULL COMMENT 'STARTED | SUCCESS | FAILED | SKIPPED',
    error_message     STRING             COMMENT 'Error detail when status = FAILED.',
    source_watermark  STRING             COMMENT 'Watermark value used for incremental runs.',
    created_at        TIMESTAMP          COMMENT 'Row insert time.',
    CONSTRAINT pk_pipeline_audit PRIMARY KEY (run_id, object_id, layer) RELY
)
USING DELTA
COMMENT 'iDEE metadata: runtime audit log. Written by the pipeline.'
PARTITIONED BY (layer)
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'metadata',
    'idee.owner'                 = 'framework'
);
