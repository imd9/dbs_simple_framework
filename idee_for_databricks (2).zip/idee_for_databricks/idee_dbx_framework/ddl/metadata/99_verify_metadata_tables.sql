-- =============================================================================
-- 99_verify_metadata_tables.sql
-- =============================================================================
-- Post-install check. Confirms all five metadata tables exist and reports how
-- many rows each holds. Safe to run any time.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
-- =============================================================================

SELECT 'source_config'       AS table_name, COUNT(*) AS row_count FROM ${catalog}.${metadata_schema}.source_config
UNION ALL
SELECT 'object_config'       AS table_name, COUNT(*) AS row_count FROM ${catalog}.${metadata_schema}.object_config
UNION ALL
SELECT 'column_config'       AS table_name, COUNT(*) AS row_count FROM ${catalog}.${metadata_schema}.column_config
UNION ALL
SELECT 'quality_rule_config' AS table_name, COUNT(*) AS row_count FROM ${catalog}.${metadata_schema}.quality_rule_config
UNION ALL
SELECT 'pipeline_audit'      AS table_name, COUNT(*) AS row_count FROM ${catalog}.${metadata_schema}.pipeline_audit
ORDER BY table_name;
