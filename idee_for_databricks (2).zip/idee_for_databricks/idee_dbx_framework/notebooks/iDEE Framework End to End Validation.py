# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# DBTITLE 1,iDEE Framework — Full Test Suite
# MAGIC %md
# MAGIC # iDEE for Databricks — Framework Test Notebook
# MAGIC
# MAGIC This notebook consolidates all phases from `docs/TESTING_GUIDE.md` into a single
# MAGIC ready-to-run artifact. Attach to your cluster and run top to bottom.
# MAGIC
# MAGIC **What this tests:**
# MAGIC - Unit tests (PyTest suite — 80+ tests)
# MAGIC - Validator rejects bad input
# MAGIC - Metadata table DDL creation
# MAGIC - Dry run (validate → parse → preview SQL)
# MAGIC - Live load (write metadata rows)
# MAGIC - Idempotency (run twice, counts don't double)
# MAGIC
# MAGIC **Scope note:** v0.1 loads *metadata*, not data. No ingestion engine yet.

# COMMAND ----------

# DBTITLE 1,Setup — Set paths (re-run after any Python restart)
# ===========================================================================
# SET THESE ONCE — everything below derives from them
# ===========================================================================
PROJECT_ROOT     = "/Workspace/Users/iduran3@its.jnj.com/idee_for_databricks"
FRAMEWORK        = f"{PROJECT_ROOT}/idee_dbx_framework"
APP              = f"{PROJECT_ROOT}/idee_dbx_app"

CATALOG          = "medtech_md_scion_dev"   # your catalog
METADATA_SCHEMA  = "idee_metaschema"        # metadata tables only
APP_SCHEMA       = "idee_app"               # business tables

print(f"PROJECT_ROOT:    {PROJECT_ROOT}")
print(f"FRAMEWORK:       {FRAMEWORK}")
print(f"APP:             {APP}")
print(f"CATALOG:         {CATALOG}")
print(f"METADATA_SCHEMA: {METADATA_SCHEMA}")

# COMMAND ----------

# DBTITLE 1,Phase 1 — Confirm folder layout
import os

for label, path in [("Framework", FRAMEWORK), ("App", APP)]:
    status = "FOUND" if os.path.isdir(path) else "MISSING"
    print(f"{label}: {status}  {path}")

print("\nFramework contents:")
for entry in sorted(os.listdir(FRAMEWORK)):
    print("  ", entry)

print("\nApp contents:")
for entry in sorted(os.listdir(APP)):
    print("  ", entry)

# COMMAND ----------

# DBTITLE 1,Phase 2 — Install dependencies
# MAGIC %pip install pytest pyyaml --quiet

# COMMAND ----------

# DBTITLE 1,Phase 2b — Restart Python (required after pip install)
dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Phase 2c — Re-set paths after restart
# After restartPython(), all variables are cleared. Re-set paths.
PROJECT_ROOT     = "/Workspace/Users/iduran3@its.jnj.com/idee_for_databricks"
FRAMEWORK        = f"{PROJECT_ROOT}/idee_dbx_framework"
APP              = f"{PROJECT_ROOT}/idee_dbx_app"

CATALOG          = "medtech_md_scion_dev"
METADATA_SCHEMA  = "idee_metaschema"
APP_SCHEMA       = "idee_app"

# COMMAND ----------

# DBTITLE 1,Phase 3 — Run the PyTest unit tests
import os
import sys
import pytest

# Workspace storage may reject cache writes, so disable bytecode and caching.
sys.dont_write_bytecode = True

os.chdir(FRAMEWORK)
if f"{FRAMEWORK}/src" not in sys.path:
    sys.path.insert(0, f"{FRAMEWORK}/src")

exit_code = pytest.main([
    "tests/",
    "-v",
    "-c", "docs/pytest.ini",    # pytest.ini moved to docs/
    "-p", "no:cacheprovider",   # do not write .pytest_cache to the workspace
    "--tb=short",
])

print(f"\n{'='*60}")
print(f"PyTest exit code: {exit_code}   (0 = all passed)")
print(f"{'='*60}")

if exit_code == 0:
    print("\n✅ ALL TESTS PASSED — framework code is healthy.")
else:
    print("\n❌ SOME TESTS FAILED — read the output above for details.")

# COMMAND ----------

# DBTITLE 1,Phase 5 — Prove the validator rejects bad input
import sys
if f"{FRAMEWORK}/src" not in sys.path:
    sys.path.insert(0, f"{FRAMEWORK}/src")

from idee_dbx.config_validator import validate_config
import yaml, copy

with open(f"{APP}/config/customer_full_refresh_config.yaml") as f:
    good = yaml.safe_load(f)

SCHEMA_DIR = f"{FRAMEWORK}/schema"

def show(label, mutate):
    cfg = copy.deepcopy(good)
    mutate(cfg)
    r = validate_config(cfg, config_path=label, schema_dir=SCHEMA_DIR)
    status = "✅ PASSED" if r.is_valid else "❌ FAILED"
    print(f"\n--- {label} --- {status}")
    if not r.is_valid:
        for e in r.errors:
            print(f"   Error: {e}")
    if r.warnings:
        for w in r.warnings:
            print(f"   Warning: {w}")

print("Each of these SHOULD fail (proving the validator catches problems):\n")
show("Illegal load_type",        lambda c: c["dataset"].__setitem__("load_type", "UPSERT"))
show("INCREMENTAL, no watermark", lambda c: c["dataset"].update({"load_type": "INCREMENTAL", "incremental_column": ""}))
show("Two-part table name",      lambda c: c["dataset"].__setitem__("bronze_table", "idee_app.bronze_customer"))
show("Mismatched source_id",     lambda c: c["dataset"].__setitem__("source_id", "src_wrong"))
show("Duplicate column name",    lambda c: c["columns"][1].__setitem__("target_column", c["columns"][0]["target_column"]))

# COMMAND ----------

# DBTITLE 1,Phase 5b — Blank template must be rejected
from idee_dbx.config_validator import validate_config_file

r = validate_config_file(
    f"{FRAMEWORK}/templates/idee_pipeline_config_template.yaml",
    schema_dir=SCHEMA_DIR
)

if not r.is_valid:
    print("✅ CORRECT: Blank template is rejected (as expected).")
    print(f"   {len(r.errors)} error(s) found.")
    for e in r.errors[:5]:
        print(f"   • {e}")
else:
    print("❌ PROBLEM: Blank template passed validation — this should NOT happen.")

# COMMAND ----------

# DBTITLE 1,Phase 6 — Preflight: verify schemas exist
sql = open(f"{FRAMEWORK}/ddl/metadata/00_verify_prerequisites.sql").read()
for k, v in {"catalog": CATALOG, "metadata_schema": METADATA_SCHEMA, "app_schema": APP_SCHEMA}.items():
    sql = sql.replace("${" + k + "}", v)
display(spark.sql(sql))

# COMMAND ----------

# DBTITLE 1,Phase 6b — Create the metadata tables (DDL)
import glob, os

def run_ddl(folder, substitutions, skip=("00_", "99_")):
    """Run all DDL scripts in order, substituting placeholders."""
    for path in sorted(glob.glob(f"{folder}/*.sql")):
        name = os.path.basename(path)
        if any(name.startswith(s) for s in skip):
            continue
        sql = open(path).read()
        for key, value in substitutions.items():
            sql = sql.replace("${" + key + "}", value)
        print(f"Running {name} ...", end=" ")
        spark.sql(sql)
        print("✅ OK")

run_ddl(
    f"{FRAMEWORK}/ddl/metadata",
    {"catalog": CATALOG, "metadata_schema": METADATA_SCHEMA},
)
print("\nAll metadata tables created.")

# COMMAND ----------

# DBTITLE 1,Phase 6c — Verify metadata tables exist (expect 5 tables, 0 rows each)
sql = open(f"{FRAMEWORK}/ddl/metadata/99_verify_metadata_tables.sql").read()
sql = sql.replace("${catalog}", CATALOG).replace("${metadata_schema}", METADATA_SCHEMA)
display(spark.sql(sql))

# COMMAND ----------

# DBTITLE 1,Phase 7 — Dry run (validate → parse → preview SQL, writes nothing)
from idee_dbx.config_validator import validate_config_file
from idee_dbx.config_parser import parse_config_file

config_path = f"{APP}/config/customer_full_refresh_config.yaml"

# Step 1: Validate
print("="*60)
print("STEP 1 — VALIDATE")
print("="*60)
result = validate_config_file(config_path, schema_dir=f"{FRAMEWORK}/schema")
print(result.report())

if not result.is_valid:
    raise RuntimeError("Validation failed — fix the config before continuing.")

# Step 2: Parse (build the plan)
print("\n" + "="*60)
print("STEP 2 — PARSE (build plan, execute nothing)")
print("="*60)
plan = parse_config_file(config_path)
print(plan.summary())

# Step 3: Show the generated SQL
print("\n" + "="*60)
print("STEP 3 — GENERATED MERGE SQL (DRY RUN)")
print("="*60)
for stmt in plan.to_merge_statements(CATALOG, METADATA_SCHEMA):
    print(f"\n{stmt}\n{'---'*20}")

print("\n\n✅ DRY RUN COMPLETE — nothing was written.")

# COMMAND ----------

# DBTITLE 1,Phase 8 — Live load (writes metadata rows for real)
from idee_dbx.metadata_loader import load_plan

print("="*60)
print("LIVE LOAD — writing metadata to catalog")
print("="*60)

load_result = load_plan(plan, CATALOG, METADATA_SCHEMA, dry_run=False, spark=spark)
print(load_result.report())

print("\n\n✅ LIVE LOAD COMPLETE.")

# COMMAND ----------

# DBTITLE 1,Phase 8b — Verify rows were written
print("Verifying metadata row counts after live load:\n")

for table in ["source_config", "object_config", "column_config", "quality_rule_config"]:
    count = spark.sql(f"SELECT COUNT(*) AS cnt FROM {CATALOG}.{METADATA_SCHEMA}.{table}").collect()[0]["cnt"]
    print(f"  {table:30s} = {count} rows")

print("\nExpected: 1 / 1 / 5 / 3")

# COMMAND ----------

# DBTITLE 1,Phase 8c — Inspect loaded objects with columns
display(spark.sql(f"""
    SELECT o.object_id, o.object_name, o.load_type, o.bronze_table,
           COUNT(c.source_column) AS column_count
    FROM {CATALOG}.{METADATA_SCHEMA}.object_config o
    LEFT JOIN {CATALOG}.{METADATA_SCHEMA}.column_config c ON c.object_id = o.object_id
    GROUP BY 1,2,3,4
"""))

# COMMAND ----------

# DBTITLE 1,Phase 9 — Idempotency check (run load again, counts should NOT double)
# Run the SAME load a second time
print("Running the same load a SECOND time to prove idempotency...\n")
load_result_2 = load_plan(plan, CATALOG, METADATA_SCHEMA, dry_run=False, spark=spark)
print(load_result_2.report())

print("\n" + "="*60)
print("IDEMPOTENCY VERIFICATION")
print("="*60)

expected = {"source_config": 1, "object_config": 1, "column_config": 5, "quality_rule_config": 3}
all_pass = True

for table, expected_count in expected.items():
    actual = spark.sql(f"SELECT COUNT(*) AS cnt FROM {CATALOG}.{METADATA_SCHEMA}.{table}").collect()[0]["cnt"]
    status = "✅" if actual == expected_count else "❌"
    if actual != expected_count:
        all_pass = False
    print(f"  {status} {table:30s} = {actual} rows (expected {expected_count})")

if all_pass:
    print("\n\n✅ IDEMPOTENCY CONFIRMED — second run did NOT duplicate rows.")
    print("   Framework uses MERGE (not INSERT) and deterministic rule_ids.")
    print("   Safe to re-run configs in CI/CD without metadata corruption.")
else:
    print("\n\n❌ IDEMPOTENCY FAILED — row counts changed after second run.")
    print("   This indicates INSERT or random UUID usage somewhere.")

# COMMAND ----------

# DBTITLE 1,Summary
# MAGIC %md
# MAGIC ## What Was Proven
# MAGIC
# MAGIC | Phase | What it showed |
# MAGIC |---|---|
# MAGIC | Phase 1 | Folder structure is correct and accessible |
# MAGIC | Phase 3 | 80+ unit tests pass (validator + parser logic) |
# MAGIC | Phase 5 | Validator rejects illegal configs with clear errors |
# MAGIC | Phase 5b | Blank template is rejected (safety guard) |
# MAGIC | Phase 6 | Metadata DDL creates 5 tables successfully |
# MAGIC | Phase 7 | Dry run: validate → parse → preview SQL without writing |
# MAGIC | Phase 8 | Live load: metadata rows written (1/1/5/3) |
# MAGIC | Phase 9 | Idempotency: running twice doesn’t duplicate rows |
# MAGIC
# MAGIC ## Scope
# MAGIC
# MAGIC This loads **metadata**, not data. No ingestion engine yet — Bronze and Silver
# MAGIC movement is the next increment. The config path is proven end to end first.
# MAGIC
# MAGIC ## Next Increment
# MAGIC
# MAGIC - Bronze ingestion via Auto Loader (full refresh)
# MAGIC - Silver transformation driven by `column_config`
# MAGIC - DQ runtime enforcement using `quality_rule_config` expressions