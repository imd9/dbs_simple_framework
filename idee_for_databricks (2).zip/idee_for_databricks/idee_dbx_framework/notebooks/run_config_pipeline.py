# Databricks notebook source
# MAGIC %md
# MAGIC # iDEE for Databricks — Config Pipeline
# MAGIC
# MAGIC Runs the three framework stages against one filled config file:
# MAGIC
# MAGIC | Stage | Module | Question it answers |
# MAGIC |---|---|---|
# MAGIC | Validate | `config_validator` | Is this config legal? |
# MAGIC | Parse | `config_parser` | What metadata actions does it produce? |
# MAGIC | Load | `metadata_loader` | Apply those actions to the metadata tables |
# MAGIC
# MAGIC **Nothing is hardcoded.** Catalog, schema, and config path are all widgets.
# MAGIC
# MAGIC Run with `dry_run = true` first — it shows exactly what would be written
# MAGIC without writing anything.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Parameters

# COMMAND ----------

dbutils.widgets.text("catalog", "medtech_md_scion_dev", "1. Catalog")
dbutils.widgets.text("metadata_schema", "idee_metaschema", "2. Metadata schema")
dbutils.widgets.text(
    "config_path",
    "../../idee_dbx_app/config/customer_full_refresh_config.yaml",
    "3. Filled config file",
)
dbutils.widgets.dropdown("dry_run", "true", ["true", "false"], "4. Dry run")

CATALOG = dbutils.widgets.get("catalog")
METADATA_SCHEMA = dbutils.widgets.get("metadata_schema")
CONFIG_PATH = dbutils.widgets.get("config_path")
DRY_RUN = dbutils.widgets.get("dry_run") == "true"

print(f"Catalog         : {CATALOG}")
print(f"Metadata schema : {METADATA_SCHEMA}")
print(f"Config          : {CONFIG_PATH}")
print(f"Dry run         : {DRY_RUN}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import the framework
# MAGIC
# MAGIC Adds `src/` to the path so `idee_dbx` imports without being pip-installed.
# MAGIC Once the framework is published as a wheel this cell goes away.

# COMMAND ----------

import sys
from pathlib import Path

NOTEBOOK_DIR = Path.cwd()
FRAMEWORK_SRC = (NOTEBOOK_DIR / ".." / "src").resolve()

if str(FRAMEWORK_SRC) not in sys.path:
    sys.path.insert(0, str(FRAMEWORK_SRC))

import idee_dbx
from idee_dbx.config_parser import parse_config
from idee_dbx.config_validator import validate_config_file
from idee_dbx.metadata_loader import load_plan

print(f"Framework version: {idee_dbx.__version__}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stage 1 — Validate

# COMMAND ----------

print("Loading started...")
validation = validate_config_file(CONFIG_PATH)
print(validation.report())

if not validation.is_valid:
    raise ValueError(
        f"Config validation failed with {len(validation.errors)} error(s). "
        "See the report above. Nothing was parsed or loaded."
    )

print("\nConfig schema validation passed.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stage 2 — Parse

# COMMAND ----------

plan = parse_config(validation.config, config_path=CONFIG_PATH)
print(plan.summary())
print("\nParser completed. Metadata action list generated.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stage 2b — Inspect the generated SQL
# MAGIC
# MAGIC Review this before switching `dry_run` off.

# COMMAND ----------

for statement in plan.to_merge_statements(CATALOG, METADATA_SCHEMA):
    print(statement)
    print()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stage 3 — Load
# MAGIC
# MAGIC With `dry_run = true` nothing is written. Set it to `false` to apply.

# COMMAND ----------

result = load_plan(
    plan,
    catalog=CATALOG,
    metadata_schema=METADATA_SCHEMA,
    dry_run=DRY_RUN,
    spark=spark,  # noqa: F821 - provided by the Databricks runtime
)
print(result.report())

if not result.succeeded:
    raise RuntimeError("Metadata load failed. See the errors above.")

print("\nLoad complete." if not DRY_RUN else "\nDry run complete — nothing was written.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

if not DRY_RUN:
    for table in ["source_config", "object_config", "column_config", "quality_rule_config"]:
        count = spark.table(f"{CATALOG}.{METADATA_SCHEMA}.{table}").count()  # noqa: F821
        print(f"{table:<22} {count} row(s)")
else:
    print("Dry run — skipping verification.")
