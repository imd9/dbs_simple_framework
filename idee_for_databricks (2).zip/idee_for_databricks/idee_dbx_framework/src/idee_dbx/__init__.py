"""
iDEE for Databricks — metadata-driven ELT framework.

Framework-owned reusable logic. Application teams import from here; they do
not modify it.

Modules
-------
config_validator : validate a filled pipeline config against a versioned schema
config_parser    : translate a valid config into metadata table actions
metadata_loader  : apply those actions to the Unity Catalog metadata schema
main             : command-line entry point (validate / parse / load)
"""

__version__ = "0.1.0"

FRAMEWORK_NAME = "iDEE for Databricks"

__all__ = ["__version__", "FRAMEWORK_NAME"]
