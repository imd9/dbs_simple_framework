"""
Config parser.

Answers one question: **what metadata actions does this config produce?**

The parser assumes the config is already valid — run config_validator first.
It translates a valid config into rows destined for the metadata tables, and
can render those rows as MERGE statements. It does not touch Spark or the
warehouse; applying the actions is metadata_loader's job.

Keeping parse and load separate is what makes a dry run possible: you can see
exactly what would be written before anything is written.

Usage
-----
    from idee_dbx.config_parser import parse_config_file

    plan = parse_config_file("path/to/customer_full_refresh_config.yaml")
    print(plan.summary())
    for statement in plan.to_merge_statements("my_catalog", "idee_metaschema"):
        print(statement)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List

import yaml

# Metadata table names, in dependency order (parents before children).
TABLE_SOURCE_CONFIG = "source_config"
TABLE_OBJECT_CONFIG = "object_config"
TABLE_COLUMN_CONFIG = "column_config"
TABLE_QUALITY_RULE_CONFIG = "quality_rule_config"

TABLE_ORDER = [
    TABLE_SOURCE_CONFIG,
    TABLE_OBJECT_CONFIG,
    TABLE_COLUMN_CONFIG,
    TABLE_QUALITY_RULE_CONFIG,
]

# Business keys used to MERGE (upsert) rather than blindly insert. Re-parsing
# the same config must not create duplicate rows.
MERGE_KEYS = {
    TABLE_SOURCE_CONFIG: ["source_id"],
    TABLE_OBJECT_CONFIG: ["object_id"],
    TABLE_COLUMN_CONFIG: ["object_id", "source_column"],
    TABLE_QUALITY_RULE_CONFIG: ["rule_id"],
}


# =============================================================================
# Plan objects
# =============================================================================
@dataclass
class MetadataAction:
    """One row headed for one metadata table."""

    table: str
    operation: str          # always "MERGE" in v0.1
    keys: Dict[str, Any]    # the business key identifying the row
    values: Dict[str, Any]  # the full row payload

    def describe(self) -> str:
        key_text = ", ".join(f"{k}={v!r}" for k, v in self.keys.items())
        return f"{self.operation:<6} {self.table:<22} ({key_text})"


@dataclass
class ParsePlan:
    """Everything a single config file would do to the metadata tables."""

    config_path: str
    object_id: str = ""
    source_id: str = ""
    config_version: str = ""
    actions: List[MetadataAction] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    def add(self, action: MetadataAction) -> None:
        self.actions.append(action)

    def actions_for(self, table: str) -> List[MetadataAction]:
        return [a for a in self.actions if a.table == table]

    def counts(self) -> Dict[str, int]:
        return {table: len(self.actions_for(table)) for table in TABLE_ORDER}

    def summary(self) -> str:
        """Human-readable plan, suitable for printing in a notebook cell."""
        lines = [
            f"Config      : {self.config_path}",
            f"Version     : {self.config_version}",
            f"Source ID   : {self.source_id}",
            f"Object ID   : {self.object_id}",
            "",
            f"Planned metadata actions ({len(self.actions)} total):",
        ]
        for table, count in self.counts().items():
            lines.append(f"  {table:<22} {count} row(s)")

        lines.append("")
        lines.append("Detail:")
        lines.extend(f"  {a.describe()}" for a in self.actions)

        if self.notes:
            lines.append("")
            lines.append("Notes:")
            lines.extend(f"  - {n}" for n in self.notes)
        return "\n".join(lines)

    def to_merge_statements(self, catalog: str, metadata_schema: str) -> List[str]:
        """Render every action as a Databricks SQL MERGE statement."""
        return [
            _render_merge(action, catalog, metadata_schema)
            for table in TABLE_ORDER
            for action in self.actions_for(table)
        ]


# =============================================================================
# SQL rendering
# =============================================================================
def _sql_literal(value: Any) -> str:
    """Render a Python value as a Databricks SQL literal."""
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)):
        return str(value)
    escaped = str(value).replace("'", "''")
    return f"'{escaped}'"


def _render_merge(action: MetadataAction, catalog: str, metadata_schema: str) -> str:
    """Build a MERGE statement for one row. Upsert semantics, idempotent."""
    target = f"{catalog}.{metadata_schema}.{action.table}"
    columns = list(action.values.keys())

    source_row = ", ".join(f"{_sql_literal(action.values[c])} AS {c}" for c in columns)
    on_clause = " AND ".join(f"tgt.{k} = src.{k}" for k in action.keys)
    update_set = ",\n           ".join(f"tgt.{c} = src.{c}" for c in columns if c not in action.keys)
    insert_cols = ", ".join(columns)
    insert_vals = ", ".join(f"src.{c}" for c in columns)

    return (
        f"MERGE INTO {target} AS tgt\n"
        f"USING (SELECT {source_row}) AS src\n"
        f"   ON {on_clause}\n"
        f" WHEN MATCHED THEN UPDATE SET\n"
        f"           {update_set}\n"
        f" WHEN NOT MATCHED THEN INSERT ({insert_cols})\n"
        f"      VALUES ({insert_vals});"
    )


# =============================================================================
# Parsing
# =============================================================================
def _clean(value: Any) -> Any:
    """Normalise empty strings to None so they land as SQL NULL."""
    if isinstance(value, str) and value.strip() == "":
        return None
    return value


def _build_rule_id(object_id: str, rule_name: str) -> str:
    """
    Deterministic rule identifier.

    Deterministic matters: re-parsing the same config must MERGE onto the same
    row rather than inserting a duplicate. A random UUID would break that.
    """
    slug = "".join(ch.lower() if ch.isalnum() else "_" for ch in rule_name).strip("_")
    while "__" in slug:
        slug = slug.replace("__", "_")
    return f"{object_id}__{slug}"[:200]


def parse_config(config: Dict[str, Any], config_path: str = "<in-memory>") -> ParsePlan:
    """Translate a valid config dict into a ParsePlan."""
    source = config.get("source") or {}
    dataset = config.get("dataset") or {}
    columns = config.get("columns") or []
    quality = config.get("quality") or {}

    object_id = dataset.get("object_id", "")
    source_id = source.get("source_id", "")

    plan = ParsePlan(
        config_path=config_path,
        object_id=object_id,
        source_id=source_id,
        config_version=str(config.get("config_version", "")),
    )

    # --- source_config: one row --------------------------------------------
    plan.add(
        MetadataAction(
            table=TABLE_SOURCE_CONFIG,
            operation="MERGE",
            keys={"source_id": source_id},
            values={
                "source_id": source_id,
                "source_name": _clean(source.get("source_name")),
                "source_type": _clean(source.get("source_type")),
                "ingestion_method": _clean(source.get("ingestion_method")),
                "landing_required": source.get("landing_required"),
                "connection_ref": _clean(source.get("connection_ref")),
                "base_path": _clean(source.get("base_path")),
                "active": source.get("active"),
            },
        )
    )

    # --- object_config: one row --------------------------------------------
    plan.add(
        MetadataAction(
            table=TABLE_OBJECT_CONFIG,
            operation="MERGE",
            keys={"object_id": object_id},
            values={
                "object_id": object_id,
                "source_id": _clean(dataset.get("source_id")),
                "object_name": _clean(dataset.get("object_name")),
                "source_path": _clean(dataset.get("source_path")),
                "file_format": _clean(dataset.get("file_format")),
                "load_type": _clean(dataset.get("load_type")),
                "primary_key": _clean(dataset.get("primary_key")),
                "incremental_column": _clean(dataset.get("incremental_column")),
                "bronze_table": _clean(dataset.get("bronze_table")),
                "silver_table": _clean(dataset.get("silver_table")),
                "active": dataset.get("active"),
                "execution_order": dataset.get("execution_order", 0),
                "parallel_group": _clean(dataset.get("parallel_group")),
            },
        )
    )

    # --- column_config: one row per column ----------------------------------
    for column in columns:
        if not isinstance(column, dict):
            continue
        source_column = column.get("source_column")
        plan.add(
            MetadataAction(
                table=TABLE_COLUMN_CONFIG,
                operation="MERGE",
                keys={"object_id": object_id, "source_column": source_column},
                values={
                    "object_id": object_id,
                    "source_column": source_column,
                    "target_column": _clean(column.get("target_column")),
                    "target_type": _clean(column.get("target_type")),
                    "primary_key_indicator": column.get("primary_key_indicator"),
                    "trim_indicator": column.get("trim_indicator"),
                    "pii_classification": _clean(column.get("pii_classification")),
                    "nullable": column.get("nullable"),
                    "sequence": column.get("sequence"),
                    "active": column.get("active"),
                },
            )
        )

    # --- quality: engine decides whether rows are produced ------------------
    engine = quality.get("engine")

    if engine == "inline":
        for rule in quality.get("rules") or []:
            if not isinstance(rule, dict):
                continue
            rule_name = rule.get("rule_name", "")
            rule_id = _build_rule_id(object_id, rule_name)
            plan.add(
                MetadataAction(
                    table=TABLE_QUALITY_RULE_CONFIG,
                    operation="MERGE",
                    keys={"rule_id": rule_id},
                    values={
                        "rule_id": rule_id,
                        "object_id": object_id,
                        "rule_name": rule_name,
                        "rule_expression": _clean(rule.get("rule_expression")),
                        "action": _clean(rule.get("action")),
                        "severity": _clean(rule.get("severity")),
                        "active": rule.get("active"),
                        "rule_source": "inline",
                    },
                )
            )
        plan.notes.append(
            f"quality.engine = inline — {len(plan.actions_for(TABLE_QUALITY_RULE_CONFIG))} "
            f"rule row(s) written to {TABLE_QUALITY_RULE_CONFIG}"
        )

    elif engine == "native":
        plan.notes.append(
            f"quality.engine = native — rules are read at run time from "
            f"'{quality.get('rules_path')}'. No rows written to {TABLE_QUALITY_RULE_CONFIG}."
        )

    elif engine == "great_expectations":
        plan.notes.append(
            f"quality.engine = great_expectations — validation runs against GX suite "
            f"'{quality.get('suite_name')}'. No rows written to {TABLE_QUALITY_RULE_CONFIG}."
        )

    if dataset.get("load_type") == "FULL":
        plan.notes.append("load_type = FULL — target is truncated and reloaded on each run")

    return plan


def parse_config_file(config_path: Path | str) -> ParsePlan:
    """Read a config file from disk and parse it into a ParsePlan."""
    config_path = Path(config_path)
    with open(config_path, "r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    return parse_config(config, config_path=str(config_path))
