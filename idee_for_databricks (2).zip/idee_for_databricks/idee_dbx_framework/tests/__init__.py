"""PyTest suite for the iDEE Databricks framework."""
