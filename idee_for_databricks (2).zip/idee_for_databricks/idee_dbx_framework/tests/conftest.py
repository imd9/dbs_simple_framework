"""
Shared PyTest fixtures.

Puts src/ on the import path so tests import the framework the same way a
Databricks notebook does, without requiring an installed package.
"""

from __future__ import annotations

import copy
import sys
from pathlib import Path

import pytest
import yaml

FRAMEWORK_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = FRAMEWORK_ROOT / "src"
SCHEMA_DIR = FRAMEWORK_ROOT / "schema"
FIXTURE_DIR = Path(__file__).resolve().parent / "fixtures"
TEMPLATE_DIR = FRAMEWORK_ROOT / "templates"
APP_CONFIG_DIR = FRAMEWORK_ROOT.parent / "idee_dbx_app" / "config"

if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))


@pytest.fixture(scope="session")
def schema_dir() -> Path:
    """Directory holding the versioned schema files."""
    return SCHEMA_DIR


@pytest.fixture(scope="session")
def fixture_dir() -> Path:
    """Directory holding the test config fixtures."""
    return FIXTURE_DIR


@pytest.fixture(scope="session")
def template_path() -> Path:
    """The framework-owned blank template."""
    return TEMPLATE_DIR / "idee_pipeline_config_template.yaml"


@pytest.fixture(scope="session")
def app_config_path() -> Path:
    """The filled demo config in the application folder."""
    return APP_CONFIG_DIR / "customer_full_refresh_config.yaml"


@pytest.fixture(scope="session")
def _valid_config_raw() -> dict:
    """Parsed valid fixture, loaded once per session."""
    with open(FIXTURE_DIR / "valid_full_refresh_config.yaml", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


@pytest.fixture
def valid_config(_valid_config_raw: dict) -> dict:
    """
    A fresh deep copy of the valid config for every test.

    Deep copy matters: tests mutate this to build invalid cases, and a shared
    dict would leak those mutations between tests.
    """
    return copy.deepcopy(_valid_config_raw)
