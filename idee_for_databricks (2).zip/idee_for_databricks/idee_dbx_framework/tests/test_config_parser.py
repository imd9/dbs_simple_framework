"""
Unit tests for idee_dbx.config_parser.

Covers: row counts per table, field mapping fidelity, DQ engine branching,
deterministic rule ids, SQL rendering, and idempotency.
"""

from __future__ import annotations

import pytest

from idee_dbx.config_parser import (
    TABLE_COLUMN_CONFIG,
    TABLE_OBJECT_CONFIG,
    TABLE_QUALITY_RULE_CONFIG,
    TABLE_SOURCE_CONFIG,
    parse_config,
    parse_config_file,
)

CATALOG = "test_catalog"
METADATA_SCHEMA = "idee_metaschema"


def only_action(plan, table):
    """Return the single action for a table, asserting there is exactly one."""
    actions = plan.actions_for(table)
    assert len(actions) == 1, f"expected 1 action for {table}, got {len(actions)}"
    return actions[0]


# =============================================================================
# Row counts
# =============================================================================
class TestActionCounts:
    def test_produces_one_source_row(self, valid_config):
        plan = parse_config(valid_config)
        assert len(plan.actions_for(TABLE_SOURCE_CONFIG)) == 1

    def test_produces_one_object_row(self, valid_config):
        plan = parse_config(valid_config)
        assert len(plan.actions_for(TABLE_OBJECT_CONFIG)) == 1

    def test_produces_one_column_row_per_column(self, valid_config):
        plan = parse_config(valid_config)
        assert len(plan.actions_for(TABLE_COLUMN_CONFIG)) == len(valid_config["columns"])

    def test_column_rows_scale_with_config(self, valid_config):
        valid_config["columns"].append(
            {
                "source_column": "EXTRA",
                "target_column": "extra",
                "target_type": "STRING",
                "primary_key_indicator": False,
                "trim_indicator": True,
                "pii_classification": "PUBLIC",
                "nullable": True,
                "sequence": 3,
                "active": True,
            }
        )
        plan = parse_config(valid_config)
        assert len(plan.actions_for(TABLE_COLUMN_CONFIG)) == 3

    def test_inactive_columns_still_produce_rows(self, valid_config):
        """
        Inactive columns are recorded with active=false rather than dropped.

        Deleting them would lose the fact that the column was deliberately
        excluded, and re-activating would look like a brand new column.
        """
        valid_config["columns"][1]["active"] = False
        plan = parse_config(valid_config)
        assert len(plan.actions_for(TABLE_COLUMN_CONFIG)) == 2


# =============================================================================
# Field mapping
# =============================================================================
class TestFieldMapping:
    def test_source_fields_map_verbatim(self, valid_config):
        action = only_action(parse_config(valid_config), TABLE_SOURCE_CONFIG)
        source = valid_config["source"]
        for field in ("source_id", "source_name", "source_type", "ingestion_method", "connection_ref"):
            assert action.values[field] == source[field]

    def test_dataset_fields_map_verbatim(self, valid_config):
        action = only_action(parse_config(valid_config), TABLE_OBJECT_CONFIG)
        dataset = valid_config["dataset"]
        for field in ("object_id", "object_name", "source_path", "load_type", "bronze_table"):
            assert action.values[field] == dataset[field]

    def test_column_fields_map_verbatim(self, valid_config):
        plan = parse_config(valid_config)
        first = plan.actions_for(TABLE_COLUMN_CONFIG)[0]
        column = valid_config["columns"][0]
        assert first.values["source_column"] == column["source_column"]
        assert first.values["target_column"] == column["target_column"]
        assert first.values["primary_key_indicator"] is True

    def test_empty_strings_become_none(self, valid_config):
        """Empty YAML strings must land as SQL NULL, not as ''."""
        valid_config["dataset"]["parallel_group"] = ""
        action = only_action(parse_config(valid_config), TABLE_OBJECT_CONFIG)
        assert action.values["parallel_group"] is None

    def test_column_rows_carry_parent_object_id(self, valid_config):
        plan = parse_config(valid_config)
        object_id = valid_config["dataset"]["object_id"]
        for action in plan.actions_for(TABLE_COLUMN_CONFIG):
            assert action.values["object_id"] == object_id

    def test_booleans_survive_as_booleans(self, valid_config):
        action = only_action(parse_config(valid_config), TABLE_SOURCE_CONFIG)
        assert action.values["landing_required"] is True
        assert action.values["active"] is True


# =============================================================================
# DQ engine branching
# =============================================================================
class TestQualityEngineBranching:
    def test_inline_engine_produces_rule_rows(self, valid_config):
        plan = parse_config(valid_config)
        assert len(plan.actions_for(TABLE_QUALITY_RULE_CONFIG)) == 1

    def test_native_engine_produces_no_rule_rows(self, valid_config):
        valid_config["quality"]["engine"] = "native"
        valid_config["quality"]["rules_path"] = "dq_rules/test_object.yaml"
        plan = parse_config(valid_config)
        assert plan.actions_for(TABLE_QUALITY_RULE_CONFIG) == []

    def test_native_engine_notes_the_rules_path(self, valid_config):
        valid_config["quality"]["engine"] = "native"
        valid_config["quality"]["rules_path"] = "dq_rules/test_object.yaml"
        plan = parse_config(valid_config)
        assert any("dq_rules/test_object.yaml" in note for note in plan.notes)

    def test_gx_engine_produces_no_rule_rows(self, valid_config):
        valid_config["quality"]["engine"] = "great_expectations"
        valid_config["quality"]["suite_name"] = "test_object_suite"
        plan = parse_config(valid_config)
        assert plan.actions_for(TABLE_QUALITY_RULE_CONFIG) == []

    def test_gx_engine_notes_the_suite_name(self, valid_config):
        valid_config["quality"]["engine"] = "great_expectations"
        valid_config["quality"]["suite_name"] = "test_object_suite"
        plan = parse_config(valid_config)
        assert any("test_object_suite" in note for note in plan.notes)

    def test_inline_rule_row_tagged_with_source(self, valid_config):
        plan = parse_config(valid_config)
        action = only_action(plan, TABLE_QUALITY_RULE_CONFIG)
        assert action.values["rule_source"] == "inline"


# =============================================================================
# Rule ids
# =============================================================================
class TestRuleIds:
    def test_rule_id_is_deterministic(self, valid_config):
        """Parsing twice must yield identical ids, or MERGE would duplicate rows."""
        first = only_action(parse_config(valid_config), TABLE_QUALITY_RULE_CONFIG)
        second = only_action(parse_config(valid_config), TABLE_QUALITY_RULE_CONFIG)
        assert first.values["rule_id"] == second.values["rule_id"]

    def test_rule_id_is_prefixed_with_object_id(self, valid_config):
        action = only_action(parse_config(valid_config), TABLE_QUALITY_RULE_CONFIG)
        assert action.values["rule_id"].startswith(valid_config["dataset"]["object_id"])

    def test_rule_id_slug_is_safe(self, valid_config):
        valid_config["quality"]["rules"][0]["rule_name"] = "Check: email/format (v2)!"
        action = only_action(parse_config(valid_config), TABLE_QUALITY_RULE_CONFIG)
        rule_id = action.values["rule_id"]
        assert " " not in rule_id
        assert "__" not in rule_id.replace(f"{valid_config['dataset']['object_id']}__", "", 1)

    def test_distinct_rules_get_distinct_ids(self, valid_config):
        valid_config["quality"]["rules"].append(
            {
                "rule_name": "Name must not be null",
                "rule_expression": "name IS NOT NULL",
                "action": "warn",
                "severity": "warning",
                "active": True,
            }
        )
        plan = parse_config(valid_config)
        ids = [a.values["rule_id"] for a in plan.actions_for(TABLE_QUALITY_RULE_CONFIG)]
        assert len(ids) == len(set(ids))


# =============================================================================
# SQL rendering
# =============================================================================
class TestSqlRendering:
    def test_statement_count_matches_action_count(self, valid_config):
        plan = parse_config(valid_config)
        statements = plan.to_merge_statements(CATALOG, METADATA_SCHEMA)
        assert len(statements) == len(plan.actions)

    def test_statements_target_the_right_schema(self, valid_config):
        plan = parse_config(valid_config)
        for statement in plan.to_merge_statements(CATALOG, METADATA_SCHEMA):
            assert f"{CATALOG}.{METADATA_SCHEMA}." in statement

    def test_statements_are_merges_not_inserts(self, valid_config):
        plan = parse_config(valid_config)
        for statement in plan.to_merge_statements(CATALOG, METADATA_SCHEMA):
            assert statement.startswith("MERGE INTO")

    def test_parent_tables_render_before_children(self, valid_config):
        """FK order matters: source before object, object before column."""
        plan = parse_config(valid_config)
        statements = plan.to_merge_statements(CATALOG, METADATA_SCHEMA)
        joined = "\n".join(statements)
        assert joined.index("source_config") < joined.index("object_config")
        assert joined.index("object_config") < joined.index("column_config")

    def test_single_quotes_are_escaped(self, valid_config):
        """An apostrophe in a value must not break out of the SQL literal."""
        valid_config["source"]["source_name"] = "O'Brien Feed"
        plan = parse_config(valid_config)
        statement = plan.to_merge_statements(CATALOG, METADATA_SCHEMA)[0]
        assert "O''Brien" in statement

    def test_booleans_render_unquoted(self, valid_config):
        plan = parse_config(valid_config)
        statement = plan.to_merge_statements(CATALOG, METADATA_SCHEMA)[0]
        assert "TRUE AS active" in statement

    def test_none_renders_as_null(self, valid_config):
        valid_config["dataset"]["parallel_group"] = ""
        plan = parse_config(valid_config)
        joined = "\n".join(plan.to_merge_statements(CATALOG, METADATA_SCHEMA))
        assert "NULL AS parallel_group" in joined

    def test_catalog_is_parameterised(self, valid_config):
        """
        Nothing may be hardcoded: a different catalog must appear in the target.

        Only the MERGE target line is checked. The row payload legitimately
        contains catalog names as *data* (bronze_table, silver_table), so a
        blanket substring check would fail for the wrong reason.
        """
        plan = parse_config(valid_config)
        statements = plan.to_merge_statements("other_catalog", "other_schema")
        targets = [s.splitlines()[0] for s in statements]
        assert all(t.startswith("MERGE INTO other_catalog.other_schema.") for t in targets)
        assert not any(CATALOG in t for t in targets)


# =============================================================================
# Plan reporting and file entry point
# =============================================================================
class TestPlanAndFile:
    def test_summary_is_printable(self, valid_config):
        plan = parse_config(valid_config)
        summary = plan.summary()
        assert valid_config["dataset"]["object_id"] in summary
        assert "source_config" in summary

    def test_counts_cover_every_table(self, valid_config):
        counts = parse_config(valid_config).counts()
        assert set(counts) == {
            TABLE_SOURCE_CONFIG,
            TABLE_OBJECT_CONFIG,
            TABLE_COLUMN_CONFIG,
            TABLE_QUALITY_RULE_CONFIG,
        }

    def test_full_load_type_is_noted(self, valid_config):
        plan = parse_config(valid_config)
        assert any("FULL" in note for note in plan.notes)

    def test_parses_the_app_demo_config(self, app_config_path):
        plan = parse_config_file(app_config_path)
        assert plan.object_id == "obj_customer"
        assert len(plan.actions_for(TABLE_COLUMN_CONFIG)) == 5
        assert len(plan.actions_for(TABLE_QUALITY_RULE_CONFIG)) == 3

    def test_parsing_is_idempotent(self, app_config_path):
        """Same input, same plan — a second run must not add or change rows."""
        first = parse_config_file(app_config_path)
        second = parse_config_file(app_config_path)
        assert [a.values for a in first.actions] == [a.values for a in second.actions]


# =============================================================================
# Validator/parser contract
# =============================================================================
class TestValidatorParserContract:
    @pytest.mark.parametrize("engine", ["inline", "native", "great_expectations"])
    def test_every_valid_engine_parses(self, valid_config, schema_dir, engine):
        """Anything the validator accepts, the parser must handle."""
        from idee_dbx.config_validator import validate_config

        valid_config["quality"]["engine"] = engine
        if engine == "native":
            valid_config["quality"]["rules_path"] = "dq_rules/test_object.yaml"
        elif engine == "great_expectations":
            valid_config["quality"]["suite_name"] = "test_object_suite"

        result = validate_config(valid_config, schema_dir=schema_dir)
        assert result.is_valid, result.errors

        plan = parse_config(valid_config)
        assert len(plan.actions) >= 2  # source + object at minimum
