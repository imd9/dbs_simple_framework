"""
Unit tests for idee_dbx.config_validator.

Covers: the happy path, version handling, required fields, type checking,
enum checking, conditional requirements, and cross-field integrity checks.
Each test asserts on the specific error raised, not merely that validation
failed — otherwise a test passes for the wrong reason.
"""

from __future__ import annotations

import pytest

from idee_dbx.config_validator import (
    ValidationResult,
    load_schema,
    validate_config,
    validate_config_file,
)


def errors_mentioning(result: ValidationResult, needle: str) -> list[str]:
    """Errors containing `needle`, case-insensitively."""
    return [e for e in result.errors if needle.lower() in e.lower()]


# =============================================================================
# Happy path
# =============================================================================
class TestValidConfigs:
    def test_valid_fixture_passes(self, valid_config, schema_dir):
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert result.is_valid, f"expected valid, got: {result.errors}"
        assert result.errors == []

    def test_valid_fixture_records_versions(self, valid_config, schema_dir):
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert result.config_version == "0.1"
        assert result.schema_version == "0.1"

    def test_app_demo_config_passes(self, app_config_path, schema_dir):
        """The filled config shipped in the app folder must validate."""
        result = validate_config_file(app_config_path, schema_dir=schema_dir)
        assert result.is_valid, f"demo config failed: {result.errors}"

    def test_report_is_printable(self, valid_config, schema_dir):
        result = validate_config(valid_config, schema_dir=schema_dir)
        report = result.report()
        assert "PASSED" in report
        assert "0.1" in report


# =============================================================================
# Version handling
# =============================================================================
class TestVersioning:
    def test_missing_config_version_fails(self, valid_config, schema_dir):
        del valid_config["config_version"]
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "config_version")

    def test_unsupported_version_fails(self, fixture_dir, schema_dir):
        result = validate_config_file(
            fixture_dir / "invalid_unsupported_version_config.yaml", schema_dir=schema_dir
        )
        assert not result.is_valid
        assert errors_mentioning(result, "9.9")

    def test_load_schema_returns_expected_version(self, schema_dir):
        schema = load_schema("0.1", schema_dir)
        assert schema["schema_version"] == "0.1"
        assert "0.1" in schema["supported_config_versions"]

    def test_load_schema_raises_for_unknown_version(self, schema_dir):
        with pytest.raises(FileNotFoundError):
            load_schema("42.0", schema_dir)


# =============================================================================
# Structure and required fields
# =============================================================================
class TestRequiredFields:
    @pytest.mark.parametrize("section", ["source", "dataset", "columns", "quality"])
    def test_missing_section_fails(self, valid_config, schema_dir, section):
        del valid_config[section]
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, section)

    @pytest.mark.parametrize(
        "field", ["source_id", "source_name", "source_type", "ingestion_method", "connection_ref"]
    )
    def test_missing_source_field_fails(self, valid_config, schema_dir, field):
        del valid_config["source"][field]
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, f"source.{field}")

    @pytest.mark.parametrize("field", ["object_id", "object_name", "source_path", "bronze_table"])
    def test_missing_dataset_field_fails(self, valid_config, schema_dir, field):
        del valid_config["dataset"][field]
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, f"dataset.{field}")

    def test_empty_string_counts_as_missing(self, valid_config, schema_dir):
        valid_config["source"]["source_name"] = "   "
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "source_name")

    def test_empty_columns_list_fails(self, valid_config, schema_dir):
        valid_config["columns"] = []
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "columns")

    def test_fixture_with_missing_fields_reports_all(self, fixture_dir, schema_dir):
        result = validate_config_file(
            fixture_dir / "invalid_missing_required_config.yaml", schema_dir=schema_dir
        )
        assert not result.is_valid
        # The validator reports every problem at once rather than stopping at the first.
        assert len(result.errors) >= 3


# =============================================================================
# Types
# =============================================================================
class TestTypeChecking:
    def test_string_where_boolean_expected_fails(self, valid_config, schema_dir):
        valid_config["source"]["active"] = "yes"
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "expected boolean")

    def test_string_where_integer_expected_fails(self, valid_config, schema_dir):
        valid_config["columns"][0]["sequence"] = "first"
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "expected integer")

    def test_boolean_is_not_accepted_as_integer(self, valid_config, schema_dir):
        """bool subclasses int in Python; the validator must not be fooled."""
        valid_config["columns"][0]["sequence"] = True
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "expected integer")


# =============================================================================
# Enums
# =============================================================================
class TestEnumChecking:
    def test_invalid_source_type_fails(self, valid_config, schema_dir):
        valid_config["source"]["source_type"] = "sftp"
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "source_type")

    def test_invalid_load_type_fails(self, valid_config, schema_dir):
        valid_config["dataset"]["load_type"] = "UPSERT"
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "load_type")

    def test_invalid_target_type_fails(self, valid_config, schema_dir):
        valid_config["columns"][0]["target_type"] = "VARCHAR"
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "target_type")

    def test_invalid_pii_classification_fails(self, valid_config, schema_dir):
        valid_config["columns"][0]["pii_classification"] = "TOP_SECRET"
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "pii_classification")

    def test_invalid_dq_action_and_severity_fail(self, fixture_dir, schema_dir):
        result = validate_config_file(fixture_dir / "invalid_bad_enum_config.yaml", schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "action")
        assert errors_mentioning(result, "severity")

    def test_invalid_quality_engine_fails(self, valid_config, schema_dir):
        valid_config["quality"]["engine"] = "deequ"
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "engine")


# =============================================================================
# Conditional requirements
# =============================================================================
class TestConditionalRules:
    def test_incremental_without_watermark_fails(self, valid_config, schema_dir):
        valid_config["dataset"]["load_type"] = "INCREMENTAL"
        valid_config["dataset"]["incremental_column"] = ""
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "incremental_column")

    def test_incremental_with_watermark_passes(self, valid_config, schema_dir):
        valid_config["dataset"]["load_type"] = "INCREMENTAL"
        valid_config["dataset"]["incremental_column"] = "updated_at"
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert result.is_valid, result.errors

    @pytest.mark.parametrize("load_type", ["CDC", "SNAPSHOT"])
    def test_cdc_and_snapshot_require_primary_key(self, valid_config, schema_dir, load_type):
        valid_config["dataset"]["load_type"] = load_type
        valid_config["dataset"]["primary_key"] = ""
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "primary_key")

    def test_cloud_files_requires_base_path(self, valid_config, schema_dir):
        valid_config["source"]["base_path"] = ""
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "base_path")

    def test_native_engine_requires_rules_path(self, valid_config, schema_dir):
        valid_config["quality"]["engine"] = "native"
        valid_config["quality"]["rules_path"] = ""
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "rules_path")

    def test_native_engine_with_rules_path_passes(self, valid_config, schema_dir):
        valid_config["quality"]["engine"] = "native"
        valid_config["quality"]["rules_path"] = "dq_rules/test_object.yaml"
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert result.is_valid, result.errors

    def test_gx_engine_requires_suite_name(self, valid_config, schema_dir):
        valid_config["quality"]["engine"] = "great_expectations"
        valid_config["quality"]["suite_name"] = ""
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "suite_name")

    def test_gx_engine_with_suite_name_passes(self, valid_config, schema_dir):
        valid_config["quality"]["engine"] = "great_expectations"
        valid_config["quality"]["suite_name"] = "test_object_suite"
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert result.is_valid, result.errors

    def test_inline_engine_requires_at_least_one_rule(self, valid_config, schema_dir):
        valid_config["quality"]["rules"] = []
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "rules")


# =============================================================================
# Cross-field integrity
# =============================================================================
class TestIntegrityChecks:
    def test_mismatched_source_id_fails(self, valid_config, schema_dir):
        valid_config["dataset"]["source_id"] = "src_something_else"
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "must match")

    def test_no_active_column_fails(self, valid_config, schema_dir):
        for column in valid_config["columns"]:
            column["active"] = False
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "active")

    def test_no_primary_key_column_fails(self, valid_config, schema_dir):
        for column in valid_config["columns"]:
            column["primary_key_indicator"] = False
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "primary key")

    def test_duplicate_target_column_fails(self, valid_config, schema_dir):
        valid_config["columns"][1]["target_column"] = valid_config["columns"][0]["target_column"]
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "duplicate")

    def test_duplicate_sequence_fails(self, valid_config, schema_dir):
        valid_config["columns"][1]["sequence"] = valid_config["columns"][0]["sequence"]
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "duplicate")

    @pytest.mark.parametrize("bad_name", ["bronze_test", "idee_app.bronze_test", "a.b.c.d"])
    def test_bronze_table_must_be_three_part(self, valid_config, schema_dir, bad_name):
        valid_config["dataset"]["bronze_table"] = bad_name
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "three-part")


# =============================================================================
# Warnings (advisory, must not fail validation)
# =============================================================================
class TestWarnings:
    def test_inactive_dataset_warns_but_passes(self, valid_config, schema_dir):
        valid_config["dataset"]["active"] = False
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert result.is_valid
        assert any("skipped" in w.lower() for w in result.warnings)

    def test_missing_silver_table_warns_but_passes(self, valid_config, schema_dir):
        valid_config["dataset"]["silver_table"] = ""
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert result.is_valid
        assert any("bronze" in w.lower() for w in result.warnings)

    def test_credential_in_connection_ref_warns(self, valid_config, schema_dir):
        valid_config["source"]["connection_ref"] = "jdbc://host?password=hunter2"
        result = validate_config(valid_config, schema_dir=schema_dir)
        assert any("credential" in w.lower() for w in result.warnings)


# =============================================================================
# File handling
# =============================================================================
class TestFileHandling:
    def test_missing_file_reports_cleanly(self, schema_dir, tmp_path):
        result = validate_config_file(tmp_path / "does_not_exist.yaml", schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "not found")

    def test_malformed_yaml_reports_parse_error(self, schema_dir, tmp_path):
        bad = tmp_path / "malformed.yaml"
        bad.write_text("source:\n  - this: [is\n    broken", encoding="utf-8")
        result = validate_config_file(bad, schema_dir=schema_dir)
        assert not result.is_valid
        assert errors_mentioning(result, "parse")

    def test_empty_file_reports_cleanly(self, schema_dir, tmp_path):
        empty = tmp_path / "empty.yaml"
        empty.write_text("", encoding="utf-8")
        result = validate_config_file(empty, schema_dir=schema_dir)
        assert not result.is_valid

    def test_blank_template_does_not_pass_validation(self, template_path, schema_dir):
        """
        The blank template must NOT validate.

        It ships with placeholder text, so if it ever passed, a user could
        deploy an unfilled template and the framework would accept it.
        """
        result = validate_config_file(template_path, schema_dir=schema_dir)
        assert not result.is_valid
