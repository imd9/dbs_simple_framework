# iDEE for Databricks — Framework Overview

## Presentation Reference Document

**Version**: 0.1.0
**Date**: July 2026
**Author**: Italo Duran — Data Engineering

---

## 1. What Is This Framework?

iDEE for Databricks is a metadata-driven ELT framework. It turns a single YAML
configuration file into rows in metadata tables — no code changes, no new
pipelines, no new notebooks. One config file = one dataset onboarded.

The framework answers: **How do we onboard 50 datasets without writing 50 pipelines?**

Answer: You don't write pipelines. You fill out config files. The framework
validates them, translates them into SQL, and loads the metadata. A reusable
engine (next version) reads that metadata and moves the actual data.

---

## 2. The Three-Stage Pipeline

```
┌──────────────────────────────────────────────────────────────────┐
│  YAML Config File                                                │
│  (filled by a data engineer from a blank template)               │
└──────────────────────────────┬───────────────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│  STAGE 1: VALIDATE                                               │
│                                                                  │
│  • Loads the versioned schema matching config_version             │
│  • Checks required fields, types, enums, cross-field rules       │
│  • Reports ALL errors at once (not just the first one)           │
│  • Rejects blank templates, placeholder text, bad references     │
│  • Result: PASS or FAIL with full error list                     │
└──────────────────────────────┬───────────────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│  STAGE 2: PARSE                                                  │
│                                                                  │
│  • Translates a valid config into a plan of MERGE statements     │
│  • Maps YAML keys directly to metadata table columns             │
│  • Generates deterministic IDs (for idempotency)                 │
│  • Executes NOTHING — this is a dry-run preview                  │
│  • Result: Plan object with 10 actions across 4 tables           │
└──────────────────────────────┬───────────────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│  STAGE 3: LOAD                                                   │
│                                                                  │
│  • Executes the MERGE plan against Spark / Unity Catalog         │
│  • Supports dry-run mode (preview only)                          │
│  • Uses MERGE (not INSERT) — re-running is always safe           │
│  • Writes to: source_config, object_config, column_config,       │
│    quality_rule_config                                           │
│  • Result: SUCCESS with statement counts                         │
└──────────────────────────────────────────────────────────────────┘
```

---

## 3. Why This Design?

### 3.1 Why YAML configs instead of SQL INSERT scripts?

- YAML is human-readable and self-documenting (comments inline)
- A versioned schema catches mistakes BEFORE they reach the database
- Templates provide guardrails for new engineers
- One file describes one complete dataset — source + columns + rules together

### 3.2 Why validate before parse?

Separating validation from parsing enables a meaningful dry run. You can check
if a config is legal without generating SQL or touching any table. This is the
"shift left" principle: catch errors as early as possible.

### 3.3 Why MERGE instead of INSERT?

MERGE makes the framework idempotent. If you run the same config twice, you get
the same result — rows are upserted, not duplicated. This is essential for:
- CI/CD pipelines that re-deploy configs
- Recovery from partial failures
- Developer re-runs during debugging

### 3.4 Why a versioned schema?

The config format will evolve. But configs already deployed should not break
when the format changes. Each config declares `config_version: "0.1"` and the
validator loads the matching schema. Old configs keep working against old schemas.
New features get a new schema version. Published schemas are never edited.

### 3.5 Why framework and app are separate folders?

The framework is shared by every team. The app folder belongs to one team.
If another team would need it, it belongs in the framework.
If only one team uses it, it belongs in the app.

This separation prevents:
- Teams stepping on each other's configs
- App-specific logic contaminating shared code
- Deployment coupling between teams

### 3.6 Why deterministic rule IDs?

Quality rules need stable IDs for MERGE to work. The framework generates:
`{object_id}__{slugified_rule_name}` — e.g. `obj_customer__customer_id_must_not_be_null`

This means:
- Same config always produces same IDs
- Re-running updates existing rules (not duplicates)
- IDs are human-readable in the audit table

---

## 4. The Five Metadata Tables

| Table | What It Stores | Populated By |
|---|---|---|
| `source_config` | Source system identity: type, connection, path | Config YAML `source:` section |
| `object_config` | Dataset: name, format, load type, PK, targets | Config YAML `dataset:` section |
| `column_config` | Columns: source→target mapping, type, PK flag | Config YAML `columns:` section |
| `quality_rule_config` | DQ rules: SQL booleans, action, severity | Config YAML `quality:` section |
| `pipeline_audit` | Runtime telemetry: rows, status, errors | Written at execution time (v0.2+) |

The first four are populated by the framework parser from YAML.
The fifth (`pipeline_audit`) is written at runtime — it has no YAML source.

---

## 5. File-by-File Explanation

### Framework Source Code (`src/idee_dbx/`)

| File | Purpose | Why It Exists |
|---|---|---|
| `config_validator.py` | Checks if a config is legal against a versioned schema | Catches errors before they reach the database |
| `config_parser.py` | Translates a valid config into MERGE SQL statements | Separates "what to do" from "doing it" |
| `metadata_loader.py` | Executes the MERGE plan against Spark | Only module that touches Spark — keeps the rest testable offline |
| `main.py` | CLI entry point: `validate`, `parse`, `load` commands | Enables command-line and notebook usage |
| `__init__.py` | Package marker | Standard Python packaging |

### Schema (`schema/`)

| File | Purpose |
|---|---|
| `pipeline_config_schema_v0_1.yaml` | The validation contract for config_version 0.1 |

This is data, not code. Adding a new config format = adding a new file here.
The validator loads the right schema based on `config_version` in the config.

### Templates (`templates/`)

| File | Purpose |
|---|---|
| `idee_pipeline_config_template.yaml` | Blank template that data engineers copy and fill |

Every field has inline comments explaining what it means, what values are allowed,
and whether it's required. The framework REJECTS this template if submitted
unfilled — a safety guard against deploying placeholder text.

### DDL (`ddl/metadata/`)

| File | Purpose |
|---|---|
| `00_verify_prerequisites.sql` | Confirms catalog and schemas exist (creates nothing) |
| `01_create_source_config.sql` | Creates the source_config Delta table |
| `02_create_object_config.sql` | Creates the object_config Delta table |
| `03_create_column_config.sql` | Creates the column_config Delta table |
| `04_create_quality_rule_config.sql` | Creates the quality_rule_config Delta table |
| `05_create_pipeline_audit.sql` | Creates the pipeline_audit Delta table |
| `99_verify_metadata_tables.sql` | Confirms all 5 tables exist and reports row counts |

All scripts use `${catalog}` and `${metadata_schema}` placeholders — nothing
is hardcoded. The same scripts promote from dev to QA to prod unchanged.

### Tests (`tests/`)

| File | Purpose |
|---|---|
| `conftest.py` | Shared fixtures: paths, valid configs, deep-copy helpers |
| `test_config_validator.py` | 58 tests: versions, required fields, types, enums, conditionals, integrity, file handling |
| `test_config_parser.py` | 37 tests: action counts, field mapping, quality engines, rule IDs, SQL rendering |
| `fixtures/valid_*.yaml` | Known-good config for test baseline |
| `fixtures/invalid_*.yaml` | Known-bad configs for negative testing |

95 tests total. They run offline (no Spark needed) in ~7 seconds.

### Notebooks (`notebooks/`)

| File | Purpose |
|---|---|
| `run_config_pipeline` | Interactive validate→parse→load with widgets |
| `iDEE Framework End to End Validation` | Full test suite: PyTest + DDL + dry run + live load + idempotency |

### Documentation (`docs/`)

| File | Purpose |
|---|---|
| `TESTING_GUIDE.md` | Step-by-step guide for building a test notebook |
| `NAMING_CONVENTIONS.md` | .yaml vs .yml, folder names, SQL naming, IDs |

### Root Files

| File | Purpose |
|---|---|
| `README.md` | Architecture, quick start, design principles |
| `CHANGELOG.md` | Version history and versioning policy |
| `VERSION` | Current framework version (0.1.0) |
| `requirements.txt` | Dependencies: PyYAML, pytest |
| `pytest.ini` | Test configuration: paths, verbosity, markers |

---

## 6. The Application Folder (`idee_dbx_app/`)

This is NOT the framework — it's a sample consumer.

| Subfolder | Contents |
|---|---|
| `config/` | Filled YAML configs (customer_full_refresh_config.yaml) |
| `ddl/` | App-specific DDL: bronze_customer, silver_customer, quarantine_customer |
| `data/` | Sample CSV files for testing |
| `notebooks/` | Demo notebook for running a sample pipeline |
| `output/` | Generated artifacts |

Key point: **metadata DDL lives in the framework**. Business table DDL lives
in the app. They go to different schemas (`idee_metaschema` vs `idee_app`).

---

## 7. Design Principles

1. **One complete unit at a time.** A small working path beats several half-built components.
2. **Framework and application stay separate.** Shared logic on one side, app-specific on the other.
3. **Nothing hardcoded.** Catalog and schema are parameters everywhere.
4. **Configs are versioned.** Each declares config_version; the validator loads the matching schema.
5. **Validate before parse, parse before load.** Separating stages enables meaningful dry runs.
6. **Repo-shaped from day one.** The move to Bitbucket should be a copy, not a redesign.

---

## 8. What v0.1 Does and Does NOT Do

| What v0.1 Does | What v0.1 Does NOT Do |
|---|---|
| Validates YAML configs against schema | Move actual data (no ingestion engine) |
| Generates MERGE SQL from configs | Execute DQ rules against data |
| Loads metadata into Delta tables | Build Bronze/Silver/Gold tables |
| Proves idempotent re-runs | Handle incremental/CDC/append loads |
| Runs 95 unit tests offline | CI/CD deployment (needs Bitbucket) |

The scope is deliberate: prove the config path end-to-end before building on top.

---

## 9. Roadmap

| Increment | Status |
|---|---|
| Config → validate → parse → metadata load | ✅ v0.1.0 |
| Bronze ingestion (Auto Loader, full refresh) | next |
| Silver transformation driven by column_config | after Bronze |
| DQ runtime enforcement (native / GX engines) | after Silver |
| Append, incremental, CDC runtime | after full refresh |
| Asset Bundles and CI/CD | blocked on Bitbucket |

---

## 10. How to Explain This in a Presentation

**Opening statement:**
"We built a framework where onboarding a new dataset means filling out one YAML file.
No new pipeline. No new notebook. No code change. Configuration only."

**Key demo moments:**
1. Show the blank template — explain every field is documented
2. Show the filled config (customer) — explain it maps 1:1 to metadata tables
3. Run validate — show it catches bad input (5 mutation tests)
4. Run parse — show the generated SQL without executing
5. Run load — show rows appear in Unity Catalog
6. Run load again — show counts don't double (MERGE idempotency)

**Closing statement:**
"v0.1 proves the config path end-to-end. The next increment adds the ingestion
engine that reads these metadata tables and actually moves data through
Bronze, Silver, and Gold. The metadata is the instruction book. The engine
just follows instructions."
