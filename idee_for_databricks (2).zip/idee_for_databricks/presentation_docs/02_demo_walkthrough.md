# Demo Walkthrough — iDEE Framework End-to-End Validation

## Presentation Demo Script

This document walks through the validation notebook cell by cell,
explaining what to say at each step during the live demo.

---

## Pre-Demo Setup

- Notebook: `iDEE Framework End to End Validation`
- Location: `idee_dbx_framework/notebooks/`
- Compute: Serverless (CPU) or any attached cluster
- Time required: ~3 minutes for full run

---

## Cell-by-Cell Demo Script

### Cell 1 — Title (Markdown)

**What to say:** "This notebook proves the entire framework works end-to-end.
It runs 95 unit tests, creates the metadata tables, validates a sample config,
loads it for real, and then proves that re-running doesn't duplicate anything."

---

### Cell 2 — Setup Paths

**What to say:** "First we set the paths. The framework and app folders are
separate — the framework is reusable shared code, the app folder is where
teams put their filled configs."

**Expected output:**
```
PROJECT_ROOT:    /Workspace/Users/.../idee_for_databricks
FRAMEWORK:       .../idee_dbx_framework
APP:             .../idee_dbx_app
CATALOG:         medtech_md_scion_dev
METADATA_SCHEMA: idee_metaschema
```

**Key point:** Catalog and schema are parameters, never hardcoded.

---

### Cell 3 — Phase 1: Confirm Folder Layout

**What to say:** "Phase 1 just confirms the folders exist. This is the sanity
check that proves we're pointed at the right workspace location."

**Expected output:**
```
Framework: FOUND
App: FOUND

Framework contents:
  CHANGELOG.md, README.md, VERSION, ddl, docs, notebooks,
  pytest.ini, requirements.txt, schema, src, templates, tests
```

**Key point:** The framework is repo-shaped. When we move to Bitbucket,
this exact structure becomes the repo.

---

### Cells 4-6 — Install Dependencies + Restart

**What to say:** "We install PyYAML and pytest, then restart the Python
process to pick them up. This is a Databricks quirk — after pip install
you need to restart the kernel."

**Key point:** Only two dependencies. The framework is intentionally lightweight.

---

### Cell 7 — Phase 3: Run 95 Unit Tests

**What to say:** "Now we run the full PyTest suite. 95 tests covering the
validator and parser. These test every edge case: missing fields, wrong types,
bad enums, version mismatches, cross-field rules, duplicate columns,
SQL rendering, and more."

**Expected output:**
```
tests/test_config_parser.py::TestActionCounts::test_produces_one_source_row PASSED
tests/test_config_parser.py::TestActionCounts::test_produces_one_object_row PASSED
... (95 lines) ...

============================== 95 passed in 6.90s ==============================

✅ ALL TESTS PASSED — framework code is healthy.
```

**Key point:** These tests run OFFLINE — no Spark, no database. Pure Python
unit tests that prove the logic is correct before we touch any catalog.

---

### Cell 8 — Phase 5: Validator Rejects Bad Input

**What to say:** "Now we prove the validator catches real problems. We take a
valid config and deliberately break it five different ways. Each one SHOULD
fail with a clear error message."

**Expected output:**
```
--- Illegal load_type --- ❌ FAILED
   Error: 'UPSERT' is not allowed. Use one of: ['FULL', 'INCREMENTAL', 'CDC', 'SNAPSHOT']

--- INCREMENTAL, no watermark --- ❌ FAILED
   Error: required because incremental load requires a watermark column

--- Two-part table name --- ❌ FAILED
   Error: must be a three-part name (catalog.schema.table)

--- Mismatched source_id --- ❌ FAILED
   Error: dataset.source_id ('src_wrong') must match source.source_id ('src_customer_files')

--- Duplicate column name --- ❌ FAILED
   Error: duplicate value(s) ['customer_id'] — must be unique
```

**Key point:** The framework fails LOUDLY and CLEARLY. No silent corruption.
Every error tells you exactly what's wrong and where.

---

### Cell 9 — Phase 5b: Template Rejection

**What to say:** "And here's a safety guard — the blank template itself is
rejected if someone tries to deploy it without filling it in. 13 errors,
all about placeholder text that was never replaced."

**Expected output:**
```
✅ CORRECT: Blank template is rejected (as expected).
   13 error(s) found.
   • source.source_id: still contains template placeholder text
   • source.source_name: still contains template placeholder text
   ...
```

**Key point:** You cannot accidentally deploy an unfilled template.

---

### Cells 10-12 — Phase 6: Create Metadata Tables

**What to say:** "Now we switch from offline testing to live Databricks.
First we verify the schemas exist, then we run the DDL scripts to create
the five metadata tables."

**Expected output (Cell 10):**
```
| catalog_name          | schema_name      | schema_status |
| medtech_md_scion_dev  | idee_app         | FOUND         |
| medtech_md_scion_dev  | idee_metaschema  | FOUND         |
```

**Expected output (Cell 11):**
```
Running 01_create_source_config.sql ... ✅ OK
Running 02_create_object_config.sql ... ✅ OK
Running 03_create_column_config.sql ... ✅ OK
Running 04_create_quality_rule_config.sql ... ✅ OK
Running 05_create_pipeline_audit.sql ... ✅ OK

All metadata tables created.
```

**Expected output (Cell 12):**
```
| table_name           | row_count |
| column_config        | 0         |
| object_config        | 0         |
| pipeline_audit       | 0         |
| quality_rule_config  | 0         |
| source_config        | 0         |
```

**Key point:** DDL scripts use parameter substitution — same scripts for
dev, QA, and prod. Tables start empty. The YAML configs will populate them.

---

### Cell 13 — Phase 7: Dry Run

**What to say:** "Now the real demo. We take the customer config and run
validate + parse + preview. This shows you EXACTLY what SQL would execute
— without writing a single row."

**Expected output:**
```
STEP 1 — VALIDATE           Result: PASSED
STEP 2 — PARSE              10 planned actions across 4 tables

Planned metadata actions:
  source_config          1 row(s)
  object_config          1 row(s)
  column_config          5 row(s)
  quality_rule_config    3 row(s)

STEP 3 — GENERATED MERGE SQL:
  MERGE INTO ... source_config ...
  MERGE INTO ... object_config ...
  MERGE INTO ... column_config ... (x5)
  MERGE INTO ... quality_rule_config ... (x3)

✅ DRY RUN COMPLETE — nothing was written.
```

**Key point:** You can preview everything before committing. This is the
safety net. Show the audience the actual MERGE SQL — it's readable and
clear.

---

### Cell 14 — Phase 8: Live Load

**What to say:** "Now we execute for real. Same plan, but this time it
writes to the catalog."

**Expected output:**
```
LIVE LOAD — writing metadata to catalog
Target      : medtech_md_scion_dev.idee_metaschema
Mode        : LIVE
Statements  : 10 run, 0 failed
Result      : SUCCESS

✅ LIVE LOAD COMPLETE.
```

**Key point:** 10 MERGEs, 0 failures. The config is now live metadata.

---

### Cells 15-16 — Phase 8b/8c: Verify

**What to say:** "Let's confirm what was written."

**Expected output:**
```
source_config          = 1 rows
object_config          = 1 rows
column_config          = 5 rows
quality_rule_config    = 3 rows

Expected: 1 / 1 / 5 / 3
```

**And the join query shows:**
```
| object_id    | object_name | load_type | bronze_table                              | column_count |
| obj_customer | customer    | FULL      | medtech_md_scion_dev.idee_app.bronze_... | 5            |
```

**Key point:** One YAML file became 10 metadata rows across 4 tables.
No code. No SQL written by hand. Configuration only.

---

### Cell 17 — Phase 9: Idempotency

**What to say:** "And the final proof. We run the SAME load a second time.
If this were INSERT, we'd get 20 rows. But because it's MERGE with
deterministic IDs, we still have exactly 10."

**Expected output:**
```
Running the same load a SECOND time to prove idempotency...

  ✅ source_config          = 1 rows (expected 1)
  ✅ object_config          = 1 rows (expected 1)
  ✅ column_config          = 5 rows (expected 5)
  ✅ quality_rule_config    = 3 rows (expected 3)

✅ IDEMPOTENCY CONFIRMED — second run did NOT duplicate rows.
   Framework uses MERGE (not INSERT) and deterministic rule_ids.
   Safe to re-run configs in CI/CD without metadata corruption.
```

**Key point:** This is critical for production. You can re-run any config
anytime — in CI/CD, after a failure, during debugging — without corruption.

---

## Closing the Demo

**What to say:**

"To summarize what we just proved:

1. 95 unit tests pass — the framework logic is correct
2. The validator catches 5+ categories of configuration errors
3. Blank templates cannot be deployed accidentally
4. Metadata tables are created cleanly from DDL
5. A YAML config becomes 10 metadata rows with zero code
6. Re-running is always safe — MERGE + deterministic IDs = idempotent

The next step is building the ingestion engine that READS these metadata
tables and moves actual data through Bronze, Silver, and Gold. The metadata
is the instruction book. We just proved the instruction book works."

---

## Common Questions and Answers

**Q: Why not just use SQL INSERT scripts?**
A: YAML is human-readable, self-documenting, versionable, and validatable
before execution. SQL INSERT scripts have no validation layer.

**Q: What if the config format needs to change?**
A: Add a new schema file. Old configs keep working on old versions.
No breaking changes.

**Q: How do you onboard a second dataset?**
A: Copy the template, fill it in, run validate + load. No code changes.

**Q: When does actual data move?**
A: v0.2 adds the ingestion engine. It reads object_config, column_config,
and quality_rule_config at runtime to drive Bronze and Silver processing.

**Q: Is this tied to SCION?**
A: No. The framework is general-purpose. SCION is the first proof of concept.
Any team with a Databricks catalog can use it.
