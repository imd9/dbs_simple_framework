-- =============================================================================
-- 01_create_bronze_customer.sql
-- =============================================================================
-- Bronze target for the customer demo pipeline (DDL Auto Creation mode).
--
-- OWNER      : Application team. This is app-specific, not framework code.
-- SCHEMA     : medtech_md_scion_dev.idee_app
-- LAYER      : Bronze
--
-- This DDL is used when allow_select_star = false. Column names match the
-- TARGET column names defined in the YAML columns section (after rename/cast).
-- The framework creates this table BEFORE writing data.
--
-- To exclude a column: remove it here AND comment it out in the YAML.
-- =============================================================================

CREATE TABLE IF NOT EXISTS medtech_md_scion_dev.idee_app.bronze_customer (
    customer_id          STRING    NOT NULL  COMMENT 'Customer identifier.',
    customer_name        STRING    NOT NULL  COMMENT 'Customer display name.',
    email                STRING              COMMENT 'Contact email address.',
    country_code         STRING              COMMENT 'ISO country code.',
    created_date         TIMESTAMP           COMMENT 'Account creation date.',
    _ingested_at         TIMESTAMP NOT NULL  COMMENT 'When the row was ingested by the pipeline.'
)
USING DELTA
COMMENT 'Bronze: customer data with column mapping applied. DDL Auto Creation demo.'
TBLPROPERTIES (
    'idee.table_role' = 'bronze',
    'idee.pipeline'   = 'Customers (DDL Auto Creation)',
    'idee.owner'      = 'application'
);
