# Databricks notebook source
# DBTITLE 1,Cell 1
# MAGIC %md
# MAGIC # iDEE Pipeline Runner — V2
# MAGIC
# MAGIC Runs a V2 YAML config file through the framework:
# MAGIC 1. **Validates** the config structure
# MAGIC 2. **Generates IDs** deterministically (pipeline_id, source_id, dataset_id)
# MAGIC 3. **Loads metadata** into the `idee_metaschema` tables via MERGE
# MAGIC
# MAGIC One YAML file = one pipeline. IDs are auto-generated. `allow_select_star = true` skips column mapping.

# COMMAND ----------

# DBTITLE 1,Cell 2
dbutils.widgets.text("catalog", "medtech_md_scion_dev", "1. Catalog")
dbutils.widgets.text("metadata_schema", "idee_metaschema", "2. Metadata schema")
dbutils.widgets.text("app_schema", "idee_app", "3. Application schema")
dbutils.widgets.dropdown("dry_run", "true", ["true", "false"], "4. Dry run")

CATALOG = dbutils.widgets.get("catalog")
METADATA_SCHEMA = dbutils.widgets.get("metadata_schema")
APP_SCHEMA = dbutils.widgets.get("app_schema")
DRY_RUN = dbutils.widgets.get("dry_run") == "True"
#print(DRY_RUN)

#CONFIG_PATH = "../config/Customers (DDL Auto Creation).yaml"
#CONFIG_PATH = "../config/Customers (Select *).yaml"
CONFIG_PATH = "../config/Customers (Custom Notebook).yaml"

# COMMAND ----------

# DBTITLE 1,V2 Framework Logic
import hashlib
import yaml
from pathlib import Path
from datetime import datetime

# ---------------------------------------------------------------------------
# V2 Framework Logic — inline for now, will move to framework package later
# ---------------------------------------------------------------------------

def load_yaml(config_path: str) -> dict:
    """Load and return parsed YAML config."""
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def generate_id(*parts: str) -> str:
    """Generate a deterministic 12-char ID from input parts."""
    raw = "|".join(str(p) for p in parts if p)
    return hashlib.md5(raw.encode()).hexdigest()[:12]


def validate_v2_config(config: dict, config_path: str) -> list:
    """Validate V2 YAML structure. Returns list of errors (empty = valid)."""
    errors = []

    # Required top-level sections
    for section in ["pipeline", "source", "target", "dataset"]:
        if section not in config:
            errors.append(f"Missing required section: '{section}'")

    if errors:
        return errors  # Can't validate further without sections

    # Pipeline section
    if not config["pipeline"].get("pipeline_name"):
        errors.append("pipeline.pipeline_name is required")

    # Source section
    src = config["source"]
    if not src.get("source_name"):
        errors.append("source.source_name is required")
    if not src.get("source_type"):
        errors.append("source.source_type is required")
    valid_source_types = ["cloud_files", "jdbc", "lakeflow_connect", "kafka", "api"]
    if src.get("source_type") and src["source_type"] not in valid_source_types:
        errors.append(f"source.source_type must be one of: {valid_source_types}")

    # Target section
    tgt = config["target"]
    if not tgt.get("target_name"):
        errors.append("target.target_name is required")
    if not tgt.get("target_type"):
        errors.append("target.target_type is required")
    if tgt.get("target_type") == "delta_table" and not tgt.get("target_table"):
        errors.append("target.target_table is required when target_type is delta_table")

    # Dataset section
    ds = config["dataset"]
    if not ds.get("object_name"):
        errors.append("dataset.object_name is required")
    if not ds.get("load_type"):
        errors.append("dataset.load_type is required")
    valid_load_types = ["FULL", "INCREMENTAL", "CDC", "SNAPSHOT"]
    if ds.get("load_type") and ds["load_type"] not in valid_load_types:
        errors.append(f"dataset.load_type must be one of: {valid_load_types}")
    if ds.get("load_type") == "INCREMENTAL" and not ds.get("incremental_column"):
        errors.append("dataset.incremental_column required for INCREMENTAL load_type")

    # Columns required only when allow_select_star=false AND allow_custom_notebook=false
    if not ds.get("allow_select_star", False) and not ds.get("allow_custom_notebook", False):
        cols = config.get("columns", [])
        if not cols:
            errors.append("columns section required when allow_select_star and allow_custom_notebook are both false")
        else:
            for i, col in enumerate(cols):
                for field in ["source_column", "target_column", "target_type"]:
                    if not col.get(field):
                        errors.append(f"columns[{i}].{field} is required")

    # Custom notebook path required when allow_custom_notebook is true
    if ds.get("allow_custom_notebook", False):
        if not ds.get("notebook_path"):
            errors.append("dataset.notebook_path is required when allow_custom_notebook is true")

    return errors


def build_merge_statements(config: dict, config_path: str, catalog: str, schema: str) -> list:
    """
    Build MERGE statements for V2 metadata tables.
    Generates IDs deterministically from config content.
    Returns list of (table_name, sql_statement) tuples.
    """
    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    config_file = str(Path(config_path).resolve())

    pipe = config["pipeline"]
    src = config["source"]
    tgt = config["target"]
    ds = config["dataset"]

    # Generate deterministic IDs
    pipeline_id = generate_id(config_file)
    source_id = generate_id(src.get("connection_ref", ""), src.get("root_path", ""))
    target_id = generate_id(pipeline_id, tgt.get("target_table", ""), tgt.get("target_path", ""))
    dataset_id = generate_id(pipeline_id, ds["object_name"])

    prefix = f"{catalog}.{schema}"
    statements = []

    # 1. pipeline_config
    statements.append(("pipeline_config", f"""
        MERGE INTO {prefix}.pipeline_config AS tgt
        USING (SELECT '{pipeline_id}' AS pipeline_id) AS src
        ON tgt.pipeline_id = src.pipeline_id
        WHEN MATCHED THEN UPDATE SET
            pipeline_name = '{_esc(pipe["pipeline_name"])}',
            description = '{_esc(pipe.get("description", ""))}',
            config_file_path = '{_esc(config_file)}',
            updated_at = '{now}'
        WHEN NOT MATCHED THEN INSERT (
            pipeline_id, pipeline_name, description, config_file_path, created_at, updated_at
        ) VALUES (
            '{pipeline_id}', '{_esc(pipe["pipeline_name"])}', '{_esc(pipe.get("description", ""))}',
            '{_esc(config_file)}', '{now}', '{now}'
        )
    """))

    # 2. source_config
    statements.append(("source_config", f"""
        MERGE INTO {prefix}.source_config AS tgt
        USING (SELECT '{source_id}' AS source_id) AS src
        ON tgt.source_id = src.source_id
        WHEN MATCHED THEN UPDATE SET
            pipeline_id = '{pipeline_id}',
            source_name = '{_esc(src["source_name"])}',
            source_description = '{_esc(src.get("source_description", ""))}',
            source_type = '{src["source_type"]}',
            connection_ref = '{_esc(src.get("connection_ref", ""))}',
            root_path = '{_esc(src.get("root_path", ""))}',
            file_format = '{src.get("file_format", "")}',
            landing_required = {str(src.get("landing_required", False)).lower()},
            config_file_path = '{_esc(config_file)}',
            updated_at = '{now}'
        WHEN NOT MATCHED THEN INSERT (
            source_id, pipeline_id, source_name, source_description, source_type,
            connection_ref, root_path, file_format, landing_required, config_file_path,
            created_at, updated_at
        ) VALUES (
            '{source_id}', '{pipeline_id}', '{_esc(src["source_name"])}',
            '{_esc(src.get("source_description", ""))}', '{src["source_type"]}',
            '{_esc(src.get("connection_ref", ""))}', '{_esc(src.get("root_path", ""))}',
            '{src.get("file_format", "")}', {str(src.get("landing_required", False)).lower()},
            '{_esc(config_file)}', '{now}', '{now}'
        )
    """))

    # 3. target_config
    statements.append(("target_config", f"""
        MERGE INTO {prefix}.target_config AS tgt
        USING (SELECT '{target_id}' AS target_id) AS src
        ON tgt.target_id = src.target_id
        WHEN MATCHED THEN UPDATE SET
            pipeline_id = '{pipeline_id}',
            target_name = '{_esc(tgt["target_name"])}',
            target_type = '{tgt["target_type"]}',
            target_table = '{_esc(tgt.get("target_table", ""))}',
            target_path = '{_esc(tgt.get("target_path", ""))}',
            config_file_path = '{_esc(config_file)}',
            updated_at = '{now}'
        WHEN NOT MATCHED THEN INSERT (
            target_id, pipeline_id, target_name, target_type, target_table,
            target_path, config_file_path, created_at, updated_at
        ) VALUES (
            '{target_id}', '{pipeline_id}', '{_esc(tgt["target_name"])}',
            '{tgt["target_type"]}', '{_esc(tgt.get("target_table", ""))}',
            '{_esc(tgt.get("target_path", ""))}', '{_esc(config_file)}', '{now}', '{now}'
        )
    """))

    # 4. dataset_config
    pk_str = ",".join(ds.get("primary_key", [])) if isinstance(ds.get("primary_key"), list) else ds.get("primary_key", "")
    statements.append(("dataset_config", f"""
        MERGE INTO {prefix}.dataset_config AS tgt
        USING (SELECT '{dataset_id}' AS dataset_id) AS src
        ON tgt.dataset_id = src.dataset_id
        WHEN MATCHED THEN UPDATE SET
            pipeline_id = '{pipeline_id}',
            object_name = '{_esc(ds["object_name"])}',
            description = '{_esc(ds.get("description", ""))}',
            ingestion_method = '{ds.get("ingestion_method", "")}',
            load_type = '{ds["load_type"]}',
            primary_key = '{pk_str}',
            incremental_column = '{ds.get("incremental_column", "")}',
            source_path = '{_esc(ds.get("source_path", ""))}',
            allow_select_star = {str(ds.get("allow_select_star", False)).lower()},
            allow_custom_notebook = {str(ds.get("allow_custom_notebook", False)).lower()},
            notebook_path = '{_esc(ds.get("notebook_path", ""))}',
            trim_all = {str(ds.get("trim_all", False)).lower()},
            config_file_path = '{_esc(config_file)}',
            updated_at = '{now}'
        WHEN NOT MATCHED THEN INSERT (
            dataset_id, pipeline_id, object_name, description, ingestion_method,
            load_type, primary_key, incremental_column, source_path,
            allow_select_star, allow_custom_notebook, notebook_path, trim_all,
            config_file_path, created_at, updated_at
        ) VALUES (
            '{dataset_id}', '{pipeline_id}', '{_esc(ds["object_name"])}',
            '{_esc(ds.get("description", ""))}', '{ds.get("ingestion_method", "")}',
            '{ds["load_type"]}', '{pk_str}', '{ds.get("incremental_column", "")}',
            '{_esc(ds.get("source_path", ""))}',
            {str(ds.get("allow_select_star", False)).lower()},
            {str(ds.get("allow_custom_notebook", False)).lower()},
            '{_esc(ds.get("notebook_path", ""))}',
            {str(ds.get("trim_all", False)).lower()},
            '{_esc(config_file)}', '{now}', '{now}'
        )
    """))

    # 5. column_config (only for DDL Auto Creation: select_star=false AND custom_notebook=false)
    if not ds.get("allow_select_star", False) and not ds.get("allow_custom_notebook", False):
        for col in config.get("columns", []):
            col_id = generate_id(dataset_id, col["source_column"])
            statements.append(("column_config", f"""
                MERGE INTO {prefix}.column_config AS tgt
                USING (SELECT '{dataset_id}' AS dataset_id, '{col["source_column"]}' AS source_column) AS src
                ON tgt.dataset_id = src.dataset_id AND tgt.source_column = src.source_column
                WHEN MATCHED THEN UPDATE SET
                    target_column = '{col["target_column"]}',
                    target_type = '{col["target_type"]}',
                    config_file_path = '{_esc(config_file)}'
                WHEN NOT MATCHED THEN INSERT (
                    dataset_id, pipeline_id, source_column, target_column, target_type,
                    config_file_path, created_at
                ) VALUES (
                    '{dataset_id}', '{pipeline_id}', '{col["source_column"]}',
                    '{col["target_column"]}', '{col["target_type"]}',
                    '{_esc(config_file)}', '{now}'
                )
            """))

    # 6. quality_rule_config
    quality = config.get("quality", {})
    if quality.get("engine") == "inline" and quality.get("rules"):
        for rule in quality["rules"]:
            rule_id = generate_id(dataset_id, rule["rule_name"])
            statements.append(("quality_rule_config", f"""
                MERGE INTO {prefix}.quality_rule_config AS tgt
                USING (SELECT '{rule_id}' AS rule_id) AS src
                ON tgt.rule_id = src.rule_id
                WHEN MATCHED THEN UPDATE SET
                    dataset_id = '{dataset_id}',
                    pipeline_id = '{pipeline_id}',
                    rule_name = '{_esc(rule["rule_name"])}',
                    rule_expression = '{_esc(rule["rule_expression"])}',
                    action = '{rule["action"]}',
                    severity = '{rule["severity"]}',
                    rule_source = 'inline',
                    config_file_path = '{_esc(config_file)}',
                    updated_at = '{now}'
                WHEN NOT MATCHED THEN INSERT (
                    rule_id, dataset_id, pipeline_id, rule_name, rule_expression,
                    action, severity, rule_source, config_file_path, created_at, updated_at
                ) VALUES (
                    '{rule_id}', '{dataset_id}', '{pipeline_id}',
                    '{_esc(rule["rule_name"])}', '{_esc(rule["rule_expression"])}',
                    '{rule["action"]}', '{rule["severity"]}', 'inline',
                    '{_esc(config_file)}', '{now}', '{now}'
                )
            """))

    return statements


def _esc(val: str) -> str:
    """Escape single quotes for SQL string literals."""
    if val is None:
        return ""
    return str(val).replace("'", "''")

# COMMAND ----------

# DBTITLE 1,Reset metadata tables
# MAGIC %sql
# MAGIC -- V2 Metadata Schema: Drop and recreate for clean slate
# MAGIC DROP TABLE IF EXISTS medtech_md_scion_dev.idee_metaschema.pipeline_config;
# MAGIC DROP TABLE IF EXISTS medtech_md_scion_dev.idee_metaschema.source_config;
# MAGIC DROP TABLE IF EXISTS medtech_md_scion_dev.idee_metaschema.target_config;
# MAGIC DROP TABLE IF EXISTS medtech_md_scion_dev.idee_metaschema.dataset_config;
# MAGIC DROP TABLE IF EXISTS medtech_md_scion_dev.idee_metaschema.column_config;
# MAGIC DROP TABLE IF EXISTS medtech_md_scion_dev.idee_metaschema.quality_rule_config;
# MAGIC DROP TABLE IF EXISTS medtech_md_scion_dev.idee_metaschema.pipeline_audit;
# MAGIC DROP TABLE IF EXISTS medtech_md_scion_dev.idee_metaschema.object_config;
# MAGIC
# MAGIC -- 1. pipeline_config (NEW in V2)
# MAGIC CREATE TABLE medtech_md_scion_dev.idee_metaschema.pipeline_config (
# MAGIC   pipeline_id      STRING    NOT NULL  COMMENT 'Auto-generated from config file path',
# MAGIC   pipeline_name    STRING    NOT NULL  COMMENT 'User-friendly pipeline name',
# MAGIC   description      STRING              COMMENT 'What this pipeline does',
# MAGIC   config_file_path STRING              COMMENT 'YAML file that produced this row',
# MAGIC   created_at       TIMESTAMP           COMMENT 'Row creation timestamp',
# MAGIC   updated_at       TIMESTAMP           COMMENT 'Last modification timestamp'
# MAGIC ) USING DELTA
# MAGIC COMMENT 'One row per pipeline. One YAML = one pipeline.'
# MAGIC TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');
# MAGIC
# MAGIC -- 2. source_config (V2: adds pipeline_id, source_description, root_path; removes ingestion_method, active)
# MAGIC CREATE TABLE medtech_md_scion_dev.idee_metaschema.source_config (
# MAGIC   source_id          STRING    NOT NULL  COMMENT 'Auto-generated from connection_ref + root_path',
# MAGIC   pipeline_id        STRING    NOT NULL  COMMENT 'FK to pipeline_config',
# MAGIC   source_name        STRING    NOT NULL  COMMENT 'User-friendly label',
# MAGIC   source_description STRING              COMMENT 'What this source provides',
# MAGIC   source_type        STRING    NOT NULL  COMMENT 'cloud_files | jdbc | lakeflow_connect | kafka | api',
# MAGIC   connection_ref     STRING              COMMENT 'UC connection name',
# MAGIC   root_path          STRING              COMMENT 'Root storage path for file sources',
# MAGIC   file_format        STRING              COMMENT 'csv | json | parquet | delta | avro',
# MAGIC   landing_required   BOOLEAN             COMMENT 'true = files land in staging before processing',
# MAGIC   config_file_path   STRING              COMMENT 'YAML file that produced this row',
# MAGIC   created_at         TIMESTAMP           COMMENT 'Row creation timestamp',
# MAGIC   updated_at         TIMESTAMP           COMMENT 'Last modification timestamp'
# MAGIC ) USING DELTA
# MAGIC COMMENT 'One row per source. Defines where data comes from.'
# MAGIC TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');
# MAGIC
# MAGIC -- 3. target_config (NEW in V2)
# MAGIC CREATE TABLE medtech_md_scion_dev.idee_metaschema.target_config (
# MAGIC   target_id        STRING    NOT NULL  COMMENT 'Auto-generated from pipeline + target details',
# MAGIC   pipeline_id      STRING    NOT NULL  COMMENT 'FK to pipeline_config',
# MAGIC   target_name      STRING    NOT NULL  COMMENT 'User-friendly label',
# MAGIC   target_type      STRING    NOT NULL  COMMENT 'delta_table | s3 | adls | jdbc',
# MAGIC   target_table     STRING              COMMENT 'Fully qualified table name (for delta_table type)',
# MAGIC   target_path      STRING              COMMENT 'Storage path (for file-based targets)',
# MAGIC   config_file_path STRING              COMMENT 'YAML file that produced this row',
# MAGIC   created_at       TIMESTAMP           COMMENT 'Row creation timestamp',
# MAGIC   updated_at       TIMESTAMP           COMMENT 'Last modification timestamp'
# MAGIC ) USING DELTA
# MAGIC COMMENT 'One row per target. Defines where data goes. 1 source : 1 target per pipeline.'
# MAGIC TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');
# MAGIC
# MAGIC -- 4. dataset_config (replaces object_config; V2: adds allow_select_star, trim_all, pipeline_id)
# MAGIC CREATE TABLE medtech_md_scion_dev.idee_metaschema.dataset_config (
# MAGIC   dataset_id         STRING    NOT NULL  COMMENT 'Auto-generated from pipeline + object_name',
# MAGIC   pipeline_id        STRING    NOT NULL  COMMENT 'FK to pipeline_config',
# MAGIC   object_name        STRING    NOT NULL  COMMENT 'Logical dataset name',
# MAGIC   description        STRING              COMMENT 'What this dataset represents',
# MAGIC   ingestion_method   STRING              COMMENT 'autoloader | jdbc | lakeflow_connect | kafka | api',
# MAGIC   load_type          STRING    NOT NULL  COMMENT 'FULL | INCREMENTAL | CDC | SNAPSHOT',
# MAGIC   primary_key        STRING              COMMENT 'Comma-separated business key columns',
# MAGIC   incremental_column STRING              COMMENT 'Watermark column for INCREMENTAL loads',
# MAGIC   source_path        STRING              COMMENT 'Subfolder/pattern within source root_path',
# MAGIC   allow_select_star  BOOLEAN             COMMENT 'true = pass all source columns through, skip column_config',
# MAGIC   allow_custom_notebook BOOLEAN           COMMENT 'true = delegate transform to user notebook',
# MAGIC   notebook_path      STRING              COMMENT 'Workspace path to custom transform notebook',
# MAGIC   trim_all           BOOLEAN             COMMENT 'true = trim all string columns',
# MAGIC   config_file_path   STRING              COMMENT 'YAML file that produced this row',
# MAGIC   created_at         TIMESTAMP           COMMENT 'Row creation timestamp',
# MAGIC   updated_at         TIMESTAMP           COMMENT 'Last modification timestamp'
# MAGIC ) USING DELTA
# MAGIC COMMENT 'One row per dataset. Defines how data is processed.'
# MAGIC TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');
# MAGIC
# MAGIC -- 5. column_config (V2: simplified to 3 core fields + metadata)
# MAGIC CREATE TABLE medtech_md_scion_dev.idee_metaschema.column_config (
# MAGIC   dataset_id       STRING    NOT NULL  COMMENT 'FK to dataset_config',
# MAGIC   pipeline_id      STRING    NOT NULL  COMMENT 'FK to pipeline_config',
# MAGIC   source_column    STRING    NOT NULL  COMMENT 'Column name in the source',
# MAGIC   target_column    STRING    NOT NULL  COMMENT 'Column name in the target',
# MAGIC   target_type      STRING    NOT NULL  COMMENT 'Spark SQL type',
# MAGIC   config_file_path STRING              COMMENT 'YAML file that produced this row',
# MAGIC   created_at       TIMESTAMP           COMMENT 'Row creation timestamp'
# MAGIC ) USING DELTA
# MAGIC COMMENT 'One row per column mapping. Only populated when allow_select_star is false.'
# MAGIC TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');
# MAGIC
# MAGIC -- 6. quality_rule_config (V2: uses dataset_id + pipeline_id instead of object_id)
# MAGIC CREATE TABLE medtech_md_scion_dev.idee_metaschema.quality_rule_config (
# MAGIC   rule_id          STRING    NOT NULL  COMMENT 'Auto-generated from dataset + rule_name',
# MAGIC   dataset_id       STRING    NOT NULL  COMMENT 'FK to dataset_config',
# MAGIC   pipeline_id      STRING    NOT NULL  COMMENT 'FK to pipeline_config',
# MAGIC   rule_name        STRING    NOT NULL  COMMENT 'Human-readable rule description',
# MAGIC   rule_expression  STRING    NOT NULL  COMMENT 'Spark SQL boolean — TRUE means row passes',
# MAGIC   action           STRING    NOT NULL  COMMENT 'warn | drop | quarantine | fail',
# MAGIC   severity         STRING    NOT NULL  COMMENT 'informational | warning | error | critical',
# MAGIC   rule_source      STRING              COMMENT 'inline | native | great_expectations',
# MAGIC   config_file_path STRING              COMMENT 'YAML file that produced this row',
# MAGIC   created_at       TIMESTAMP           COMMENT 'Row creation timestamp',
# MAGIC   updated_at       TIMESTAMP           COMMENT 'Last modification timestamp'
# MAGIC ) USING DELTA
# MAGIC COMMENT 'One row per DQ rule per dataset.'
# MAGIC TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');
# MAGIC
# MAGIC -- 7. pipeline_audit (V2: uses pipeline_id + dataset_id)
# MAGIC CREATE TABLE medtech_md_scion_dev.idee_metaschema.pipeline_audit (
# MAGIC   run_id           STRING     NOT NULL  COMMENT 'Execution run identifier',
# MAGIC   pipeline_id      STRING     NOT NULL  COMMENT 'FK to pipeline_config',
# MAGIC   dataset_id       STRING     NOT NULL  COMMENT 'FK to dataset_config',
# MAGIC   layer            STRING     NOT NULL  COMMENT 'landing | bronze | silver | gold',
# MAGIC   start_time       TIMESTAMP  NOT NULL  COMMENT 'Execution start time',
# MAGIC   end_time         TIMESTAMP            COMMENT 'Execution end time',
# MAGIC   rows_read        BIGINT               COMMENT 'Input record count',
# MAGIC   rows_written     BIGINT               COMMENT 'Output record count',
# MAGIC   rows_rejected    BIGINT               COMMENT 'Records quarantined',
# MAGIC   status           STRING     NOT NULL  COMMENT 'STARTED | SUCCESS | FAILED | SKIPPED',
# MAGIC   error_message    STRING               COMMENT 'Error details on FAILED',
# MAGIC   created_at       TIMESTAMP            COMMENT 'Row insert timestamp'
# MAGIC ) USING DELTA
# MAGIC COMMENT 'Runtime audit log. One row per run + dataset + layer.'
# MAGIC PARTITIONED BY (layer)
# MAGIC TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');

# COMMAND ----------

# DBTITLE 1,Validate header
# MAGIC %md
# MAGIC ## Validate this team's config

# COMMAND ----------

# DBTITLE 1,Validate V2 config
# Load and validate the V2 YAML config
config = load_yaml(CONFIG_PATH)
errors = validate_v2_config(config, CONFIG_PATH)

print(f"Config : {CONFIG_PATH}")
print(f"Version: {config.get('config_template_version', 'unknown')}")

if errors:
    print(f"Result : FAILED\n")
    for e in errors:
        print(f"  [ERROR] {e}")
    raise ValueError("Config validation failed.")
else:
    print(f"Result : PASSED")

# COMMAND ----------

# DBTITLE 1,Cell 4
# MAGIC %md
# MAGIC ## Create application tables from DDL

# COMMAND ----------

# DBTITLE 1,Run DDL scripts
# Auto runs DDL files — but ONLY when allow_select_star is false.
# When allow_select_star = true, the schema comes from the source data,
# so pre-defining table structures via DDL would just cause schema conflicts.
from pathlib import Path

# Check if config is loaded (Cell 8 must have run first)
try:
    _select_star = config["dataset"].get("allow_select_star", False)
    _custom_notebook = config["dataset"].get("allow_custom_notebook", False)
except NameError:
    print("Hi")
    _select_star = False
    _custom_notebook = False

if _select_star or _custom_notebook:
    _reason = "allow_select_star" if _select_star else "allow_custom_notebook"
    print(f"{_reason} = true -> skipping DDL execution.")
    print("Table schemas will be defined by the source data / custom notebook at runtime.")
else:
    DDL_FOLDER = Path.cwd() / ".." / "ddl"
    ddl_files = sorted(DDL_FOLDER.glob("*.sql"), key=lambda f: f.name)

    print(f"Found {len(ddl_files)} DDL file(s) in {DDL_FOLDER.resolve()}\n")

    for ddl_file in ddl_files:
        sql = ddl_file.read_text(encoding="utf-8").strip()
        if sql:
            print(f"  Running: {ddl_file.name}")
            spark.sql(sql)
            print(f"  \u2713 Done\n")

    print("All DDL executed.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Parse it into metadata actions

# COMMAND ----------

# DBTITLE 1,Parse + generate IDs
# Build MERGE statements with auto-generated IDs
statements = build_merge_statements(config, CONFIG_PATH, CATALOG, METADATA_SCHEMA)

# Show summary
pipeline_id = generate_id(str(Path(CONFIG_PATH).resolve()))
source_id = generate_id(config["source"].get("connection_ref", ""), config["source"].get("root_path", ""))
dataset_id = generate_id(pipeline_id, config["dataset"]["object_name"])

print(f"Config          : {CONFIG_PATH}")
print(f"Pipeline        : {config['pipeline']['pipeline_name']}")
print(f"  pipeline_id   : {pipeline_id}")
print(f"  source_id     : {source_id}")
print(f"  dataset_id    : {dataset_id}")
print(f"")
print(f"Planned MERGE statements: {len(statements)}")

# Count by table
from collections import Counter
table_counts = Counter(table for table, _ in statements)
for table, count in table_counts.items():
    print(f"  {table:<25} {count} row(s)")

if config["dataset"].get("allow_select_star"):
    print(f"\n  Note: allow_select_star = true — column_config skipped (SELECT * at runtime)")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load into the metadata schema

# COMMAND ----------

# DBTITLE 1,Load into metadata schema
# Execute MERGE statements against the metadata schema
if DRY_RUN:
    print("DRY RUN — statements that would execute:\n")
    for table, sql in statements:
        print(f"  MERGE INTO {CATALOG}.{METADATA_SCHEMA}.{table}")
    print(f"\n{len(statements)} statement(s) — nothing written.")
else:
    succeeded = 0
    failed = 0
    errors_list = []

    for table, sql in statements:
        try:
            spark.sql(sql)  # noqa: F821
            succeeded += 1
        except Exception as exc:
            failed += 1
            errors_list.append(f"{table} -> {exc}")

    print(f"Target      : {CATALOG}.{METADATA_SCHEMA}")
    print(f"Mode        : LIVE")
    print(f"Statements  : {succeeded + failed} run, {failed} failed")
    print(f"Result      : {'SUCCESS' if failed == 0 else 'FAILED'}")

    if errors_list:
        print(f"\nErrors:")
        for e in errors_list:
            print(f"  [ERROR] {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Confirm what landed

# COMMAND ----------

# DBTITLE 1,Confirm what landed
if not DRY_RUN:
    print("\n=== What landed in metadata tables ===")
    display(  # noqa: F821
        spark.sql(  # noqa: F821
            f"""
            SELECT
                p.pipeline_id,
                p.pipeline_name,
                s.source_name,
                s.source_type,
                t.target_name,
                t.target_table,
                d.object_name,
                d.load_type,
                d.allow_select_star,
                p.config_file_path
            FROM {CATALOG}.{METADATA_SCHEMA}.pipeline_config p
            LEFT JOIN {CATALOG}.{METADATA_SCHEMA}.source_config s ON s.pipeline_id = p.pipeline_id
            LEFT JOIN {CATALOG}.{METADATA_SCHEMA}.target_config t ON t.pipeline_id = p.pipeline_id
            LEFT JOIN {CATALOG}.{METADATA_SCHEMA}.dataset_config d ON d.pipeline_id = p.pipeline_id
            WHERE p.pipeline_id = '{pipeline_id}'
            """
        )
    )

    # Show quality rules
    print("\n=== Quality rules loaded ===")
    display(  # noqa: F821
        spark.sql(  # noqa: F821
            f"""
            SELECT rule_id, rule_name, action, severity, rule_source
            FROM {CATALOG}.{METADATA_SCHEMA}.quality_rule_config
            WHERE pipeline_id = '{pipeline_id}'
            """
        )
    )
else:
    print("Dry run — nothing was written.")

# COMMAND ----------

# DBTITLE 1,Execute pipeline header
# MAGIC %md
# MAGIC ## Execute Pipeline — SELECT * with ingestion timestamp
# MAGIC
# MAGIC Reads metadata back from the tables, resolves source path, and runs the actual data movement.

# COMMAND ----------

# DBTITLE 1,Execute pipeline
# ---------------------------------------------------------------------------
# Phase 2 Execution Engine: SELECT * + trim + DQ + quarantine
# ---------------------------------------------------------------------------
from datetime import datetime, timezone
import uuid
from pyspark.sql.functions import current_timestamp, trim as spark_trim, col, lit, expr
from pyspark.sql.types import StringType

if not DRY_RUN:
    # 1. Read metadata for this pipeline
    meta = spark.sql(f"""
        SELECT s.root_path, s.file_format, s.source_type,
               d.source_path, d.allow_select_star, d.allow_custom_notebook, d.notebook_path,
               d.trim_all, d.load_type, d.object_name,
               t.target_type, t.target_table, t.target_path,
               d.dataset_id
        FROM {CATALOG}.{METADATA_SCHEMA}.source_config s
        JOIN {CATALOG}.{METADATA_SCHEMA}.dataset_config d ON d.pipeline_id = s.pipeline_id
        JOIN {CATALOG}.{METADATA_SCHEMA}.target_config t ON t.pipeline_id = s.pipeline_id
        WHERE s.pipeline_id = '{pipeline_id}'
    """).collect()[0]

    # 2. Resolve source path
    root = meta["root_path"].rstrip("/")
    sub = meta["source_path"] or ""
    source_full_path = f"{root}/{sub}" if sub else root
    file_fmt = meta["file_format"] or "csv"

    print(f"Pipeline    : {config['pipeline']['pipeline_name']}")
    print(f"Source path : {source_full_path}")
    print(f"File format : {file_fmt}")
    print(f"Target      : {meta['target_table']}")
    _custom_nb = meta["allow_custom_notebook"] if "allow_custom_notebook" in meta.asDict() else False
    _mode = "Custom Notebook" if _custom_nb else ("SELECT *" if meta["allow_select_star"] else "Column mapping (DDL Auto Creation)")
    print(f"Mode        : {_mode}")
    print(f"Load type   : {meta['load_type']}")
    print()

    # 3. Start audit
    run_id = str(uuid.uuid4())[:8]
    run_start = datetime.now(timezone.utc)

    try:
        # Determine execution path
        allow_select_star = meta["allow_select_star"]
        allow_custom_notebook = meta["allow_custom_notebook"] if "allow_custom_notebook" in meta.asDict() else False

        if allow_custom_notebook:
            # --- PATH C: Custom Notebook (handles its own source reading) ---
            notebook_path = meta["notebook_path"]
            print(f"Transform   : Custom Notebook")
            print(f"  Notebook  : {notebook_path}")

            # Run the user's custom notebook — it writes to a staging table
            STAGING_TABLE = f"{CATALOG}.{APP_SCHEMA}._staging_custom_output"
            dbutils.notebook.run(notebook_path, timeout_seconds=600)

            # Pick up the result from the staging table
            df = spark.table(STAGING_TABLE)
            rows_read = df.count()
            print(f"  Output    : {rows_read} rows from _custom_output")
            print(f"  Columns   : {df.columns}")

            # Add ingestion timestamp
            df = df.withColumn("_ingested_at", current_timestamp())

        else:
            # 4. Read source data (Path A and B)
            df = (spark.read
                  .format(file_fmt)
                  .option("header", "true")
                  .option("inferSchema", "true")
                  .load(source_full_path))

            rows_read = df.count()
            print(f"Rows read   : {rows_read}")

            if allow_select_star:
                # --- PATH A: SELECT * ---
                print(f"Transform   : SELECT * (pass all columns through)")
                df = df.withColumn("_ingested_at", current_timestamp())

            else:
                # --- PATH B: Column mapping (allow_select_columns) ---
                columns_cfg = config.get("columns", [])
                if not columns_cfg:
                    raise ValueError("allow_select_star is false but no columns section found in YAML")

                print(f"Transform   : Column mapping ({len(columns_cfg)} columns)")
                from pyspark.sql.functions import col as spark_col

                # Select, rename, and cast each configured column
                select_exprs = []
                for c in columns_cfg:
                    src = c["source_column"]
                    tgt = c["target_column"]
                    tgt_type = c["target_type"]
                    select_exprs.append(spark_col(src).cast(tgt_type).alias(tgt))
                    print(f"    {src} -> {tgt} ({tgt_type})")

                df = df.select(*select_exprs)
                df = df.withColumn("_ingested_at", current_timestamp())

        # 6. Trim all string columns if trim_all = true
        if meta["trim_all"]:
            string_cols = [field.name for field in df.schema.fields
                          if isinstance(field.dataType, StringType) and field.name != "_ingested_at"]
            for c in string_cols:
                df = df.withColumn(c, spark_trim(col(c)))
            print(f"Trimmed     : {len(string_cols)} string column(s)")

        # ---------------------------------------------------------------
        # 7. DATA QUALITY: resolve aliases, evaluate rules, quarantine
        # ---------------------------------------------------------------
        quality = config.get("quality", {})
        aliases_config = quality.get("aliases", {})
        rules = quality.get("rules", [])

        # 7a. Resolve aliases: find which actual column matches each alias list
        actual_columns = [field.name for field in df.schema.fields]
        resolved_aliases = {}
        for alias_name, candidates in aliases_config.items():
            matched = None
            for candidate in candidates:
                if candidate in actual_columns:
                    matched = candidate
                    break
            resolved_aliases[alias_name] = matched or alias_name

        print(f"\nAliases resolved:")
        for alias, actual in resolved_aliases.items():
            print(f"  {{{alias}}} -> {actual}")

        # 7b. Resolve rule expressions by replacing {alias} placeholders
        def resolve_expression(expression, aliases):
            for alias_name, actual_col in aliases.items():
                expression = expression.replace("{" + alias_name + "}", f"`{actual_col}`")
            return expression

        # 7c. Evaluate rules and route rows
        rows_quarantined = 0
        rows_dropped = 0
        quarantine_frames = []
        target_table = meta["target_table"]

        # Derive quarantine table: bronze_X -> quarantine_X
        table_parts = target_table.rsplit(".", 1)
        quarantine_table = table_parts[0] + "." + table_parts[-1].replace("bronze_", "quarantine_")

        print(f"\nDQ Rules ({len(rules)}):")

        for rule in rules:
            rule_name = rule["rule_name"]
            raw_expr = rule["rule_expression"]
            action = rule["action"]
            resolved_expr = resolve_expression(raw_expr, resolved_aliases)

            # TRUE = pass, FALSE/NULL = fail
            passing = df.filter(expr(resolved_expr))
            failing = df.filter(f"NOT ({resolved_expr}) OR ({resolved_expr}) IS NULL")
            fail_count = failing.count()

            if fail_count == 0:
                print(f"  [PASS] {rule_name} -> 0 failures")
                continue

            if action == "fail":
                raise ValueError(
                    f"DQ FAIL: rule '{rule_name}' failed for {fail_count} row(s). "
                    f"Pipeline halted. Expression: {resolved_expr}"
                )

            elif action == "quarantine":
                quarantine_df = (failing
                    .withColumn("_quarantine_rule_name", lit(rule_name))
                    .withColumn("_quarantined_at", current_timestamp())
                    .withColumn("_run_id", lit(run_id))
                    .withColumn("_pipeline_id", lit(pipeline_id))
                )
                quarantine_frames.append(quarantine_df)
                rows_quarantined += fail_count
                df = passing
                print(f"  [QUARANTINE] {rule_name} -> {fail_count} row(s) quarantined")

            elif action == "drop":
                rows_dropped += fail_count
                df = passing
                print(f"  [DROP] {rule_name} -> {fail_count} row(s) dropped")

            elif action == "warn":
                print(f"  [WARN] {rule_name} -> {fail_count} row(s) flagged (kept in output)")

        # 7d. Write quarantined rows
        if quarantine_frames:
            from functools import reduce
            quarantine_combined = reduce(
                lambda a, b: a.unionByName(b, allowMissingColumns=True),
                quarantine_frames
            )
            quarantine_combined.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(quarantine_table)
            print(f"\nQuarantine  : {rows_quarantined} row(s) -> {quarantine_table}")

        if rows_dropped > 0:
            print(f"Dropped     : {rows_dropped} row(s) removed")

        # ---------------------------------------------------------------
        # 8. Write passing rows to target
        # ---------------------------------------------------------------
        if meta["load_type"] == "FULL":
            if allow_select_star or allow_custom_notebook:
                # SELECT * or Custom Notebook: schema comes from source/notebook, may change
                df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(target_table)
            else:
                # DDL mode: table already exists with correct schema
                df.write.mode("overwrite").saveAsTable(target_table)
        else:
            if allow_select_star or allow_custom_notebook:
                df.write.mode("append").option("mergeSchema", "true").saveAsTable(target_table)
            else:
                df.write.mode("append").saveAsTable(target_table)

        rows_written = spark.sql(f"SELECT COUNT(*) AS cnt FROM {target_table}").collect()[0]["cnt"]
        run_end = datetime.now(timezone.utc)

        print(f"\nRows written: {rows_written} (to {target_table})")
        print(f"Status      : SUCCESS")
        print(f"Duration    : {(run_end - run_start).total_seconds():.1f}s")

        # 9. Write audit row
        spark.sql(f"""
            INSERT INTO {CATALOG}.{METADATA_SCHEMA}.pipeline_audit
            VALUES (
                '{run_id}', '{pipeline_id}', '{meta["dataset_id"]}', 'bronze',
                '{run_start.strftime("%Y-%m-%d %H:%M:%S")}',
                '{run_end.strftime("%Y-%m-%d %H:%M:%S")}',
                {rows_read}, {rows_written}, {rows_quarantined}, 'SUCCESS', NULL,
                '{run_end.strftime("%Y-%m-%d %H:%M:%S")}'
            )
        """)
        print(f"Audit       : logged (run_id={run_id}, quarantined={rows_quarantined})")

        # Clean up staging table if custom notebook was used
        if allow_custom_notebook:
            spark.sql(f"DROP TABLE IF EXISTS {STAGING_TABLE}")
            print(f"Cleanup     : dropped staging table")

    except Exception as exc:
        run_end = datetime.now(timezone.utc)
        print(f"\nStatus      : FAILED")
        print(f"Error       : {exc}")

        spark.sql(f"""
            INSERT INTO {CATALOG}.{METADATA_SCHEMA}.pipeline_audit
            VALUES (
                '{run_id}', '{pipeline_id}', '{meta["dataset_id"]}', 'bronze',
                '{run_start.strftime("%Y-%m-%d %H:%M:%S")}',
                '{run_end.strftime("%Y-%m-%d %H:%M:%S")}',
                0, 0, 0, 'FAILED', '{str(exc).replace(chr(39), chr(39)+chr(39))[:500]}',
                '{run_end.strftime("%Y-%m-%d %H:%M:%S")}'
            )
        """)
        print(f"Audit       : logged FAILED (run_id={run_id})")

else:
    print("Dry run — execution skipped.")

# COMMAND ----------

# DBTITLE 1,Show target data
# Show what landed in the target table
if not DRY_RUN:
    target_table = meta["target_table"]
    print(f"\n=== {target_table} ===")
    display(spark.sql(f"SELECT * FROM {target_table}"))