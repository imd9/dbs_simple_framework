# Databricks notebook source
# DBTITLE 1,Custom Transform: Combine Customer CSVs
# =============================================================================
# transform_customer_combined
# =============================================================================
# Custom notebook for the iDEE framework (allow_custom_notebook = true).
#
# CONTRACT:
#   - This notebook is called by the framework execution engine.
#   - It MUST create a temp view named "_custom_output".
#   - The framework picks up that view and handles: _ingested_at, trim, DQ,
#     quarantine, target writing, and audit logging.
#
# WHAT THIS DOES:
#   Reads two CSVs with different schemas, standardizes column names,
#   and unions them into one combined dataset.
#
# SOURCE FILES:
#   1. customer_sample.csv        -> CUSTOMER_ID, CUSTOMER_NAME, EMAIL_ADDRESS
#   2. test_customers_sharepoint.csv -> CUST_ID, CUST_NAME, CUST_EMAIL
# =============================================================================

from pyspark.sql.functions import col, lit

# --- Source paths ---
# Custom notebooks read from wherever the data actually lives.
# file_1 is in the workspace data folder, file_2 is in the Volume.
VOLUME_PATH = "/Volumes/medtech_md_scion_dev/idee_app/landing/customer/incoming"
DATA_PATH = "/Workspace/Users/iduran3@its.jnj.com/idee_for_databricks/idee_dbx_app/data"

file_1 = f"{VOLUME_PATH}/customer_sample.csv"
file_2 = f"{VOLUME_PATH}/test_customers_sharepoint.csv"

# --- Read source 1: customer_sample.csv ---
df1 = (spark.read
    .format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load(file_1))

# Select and standardize: CUSTOMER_ID -> customer_id, etc.
df1_std = df1.select(
    col("CUSTOMER_ID").cast("string").alias("customer_id"),
    col("CUSTOMER_NAME").alias("customer_name"),
    col("EMAIL_ADDRESS").alias("email"),
    lit("customer_sample.csv").alias("_source_file")
)

print(f"Source 1: {file_1} -> {df1_std.count()} rows")

# --- Read source 2: test_customers_sharepoint.csv ---
df2 = (spark.read
    .format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load(file_2))

# Select and standardize: CUST_ID -> customer_id, etc.
df2_std = df2.select(
    col("CUST_ID").cast("string").alias("customer_id"),
    col("CUST_NAME").alias("customer_name"),
    col("CUST_EMAIL").alias("email"),
    lit("test_customers_sharepoint.csv").alias("_source_file")
)

print(f"Source 2: {file_2} -> {df2_std.count()} rows")

# --- Union both into one combined dataset ---
combined_df = df1_std.unionByName(df2_std)

print(f"Combined : {combined_df.count()} rows")
print(f"Columns  : {combined_df.columns}")

# --- Write to staging table for framework to pick up ---
# dbutils.notebook.run on serverless uses a separate session, so temp views don't work.
# Instead, write to a real staging table that the framework reads and then drops.
STAGING_TABLE = "medtech_md_scion_dev.idee_app._staging_custom_output"

combined_df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(STAGING_TABLE)

print(f"\n✓ Staging table '{STAGING_TABLE}' written ({combined_df.count()} rows). Framework will handle the rest.")