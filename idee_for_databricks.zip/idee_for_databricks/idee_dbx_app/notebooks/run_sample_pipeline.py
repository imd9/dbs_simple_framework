# Databricks notebook source
# MAGIC %md
# MAGIC # Sample Pipeline — customer full refresh
# MAGIC
# MAGIC The application-side view: how a downstream team uses the framework.
# MAGIC
# MAGIC This notebook does **not** contain framework logic. It points the
# MAGIC framework at this team's filled config and reports what happened. All
# MAGIC reusable logic lives in `idee_dbx_framework/src/idee_dbx/`.

# COMMAND ----------

dbutils.widgets.text("catalog", "medtech_md_scion_dev", "1. Catalog")
dbutils.widgets.text("metadata_schema", "idee_metaschema", "2. Metadata schema")
dbutils.widgets.text("app_schema", "idee_app", "3. Application schema")
dbutils.widgets.dropdown("dry_run", "true", ["true", "false"], "4. Dry run")

CATALOG = dbutils.widgets.get("catalog")
METADATA_SCHEMA = dbutils.widgets.get("metadata_schema")
APP_SCHEMA = dbutils.widgets.get("app_schema")
DRY_RUN = dbutils.widgets.get("dry_run") == "true"

CONFIG_PATH = "../config/customer_full_refresh_config.yaml"

# COMMAND ----------

import sys
from pathlib import Path

FRAMEWORK_SRC = (Path.cwd() / ".." / ".." / "idee_dbx_framework" / "src").resolve()
if str(FRAMEWORK_SRC) not in sys.path:
    sys.path.insert(0, str(FRAMEWORK_SRC))

from idee_dbx.config_parser import parse_config
from idee_dbx.config_validator import validate_config_file
from idee_dbx.metadata_loader import load_plan

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validate this team's config

# COMMAND ----------

validation = validate_config_file(CONFIG_PATH)
print(validation.report())
if not validation.is_valid:
    raise ValueError("Config validation failed — see the report above.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Parse it into metadata actions

# COMMAND ----------

plan = parse_config(validation.config, config_path=CONFIG_PATH)
print(plan.summary())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load into the metadata schema

# COMMAND ----------

result = load_plan(
    plan,
    catalog=CATALOG,
    metadata_schema=METADATA_SCHEMA,
    dry_run=DRY_RUN,
    spark=spark,  # noqa: F821
)
print(result.report())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Confirm what landed

# COMMAND ----------

if not DRY_RUN:
    display(  # noqa: F821
        spark.sql(  # noqa: F821
            f"""
            SELECT o.object_id, o.object_name, o.load_type, o.bronze_table,
                   COUNT(c.source_column) AS column_count
            FROM {CATALOG}.{METADATA_SCHEMA}.object_config o
            LEFT JOIN {CATALOG}.{METADATA_SCHEMA}.column_config c
                   ON c.object_id = o.object_id
            WHERE o.object_id = '{plan.object_id}'
            GROUP BY o.object_id, o.object_name, o.load_type, o.bronze_table
            """
        )
    )
else:
    print("Dry run — nothing was written.")
