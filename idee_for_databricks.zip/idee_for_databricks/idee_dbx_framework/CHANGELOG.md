# Changelog

All notable changes to the iDEE for Databricks framework.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Versioning follows [Semantic Versioning](https://semver.org/).

---

## Versioning policy

Two version numbers exist and they move independently:

| Version | Lives in | Covers |
|---|---|---|
| **Framework version** | `VERSION`, `src/idee_dbx/__init__.py` | The Python code: validator, parser, loader, CLI |
| **Config schema version** | `config_version:` in each config; `schema/pipeline_config_schema_v*.yaml` | The shape of a config file |

A framework release can ship without changing the config schema. When the
config schema *does* change:

- **Backward-compatible** (new optional field) → bump the schema minor version,
  add a new schema file, keep the old one. Existing configs continue to
  validate against the version they declare.
- **Breaking** (field removed, renamed, or newly required) → bump the schema
  major version and publish a migration note here. **Never edit a published
  schema file in place** — configs in the wild are validating against it.

Schema files are additive. `schema/` accumulates versions; it does not replace
them.

---

## [Unreleased]

### Planned
- Bronze ingestion engine (Auto Loader) driven by `object_config`
- Silver transformation engine driven by `column_config`
- Runtime enforcement of the `native` and `great_expectations` DQ engines
- `pipeline_audit` writes at run time
- Databricks Asset Bundle deployment (deferred until repos and AD groups exist)
- Append and incremental load patterns (deferred until full refresh is proven)

---

## [0.1.0] — 2026-07-28

First working skeleton. Proves the `config → validate → parse → output` path
end to end for a single small full-refresh pipeline.

### Added

**Framework**
- `config_validator` — schema-driven validation. Rules live in
  `schema/pipeline_config_schema_v0_1.yaml`, not in Python, so new config
  formats mean a new schema file rather than a code change.
- `config_parser` — translates a valid config into metadata actions and renders
  them as idempotent `MERGE` statements.
- `metadata_loader` — applies a parse plan to Unity Catalog. The only module
  that touches Spark; supports `dry_run`.
- `main` — CLI with `validate`, `parse`, and `load` subcommands.
- Config schema v0.1 covering required fields, types, enums, conditional
  requirements, cross-field integrity, and unfilled-placeholder detection.
- Blank config template with the four-section model
  (`source` / `dataset` / `columns` / `quality`).
- Metadata DDL for five tables: `source_config`, `object_config`,
  `column_config`, `quality_rule_config`, `pipeline_audit`.
- PyTest suite covering the validator and parser, with valid and invalid
  fixtures.
- `docs/NAMING_CONVENTIONS.md`.

**Application**
- Filled demo config: `customer_full_refresh_config.yaml` — one source, one
  target, five columns, full refresh.
- Bronze, Silver, and quarantine DDL for the demo.
- Sample CSV containing deliberate data quality defects, so the rules visibly
  fire during a demo.
- Demo notebook calling the framework.

### Design decisions
- **Validate and parse are separate stages.** Parsing produces a plan without
  executing it, which is what makes a meaningful dry run possible.
- **`MERGE`, not `INSERT`.** Re-running the same config must not duplicate rows.
- **Deterministic `rule_id`s** (`<object_id>__<slug>`) rather than UUIDs, for
  the same reason.
- **Inactive columns are recorded with `active = false`, not dropped.** Deleting
  them would lose the fact that exclusion was deliberate.
- **Nothing hardcoded.** Catalog and schema are parameters throughout.

### Known gaps
- No ingestion engine yet — the framework loads *metadata*, not data. Bronze and
  Silver movement is not implemented.
- `native` and `great_expectations` DQ engines validate and parse correctly, but
  no runtime enforces them; only `inline` produces metadata rows.
- Only `FULL` load type is exercised end to end. `INCREMENTAL`, `CDC`, and
  `SNAPSHOT` validate but have no runtime behaviour.
