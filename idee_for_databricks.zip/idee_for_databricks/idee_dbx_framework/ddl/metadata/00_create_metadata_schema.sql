-- =============================================================================
-- 00_create_metadata_schema.sql
-- =============================================================================
-- Creates the framework metadata schema.
--
-- OWNER      : Framework. Application teams do not run this.
-- RUNS       : Once per environment, at setup.
-- PARAMETERS : ${catalog}, ${metadata_schema}  -- never hardcode these
--
-- NOTE: if the platform team has already provisioned the schema for you, skip
-- this script. Creating schemas usually requires privileges an application
-- workspace does not have.
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS ${catalog}.${metadata_schema}
COMMENT 'iDEE framework metadata tables. Metadata only - no business data.';
