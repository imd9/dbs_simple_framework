# iDEE for Databricks

Metadata-driven ELT framework for Databricks, plus a sample application that
uses it.

**Framework v0.1.0** · config schema v0.1

---

## Start here

Two folders, two audiences:

| Folder | Audience | Contents |
|---|---|---|
| [`idee_dbx_framework/`](idee_dbx_framework/) | Framework engineers | Template, schema, validator, parser, metadata DDL, unit tests |
| [`idee_dbx_app/`](idee_dbx_app/) | Downstream application teams | Filled configs, application DDL, sample data, demo notebook |

The split is the point. The framework is shared by every application team; the
app folder belongs to one team. Anything another team would also need belongs
in the framework.

---

## What works today

```
  filled config.yaml  →  VALIDATE  →  PARSE  →  LOAD  →  metadata tables
```

Onboarding a dataset means filling out one YAML file. No new pipeline, no code
change.

**v0.1 loads metadata, not data.** There is no ingestion engine yet — Bronze
and Silver movement is the next increment. Building the config path first, and
proving it end to end, is deliberate.

---

## Try it in two minutes

```bash
cd idee_dbx_framework

PYTHONPATH=src python -m idee_dbx.main parse \
  --config ../idee_dbx_app/config/customer_full_refresh_config.yaml \
  --catalog medtech_md_scion_dev
```

Expected:

```
STEP 1 — CONFIG VALIDATION      Result: PASSED
STEP 2 — CONFIG PARSING         10 planned actions across 4 tables
```

Add `--show-sql` to see the generated `MERGE` statements.

---

## Two schemas, two folders — not the same thing

A common source of confusion. These are separate namespaces:

| | What it is | Names |
|---|---|---|
| **Unity Catalog schemas** | where *tables* live | `idee_metaschema` (metadata only), `idee_app` (business data) |
| **Workspace folders** | where *files* live | `idee_dbx_framework`, `idee_dbx_app` |

Metadata tables never go in the application schema; business data never goes in
the metadata schema.

---

## Design principles

1. **One complete unit at a time.** A small working path beats several
   half-built components.
2. **Framework and application stay separate.** Templates and reusable logic on
   one side, filled configs and app-specific DDL on the other.
3. **Nothing hardcoded.** Catalog and schema are parameters everywhere, so the
   same artifact promotes across dev, QA, and prod unchanged.
4. **Configs are versioned.** Each declares `config_version`; the validator
   loads the matching schema. Published schemas are never edited in place.
5. **Validate before parse, parse before load.** Separating the stages is what
   makes a meaningful dry run possible.
6. **Repo-shaped from day one.** The move to Bitbucket should be a copy, not a
   redesign.

---

## Roadmap

| Increment | Status |
|---|---|
| Config → validate → parse → metadata load | ✅ v0.1.0 |
| Bronze ingestion (Auto Loader, full refresh) | next |
| Silver transformation driven by `column_config` | after Bronze |
| DQ runtime enforcement (native / GX engines) | after Silver |
| Append, then incremental / CDC | after full refresh is proven |
| Asset Bundles and CI/CD | blocked on Bitbucket repos + AD groups |

Deferred items are deferred on purpose, not overlooked. See
`idee_dbx_framework/CHANGELOG.md`.

---

## Documentation

| Document | Covers |
|---|---|
| [Framework README](idee_dbx_framework/README.md) | Architecture, install, CLI, testing |
| [Testing guide — framework engineer](idee_dbx_framework/docs/TESTING_GUIDE.md) | Running PyTest in Databricks, DDL install, demo script |
| [Demo guide — data engineer](idee_dbx_app/docs/DEMO_GUIDE.md) | Filling a config, validating, loading, demo script |
| [Application README](idee_dbx_app/README.md) | Onboarding a pipeline, the demo |
| [Naming conventions](idee_dbx_framework/docs/NAMING_CONVENTIONS.md) | `.yaml` vs `.yml`, folders, Python, SQL, IDs |
| [Changelog](idee_dbx_framework/CHANGELOG.md) | Version history and versioning policy |
