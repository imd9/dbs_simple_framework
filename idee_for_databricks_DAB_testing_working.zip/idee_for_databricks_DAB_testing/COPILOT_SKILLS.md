# COPILOT SKILLS — What the AI needs to know for DABs deployment

---

## Skill 1: Declarative Automation Bundles (databricks.yml)

### What it is
Declarative Automation Bundles (formerly "Databricks Asset Bundles" or DABs) is a deployment tool. You define a `databricks.yml` file that describes WHAT to deploy, and the CLI handles HOW.

### Key commands
```bash
databricks bundle init          # Create new bundle from template
databricks bundle validate      # Check config is valid
databricks bundle deploy        # Build artifacts + sync files + create resources
databricks bundle run <job>     # Trigger a job run
databricks bundle destroy       # Tear down deployed resources
```

### databricks.yml structure
```yaml
bundle:
  name: <project-name>

artifacts:          # Things to BUILD (wheels, JARs)
  <name>:
    type: whl
    path: <path-to-python-package>

resources:          # Things to CREATE in workspace (jobs, pipelines)
  jobs:
    <job-key>:
      name: "Human readable name"
      tasks:
        - task_key: <key>
          notebook_task:
            notebook_path: <relative-path>
            base_parameters: {key: value}
          libraries:
            - whl: <path-to-wheel>

targets:            # Environments (dev, staging, prod)
  dev:
    default: true
    workspace:
      host: https://<workspace-url>
  prod:
    workspace:
      host: https://<prod-workspace-url>
```

### Important docs
- https://learn.microsoft.com/en-us/azure/databricks/dev-tools/bundles/
- https://learn.microsoft.com/en-us/azure/databricks/dev-tools/bundles/python-wheel/
- https://learn.microsoft.com/en-us/azure/databricks/dev-tools/bundles/library-dependencies/

---

## Skill 2: Python wheel building

### What a wheel is
A `.whl` file is a pre-built Python package. When attached as a job library, the package is available to import without any `%pip install` or `sys.path` manipulation.

### How to build
```bash
# Standard (needs internet for build deps)
pip wheel ./path/to/package -w dist/

# No internet (uses existing setuptools)
pip wheel ./path/to/package --no-build-isolation --no-deps -w dist/

# Using python -m build
python -m build ./path/to/package
```

### Required files
- `pyproject.toml` at package root (defines name, version, build system)
- `src/<package_name>/__init__.py` (makes it a package)
- Source layout: `src/idee_dbx/` for the `idee-dbx` package

### Naming convention
Package name in pyproject.toml: `idee-dbx` (hyphen)
Import name in Python: `idee_dbx` (underscore)
Wheel filename: `idee_dbx-0.1.0-py3-none-any.whl`

---

## Skill 3: Job cluster libraries

### What it does
When a wheel is attached as a library to a job task, the package is pre-installed on the cluster BEFORE the notebook runs. The notebook can then `from idee_dbx.main import run_pipeline` without any installation step.

### How to reference in databricks.yml
```yaml
libraries:
  # From a built artifact (bundle builds it)
  - whl: ../dist/idee_dbx-*.whl
  
  # From a UC Volume (pre-built)
  - whl: /Volumes/catalog/schema/volume/idee_dbx-0.1.0-py3-none-any.whl
  
  # From workspace files
  - whl: /Workspace/path/to/idee_dbx-0.1.0-py3-none-any.whl
```

---

## Skill 4: Databricks workspace specifics (this project)

### Workspace
- Azure Databricks: `adb-6804987682635671.11.azuredatabricks.net`
- No internet access from compute
- Serverless compute available
- Unity Catalog enabled

### Authentication
- Use the Databricks extension in VS Code (token-based or Azure AD)
- CLI profile: configure with `databricks configure --profile dev`

### File paths
- Workspace files: `/Workspace/Users/iduran3@its.jnj.com/...`
- Volumes: `/Volumes/medtech_md_scion_dev/idee_metaschema/...`
- Bundle deploys to: `/Workspace/Users/iduran3@its.jnj.com/.bundle/idee_for_databricks/dev/`

---

## Skill 5: The sync/deploy model

### What gets synced to workspace
When you `bundle deploy`:
1. **Notebooks** → synced to workspace (users interact with these)
2. **Config files (YAML, SQL)** → synced to workspace (notebooks read these at runtime)
3. **Python source** → NOT synced directly. Instead, BUILT into a wheel and attached as a library.

### What this means for our project
- `idee_dbx_framework/src/` → gets built into wheel, NOT synced as files
- `idee_dbx_app/notebooks/` → synced as notebooks
- `idee_dbx_app/config/` → synced as workspace files
- `idee_dbx_app/ddl/` → synced as workspace files
- `idee_dbx_framework/ddl/` → synced as workspace files

### include/exclude in sync
```yaml
sync:
  include:
    - idee_dbx_app/**
    - idee_dbx_framework/ddl/**
    - idee_dbx_framework/schema/**
  exclude:
    - idee_dbx_framework/src/**
    - idee_dbx_framework/tests/**
    - "**/__pycache__/**"
```

---

## Skill 6: Troubleshooting

### Common issues

| Problem | Cause | Fix |
| --- | --- | --- |
| `ModuleNotFoundError: idee_dbx` | Wheel not attached as library | Check `libraries` in databricks.yml |
| Wheel build fails during deploy | No internet on build machine | Use `--no-build-isolation` or pre-build locally |
| Notebook can't find config files | Wrong relative path | Paths are relative to notebook location |
| `setuptools` download fails | Network-restricted workspace | Pre-build wheel and reference from Volume |
| Job sees old code | Wheel cache | Bump version in pyproject.toml (0.1.1) or delete .bundle/ |

### Debug commands
```bash
# Check what's in the deployed bundle
databricks bundle summary

# See the generated Terraform state
ls .bundle/dev/terraform/

# Check the job was created
databricks jobs list --output JSON | grep idee

# Check the wheel was uploaded
databricks workspace ls /Workspace/Users/iduran3@its.jnj.com/.bundle/
```

---

## Skill 7: The end-user experience (Ojoma's requirements)

### Rules from the tech lead
1. NO hardcoded paths in the end-user notebook
2. NO visible framework plumbing (no sys.path, no %pip, no bootstrap)
3. ONE import, ONE function call
4. Logs showing what happened at each step
5. Parameterized via widgets (catalog, schema, paths)
6. Works identically in dev, QA, and prod (only parameters change)

### Demo flow ("3 clicks")
1. Open `pipeline_builder` notebook
2. Run All
3. Check Unity Catalog — tables are populated

### Two personas for demos
- **Framework user** (SCION engineer): sees the simple notebook, runs it, done
- **Framework developer** (iDEE team): sees the internals, explains how it works
