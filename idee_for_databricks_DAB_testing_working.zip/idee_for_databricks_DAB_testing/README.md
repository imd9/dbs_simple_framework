# iDEE for Databricks

Metadata-driven ELT framework for Databricks, plus a sample application that
uses it.

**Framework v0.1.0** · config schemas v0.1 + v0.2

---

## Start here

Two folders, two audiences:

| Folder | Audience | Contents |
|---|---|---|
| [`idee_dbx_framework/`](idee_dbx_framework/) | Framework engineers | Template, schemas, validator, parser, metadata loader, runtime engine, DDL, 217 unit tests |
| [`idee_dbx_app/`](idee_dbx_app/) | Downstream application teams | One multi-hop config, application DDL, sample data, demo notebook |

The split is the point. The framework is shared by every application team; the
app folder belongs to one team. Anything another team would also need belongs
in the framework.

---

## What works today

```
  config.yaml  →  VALIDATE  →  PARSE  →  LOAD metadata  →  RUN pipeline  →  data in tables
```

Onboarding a dataset means filling out one YAML file. No new pipeline, no code
change. The framework validates, parses, loads metadata, and **executes the
pipeline end to end** — Landing → Bronze → Silver → Gold — with data quality
enforcement, quarantine, and audit trail.

---

## Try it in two minutes

Open `idee_dbx_app/notebooks/run_sample_pipeline` in Databricks and run all
cells. It reads `config/customer_pipeline.yaml` (a single v0.2 multi-hop
file), validates it, parses 3 hops, loads metadata, executes all 3 hops, and
creates a scheduled Databricks job.

Expected output:

```
Hop 1/3: customer_etl_landing_to_bronze    SUCCESS  5 read → 5 written
Hop 2/3: customer_etl_bronze_to_silver     SUCCESS  5 read → 4 written, 1 quarantined
Hop 3/3: customer_etl_silver_to_gold       SUCCESS  4 read → 4 written
```

---

## Two schemas, two folders — not the same thing

A common source of confusion. These are separate namespaces:

| | What it is | Names |
|---|---|---|
| **Unity Catalog schemas** | where *tables* live | `idee_metaschema` (metadata only), `idee_app` (business data) |
| **Workspace folders** | where *files* live | `idee_dbx_framework`, `idee_dbx_app` |

Metadata tables never go in the application schema; business data never goes in
the metadata schema.

---

## Design principles

1. **One complete unit at a time.** A small working path beats several
   half-built components.
2. **Framework and application stay separate.** Templates and reusable logic on
   one side, filled configs and app-specific DDL on the other.
3. **Nothing hardcoded.** Catalog and schema are parameters everywhere, so the
   same artifact promotes across dev, QA, and prod unchanged.
4. **Configs are versioned.** Each declares `config_version`; the validator
   loads the matching schema. Published schemas are never edited in place.
5. **Validate before parse, parse before load.** Separating the stages is what
   makes a meaningful dry run possible.
6. **Repo-shaped from day one.** The move to Bitbucket should be a copy, not a
   redesign.

---

## Roadmap

| Increment | Status |
|---|---|
| Config → validate → parse → metadata load | ✅ v0.1.0 |
| Bronze ingestion (Auto Loader, full refresh) | ✅ done |
| Silver transformation driven by `column_config` | ✅ done |
| Gold transformation (explicit mode) | ✅ done |
| DQ runtime enforcement (inline engine) | ✅ done (warn, quarantine, drop, fail) |
| v0.2 multi-hop configs (single file, N hops) | ✅ done |
| Scheduled job creation from config | ✅ done |
| DQ runtime (native / GX engines) | next |
| Append, then incremental / CDC | after full refresh is proven |
| `notebook` column mode execution | after explicit is proven |
| Declarative Automation Bundles and CI/CD | blocked on Bitbucket repos + AD groups |

Deferred items are deferred on purpose, not overlooked. See
`idee_dbx_framework/docs/CHANGELOG.md`.

---

## 🤖 iDEE Framework Assistant (AI Agent)

**New: An AI agent that helps you use the framework without reading docs.**

Open `idee_dbx_framework/notebooks/iDEE Framework Assistant` and start chatting.
It can:

- **Walk you through filling a pipeline config** step by step (you answer questions, it builds the YAML)
- **Diagnose pipeline failures** and explain errors in plain English
- **Show you what pipelines exist**, their DQ rules, column mappings, and data lineage
- **Generate a complete YAML config** from your description and save it to the app folder

Or chat directly in [AI Playground](/ml/playground) → select endpoint `supervisor-agent-2026-05-11-14-00-30`.

See [Agent Guide](idee_dbx_framework/docs/AGENT_GUIDE.md) for full details.

---

## Documentation

| Document | Covers |
|---|---|
| [How it works — the complete flow](HOW_IT_WORKS.md) | Both folders, both roles, and the demo script |
| [Framework README](idee_dbx_framework/README.md) | Architecture, install, CLI, testing |
| [Application README](idee_dbx_app/README.md) | Onboarding a pipeline, the demo |
| [Agent Guide](idee_dbx_framework/docs/AGENT_GUIDE.md) | How to use the AI assistant, permissions, tools |
| [Naming conventions](idee_dbx_framework/docs/NAMING_CONVENTIONS.md) | `.yaml` vs `.yml`, folders, Python, SQL, IDs |
| [Changelog](idee_dbx_framework/docs/CHANGELOG.md) | Version history and versioning policy |
