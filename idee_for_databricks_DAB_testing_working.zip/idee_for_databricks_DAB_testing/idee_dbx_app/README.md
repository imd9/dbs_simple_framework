# iDEE for Databricks — Application

The **downstream user's** side. Everything here is specific to one application
team and its pipelines: one multi-hop config, application DDL, sample data, and
a demo notebook that runs the full ETL and creates a scheduled job.

Reusable logic lives in `../idee_dbx_framework/`. Nothing in this folder
should contain framework code — if you find yourself writing something another
team would also need, it belongs in the framework.

---

**New here?** Start with [`docs/DEMO_GUIDE.md`](docs/DEMO_GUIDE.md) — a
step-by-step walkthrough for filling out a config and running it in Databricks.

---

## The separation, in one table

| | Framework folder | This folder |
|---|---|---|
| Config template (blank) | ✅ owns it | ❌ copies from it |
| Filled config | ❌ | ✅ owns it |
| Validator / parser | ✅ | ❌ |
| Metadata DDL (`idee_metaschema`) | ✅ | ❌ |
| Application DDL (`idee_app`) | ❌ | ✅ |
| Sample data | ❌ | ✅ |
| Unit tests | ✅ primary | simple checks only |

A **template** is blank and framework-owned. A **filled config** is populated
for one pipeline and lives here. Once you fill a copy in, it is no longer a
template and must not carry `template` in its name.

---

## Folder layout

```
idee_dbx_app/
├── README.md                              you are here
├── config/                                filled configs, one per pipeline
│   └── customers_landing_to_bronze_config.yaml
├── ddl/                                   application tables (idee_app schema)
│   ├── 01_create_bronze_customer.sql
│   ├── 02_create_silver_customer.sql
│   └── 03_create_quarantine_records.sql
├── data/
│   └── customer_sample.csv
├── notebooks/
│   └── run_sample_pipeline.py
└── output/                                validation and parse output
```

---

## The demo pipeline

`customers_landing_to_bronze_config.yaml` is deliberately the smallest thing that
proves the framework works:

| | |
|---|---|
| Sources | 1 (cloud files, CSV) |
| Targets | 1 Bronze + 1 Silver |
| Columns | 5 |
| Load type | `FULL` — truncate and load |
| DQ engine | `inline` — 3 rules, self-contained |

No incremental logic, no CDC, no append. Those come after this path is signed
off.

### The sample data has deliberate defects

`data/customer_sample.csv` contains three planted problems so the quality rules
visibly fire rather than everything passing silently:

| Row | Defect | Rule that catches it | Action |
|---|---|---|---|
| 1004 | `not-an-email` in the email column | Email address format check | `warn` |
| 1005 | `USA` — three characters, not two | Country code must be two characters | `quarantine` |
| 1002 | Leading/trailing spaces in the name | `trim_indicator: true` on that column | cleaned |

A demo where everything passes proves nothing. This one shows warn, quarantine,
and trim all working.

---

## Running it

### 1. Create the application tables

Run `ddl/` in filename order against your **application** schema
(`idee_app`) — not the metadata schema. Substitute `${catalog}` and
`${app_schema}`; nothing is hardcoded.

### 2. Run the pipeline

Open `notebooks/run_sample_pipeline.py` in Databricks, set the widgets, and run.
It validates this team's config, parses it, and loads the metadata.

Leave `dry_run = true` for the first pass — it prints exactly what would be
written without writing anything.

From a terminal instead:

```bash
cd ../idee_dbx_framework
PYTHONPATH=src python -m idee_dbx.main parse \
  --config ../idee_dbx_app/config/customers_landing_to_bronze_config.yaml \
  --show-sql --catalog medtech_md_scion_dev
```

### 3. What you should see

```
STEP 1 — CONFIG VALIDATION      Result: PASSED
STEP 2 — CONFIG PARSING         10 planned actions:
                                  pipeline_config       1 row
                                  source_config         1 row
                                  target_config         1 row
                                  dataset_config        1 row
                                  column_config         5 rows
                                  quality_rule_config   4 rows
```

---

## Adding another pipeline

1. Copy the template — **do not** copy an existing filled config, which
   invites stale values surviving into the new pipeline:

   ```bash
   cp ../idee_dbx_framework/templates/idee_pipeline_config_template.yaml \
      config/<object>_<load_type>_config.yaml
   ```

2. Fill it in. Every field is commented with meaning, allowed values, and
   whether it is required.
3. Add the Bronze/Silver DDL to `ddl/`.
4. Validate before anything else:

   ```bash
   PYTHONPATH=../idee_dbx_framework/src \
     python -m idee_dbx.main validate --config config/<your file>.yaml
   ```

The validator reports every problem at once rather than stopping at the first,
so one pass tells you everything to fix.

---

## Two schemas, and what goes where

| Schema | Holds | Written by |
|---|---|---|
| `idee_metaschema` | metadata tables only | the framework |
| `idee_app` | Bronze, Silver, Gold, quarantine | this team's pipelines |

Never put business data in the metadata schema, and never put metadata tables
in the application schema. The split is what lets the framework be shared
across teams without their data mingling.
