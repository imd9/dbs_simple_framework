-- =============================================================================
-- 02_create_silver_customer.sql
-- =============================================================================
-- Silver target for scion_customer_bronze_to_silver.
--
-- OWNER      : Application team.
-- SCHEMA     : ${catalog}.${app_schema}
-- PARAMETERS : ${catalog}, ${app_schema}
--
-- THESE COLUMNS MIRROR THE CONFIG
--   That pipeline uses column_mode: explicit, so the names and types below must
--   match the columns: block in customers_bronze_to_silver_config.yaml exactly.
--   Change one and change the other, or the write will fail on a schema
--   mismatch — which is the desired behaviour: a silent mismatch would be worse.
--
-- THE _ COLUMNS ARE WRITTEN BY THE FRAMEWORK
--   Must match ETL_AUDIT_COLUMNS in config_parser.py. They are regenerated
--   here rather than inherited from Bronze, because the config sets
--   exclude_etl_columns: true. Inheriting them would make Silver claim it was
--   loaded when Bronze was.
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${app_schema}.silver_customer (
    customer_id    BIGINT    COMMENT 'Business key. Cast from the Bronze string.',
    customer_name  STRING    COMMENT 'Trimmed.',
    email_address  STRING    COMMENT 'Trimmed. Contains PII.',
    country_code   STRING    COMMENT 'Two-character ISO country code.',
    created_date   TIMESTAMP COMMENT 'Cast from the Bronze string.',

    -- Framework-managed. Regenerated on this hop, not copied from Bronze.
    _ingested_at   TIMESTAMP COMMENT 'When this row was written by this pipeline.',
    _run_id        STRING    COMMENT 'The run that produced it. Joins to pipeline_audit.run_id.',
    _pipeline_id   STRING    COMMENT 'Which pipeline produced it.',
    _source_file   STRING    COMMENT 'Resolved source table this row was read from.'
)
USING DELTA
COMMENT 'Silver: cleaned and typed customer records.'
TBLPROPERTIES (
    'idee.table_role' = 'silver',
    'idee.pipeline'   = 'scion_customer_bronze_to_silver',
    'idee.owner'      = 'application'
);
