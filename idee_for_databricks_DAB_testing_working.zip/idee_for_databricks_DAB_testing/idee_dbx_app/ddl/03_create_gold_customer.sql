-- =============================================================================
-- 03_create_gold_customer.sql
-- =============================================================================
-- Gold target for scion_customer_silver_to_gold.
--
-- OWNER      : Application team.
-- SCHEMA     : ${catalog}.${app_schema}
-- PARAMETERS : ${catalog}, ${app_schema}
--
-- GOLD LAYER
--   The business-ready, curated customer table. All records here have passed
--   Silver's data quality checks. This is the table analysts and dashboards
--   consume. Columns use business-friendly names and all are guaranteed non-null.
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${app_schema}.gold_customer (
    customer_id    STRING    COMMENT 'Business key.',
    customer_name  STRING    COMMENT 'Full customer name, trimmed and validated.',
    email_address  STRING    COMMENT 'Validated email. Contains PII.',
    country_code   STRING    COMMENT 'Two-character ISO country code, validated.',
    created_date   TIMESTAMP COMMENT 'Customer creation timestamp.',

    -- Framework-managed audit columns.
    _ingested_at   TIMESTAMP COMMENT 'When this row was written by this pipeline.',
    _run_id        STRING    COMMENT 'The run that produced it. Joins to pipeline_audit.run_id.',
    _pipeline_id   STRING    COMMENT 'Which pipeline produced it.',
    _source_file   STRING    COMMENT 'Resolved source table this row was read from.'
)
USING DELTA
COMMENT 'Gold: business-ready customer records. All DQ checks passed.'
TBLPROPERTIES (
    'idee.table_role' = 'gold',
    'idee.pipeline'   = 'scion_customer_silver_to_gold',
    'idee.owner'      = 'application'
);
