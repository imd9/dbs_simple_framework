-- =============================================================================
-- 04_create_bronze_customer_bitbucket.sql
-- =============================================================================
-- Bronze target for customer data fetched from Bitbucket via connector.
-- Used by customer_pipeline_combined.yaml (Task 1: bitbucket_to_bronze).
--
-- PARAMETERS : ${catalog}, ${app_schema}
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${app_schema}.bronze_customer_external (
    CUSTOMER_ID    STRING COMMENT 'Raw source value, uncast.',
    CUSTOMER_NAME  STRING COMMENT 'Raw source value, uncast.',
    EMAIL_ADDRESS  STRING COMMENT 'Raw source value, uncast.',
    COUNTRY_CODE   STRING COMMENT 'Raw source value, uncast.',
    CREATED_DATE   STRING COMMENT 'Raw source value, uncast.',

    _ingested_at   TIMESTAMP COMMENT 'When this row was written by this pipeline.',
    _run_id        STRING    COMMENT 'The run that produced it.',
    _pipeline_id   STRING    COMMENT 'Which pipeline produced it.',
    _source_file   STRING    COMMENT 'Resolved source path this row was read from.'
)
USING DELTA
COMMENT 'Bronze: raw customer extracts from Bitbucket source.'
TBLPROPERTIES (
    'idee.table_role' = 'bronze',
    'idee.pipeline'   = 'customer_etl_combined',
    'idee.source'     = 'bitbucket',
    'idee.owner'      = 'application'
);
