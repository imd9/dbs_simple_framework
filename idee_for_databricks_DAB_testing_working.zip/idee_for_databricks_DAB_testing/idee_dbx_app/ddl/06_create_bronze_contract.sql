-- =============================================================================
-- 06_create_bronze_contract.sql
-- =============================================================================
-- Bronze target for contracts ingestion.
-- All columns STRING — source fidelity preserved. Typing happens in Silver.
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${app_schema}.bronze_contract (
    CONTRACT_ID    STRING COMMENT 'Raw source value, uncast.',
    CUSTOMER_ID    STRING COMMENT 'Raw source value, uncast.',
    CONTRACT_TYPE  STRING COMMENT 'Raw source value, uncast.',
    START_DATE     STRING COMMENT 'Raw source value, uncast.',
    END_DATE       STRING COMMENT 'Raw source value, uncast.',
    ANNUAL_VALUE   STRING COMMENT 'Raw source value, uncast.',
    STATUS         STRING COMMENT 'Raw source value, uncast.',

    -- Framework-managed audit columns
    _ingested_at   TIMESTAMP COMMENT 'When this row was written by this pipeline.',
    _run_id        STRING    COMMENT 'The run that produced it.',
    _pipeline_id   STRING    COMMENT 'Which pipeline produced it.',
    _source_file   STRING    COMMENT 'Resolved source path this row was read from.'
)
USING DELTA
COMMENT 'Bronze: raw contract records, source fidelity preserved.'
TBLPROPERTIES (
    'idee.table_role' = 'bronze',
    'idee.pipeline'   = 'contracts_etl',
    'idee.owner'      = 'application'
);
