-- =============================================================================
-- 07_create_silver_contract.sql
-- =============================================================================
-- Silver: cleaned, typed, deduplicated contract records.
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${app_schema}.silver_contract (
    contract_id    STRING    COMMENT 'Unique contract identifier.',
    customer_id    STRING    COMMENT 'FK to gold_customer.customer_id.',
    contract_type  STRING    COMMENT 'Type of contract (Service Agreement, Maintenance, etc.).',
    start_date     DATE      COMMENT 'Contract effective start date.',
    end_date       DATE      COMMENT 'Contract end date.',
    annual_value   DECIMAL(12,2) COMMENT 'Annual contract value in USD.',
    status         STRING    COMMENT 'Contract status (ACTIVE, EXPIRED, PENDING).',

    -- Framework-managed audit columns
    _ingested_at   TIMESTAMP COMMENT 'When this row was written by this pipeline.',
    _run_id        STRING    COMMENT 'The run that produced it.',
    _pipeline_id   STRING    COMMENT 'Which pipeline produced it.',
    _source_file   STRING    COMMENT 'Resolved source path this row was read from.'
)
USING DELTA
COMMENT 'Silver: validated and typed contract records.'
TBLPROPERTIES (
    'idee.table_role' = 'silver',
    'idee.pipeline'   = 'contracts_etl',
    'idee.owner'      = 'application'
);
