-- =============================================================================
-- 08_create_gold_contract.sql
-- =============================================================================
-- Gold: business-ready contract records enriched with customer details.
-- Joins silver_contract with gold_customer on customer_id.
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${app_schema}.gold_contract (
    contract_id    STRING        COMMENT 'Unique contract identifier.',
    customer_id    STRING        COMMENT 'FK to gold_customer.',
    contract_type  STRING        COMMENT 'Type of contract.',
    start_date     DATE          COMMENT 'Contract effective start date.',
    end_date       DATE          COMMENT 'Contract end date.',
    annual_value   DECIMAL(12,2) COMMENT 'Annual contract value in USD.',
    status         STRING        COMMENT 'Contract status (ACTIVE, EXPIRED, PENDING).',

    -- Framework-managed audit columns
    _ingested_at   TIMESTAMP COMMENT 'When this row was written by this pipeline.',
    _run_id        STRING    COMMENT 'The run that produced it.',
    _pipeline_id   STRING    COMMENT 'Which pipeline produced it.',
    _source_file   STRING    COMMENT 'Resolved source path this row was read from.'
)
USING DELTA
COMMENT 'Gold: contract records enriched with customer details from gold_customer.'
TBLPROPERTIES (
    'idee.table_role' = 'gold',
    'idee.pipeline'   = 'contracts_etl',
    'idee.owner'      = 'application'
);
