# iDEE for Databricks — Framework & Application Status

**Last updated:** 2026-08-18

---

## ✅ Completed

### Framework (`idee_dbx_framework/`)

- **Config validation** — YAML configs validated against JSON schema before parsing
- **Config parser** — Auto-detects multi-hop vs single-hop YAML; generates SQL per hop
- **Metadata loader** — Inserts parsed pipeline plans into Unity Catalog metadata tables
- **Runtime engine** — Executes ETL hops (Landing → Bronze → Silver → Gold) with read/write tracking
- **Source readers** — Landing (CSV/Parquet from Volumes), Table-to-Table, Bitbucket connector
- **DDL scripts** — 11 framework metadata tables + application tables, all idempotent (CREATE IF NOT EXISTS)
- **High-level API functions** in `main.py`:
  - `setup_metadata_tables()` — runs framework DDL scripts
  - `setup_app_tables()` — runs application DDL scripts
  - `load_all_configs()` — scans folder, validates, parses, and loads ALL YAML configs
  - `execute_all_pipelines()` — runs all registered ETL pipelines
  - `run_pipeline()` — **single entry point** wrapping all steps into one call
- **Wheel packaging** — `pyproject.toml` added; framework builds as `idee_dbx-0.1.0-py3-none-any.whl`
- **Wheel deployed to Volume** — `/Volumes/medtech_md_scion_dev/idee_metaschema/idee_framework_wheels/idee_dbx-0.1.0-py3-none-any.whl`

### Application (`idee_dbx_app/`)

- **`pipeline_builder` notebook** — Ojoma's "3 clicks" vision:
  - Cell 1: `%pip install` from Unity Catalog Volume (no hardcoded paths)
  - Cell 2: `from idee_dbx.main import run_pipeline` + one function call with parameterized widgets
  - Zero bootstrap code, zero sys.path manipulation
- **`asset_bundle_commands` notebook** — DABs simulation with 3 separate commands (for framework engineers/debugging)
  - All paths parameterized via `dbutils.widgets`
  - Comments clearly mark each cell as "ASSET BUNDLE COMMAND 1/2/3"
- **`run_sample_pipeline` notebook** — Development/debugging notebook (16 cells, step-by-step)
- **Config files** — `config/active/` contains:
  - `customer_pipeline_combined.yaml` (4 hops: Bitbucket→Bronze, Landing→Bronze, Bronze→Silver, Silver→Gold)
  - `product_pipeline.yaml` (3 hops: Landing→Bronze, Bronze→Silver, Silver→Gold)
- **Application DDLs** — 5 SQL scripts in `ddl/` for bronze/silver/gold customer tables
- **Transform notebooks** — `transform_customer_combined`, `transform_customer_dedup`

### Infrastructure

- **Unity Catalog metadata schema** — `medtech_md_scion_dev.idee_metaschema` (9 tables)
- **Unity Catalog app schema** — `medtech_md_scion_dev.idee_app` (9 tables incl. bronze/silver/gold + quarantine)
- **Volume for wheels** — `medtech_md_scion_dev.idee_metaschema.idee_framework_wheels`
- **Job** — "iDEE Customer ETL (Bitbucket) — Landing to Gold" (Job ID: 722952128708444)
- **Logging** — All commands produce structured terminal output showing progress, file counts, and results

### Demo Readiness

- **Demo for Rashid** — Scheduled (show empty state → run commands → show results)
- **Two personas defined** — Framework user (SCION engineer) vs Framework developer (iDEE team)
- **"3 clicks" story** — Open notebook, run, check catalog

---

## 🚧 In Progress / Pending

### Short-term (this week)

- [ ] **Fix Hop 3 (bronze_combined_to_silver)** — Reads 5 rows but writes 0; likely dedup logic returning empty. Investigate transform notebook.
- [ ] **Dry-run demo with Ojoma** — Practice storytelling before presenting to Rashid
- [ ] **Parameterize Volume path** — The `%pip install /Volumes/...` path should also be a widget or derived dynamically

### Medium-term (next 1–2 weeks)

- [ ] **Option 4: Job cluster libraries** — Attach the wheel as a job library so the production notebook has ZERO install cells. Just `from idee_dbx.main import run_pipeline`.
- [ ] **Option 5: DABs auto-build + deploy** — When Yash/Prasun/Vishal set up Declarative Automation Bundles:
  - `databricks.yml` defines artifacts (wheel build from source)
  - Bundle auto-deploys wheel + creates job + attaches library
  - `databricks bundle deploy` = files copied from Bitbucket + wheel built + job configured
  - `databricks bundle run` = triggers the job (which runs `pipeline_builder`)
- [ ] **Bitbucket integration** — Push all code to Bitbucket repo (configs, DDLs, framework source)
- [ ] **CI/CD pipeline** — On merge to main: rebuild wheel → upload to Volume → trigger job
- [ ] **Two demo notebooks** (Ojoma request):
  - "Brand new setup" — runs everything including DDL creation
  - "Existing setup" — skips DDL, only loads new configs and executes
  - (Currently handled by idempotent DDLs, but could split for clarity)

### Long-term (roadmap)

- [ ] **Auto-generate Databricks Jobs from metadata** — Each pipeline in metadata becomes its own scheduled job
- [ ] **Data quality checks** — Integrate Great Expectations or custom DQ rules per hop
- [ ] **Alerting** — Slack/Teams notifications on pipeline failure
- [ ] **Dashboard** — Pipeline execution history, success rates, row counts over time
- [ ] **AI-assisted YAML generation** — Give Genie/Copilot a template + instructions to generate configs
- [ ] **Handle modified configs** — When an existing YAML is updated, update metadata tables (not just insert)
- [ ] **Multi-environment promotion** — dev → QA → prod with same configs, different catalogs
- [ ] **Versioning** — Track config versions in metadata; rollback capability

---

## Architecture Overview

```
Bitbucket (source of truth)
    │
    ├── config/active/*.yaml     → Pipeline definitions
    ├── ddl/*.sql                → Table creation scripts
    └── idee_dbx_framework/src/  → Framework source code
           │
           │  DABs: databricks bundle deploy
           ▼
    Databricks Workspace
    │
    ├── Volume: idee_dbx-0.1.0.whl  (framework wheel)
    ├── Notebook: pipeline_builder  (entry point)
    │       │
    │       ├── %pip install wheel
    │       └── run_pipeline(spark, ...)
    │               │
    │               ├── Step 1: setup_metadata_tables()
    │               ├── Step 2: setup_app_tables()
    │               ├── Step 3: load_all_configs()
    │               └── Step 4: execute_all_pipelines()
    │
    └── Unity Catalog
            ├── idee_metaschema (metadata tables)
            └── idee_app (bronze/silver/gold tables)
```

---

## Key People

| Person | Role |
| --- | --- |
| Italo Duran | Framework developer, builds iDEE for DBX |
| Yash Yagnik | Application developer, demo partner |
| Ojoma Ali | Technical lead, architecture direction |
| Rashid | Stakeholder, demo audience |
| Prasun / Vishal | DABs setup (Declarative Automation Bundles) |
