# Databricks notebook source
# DBTITLE 1,iDEE Pipeline Builder
# MAGIC %md
# MAGIC # iDEE — Pipeline Builder
# MAGIC
# MAGIC **This is the entry point.** Open this notebook, configure your parameters, and run.
# MAGIC
# MAGIC One import. One command. Everything happens.
# MAGIC
# MAGIC ---
# MAGIC **What happens when you run this:**
# MAGIC 1. Creates metadata + application tables (idempotent)
# MAGIC 2. Validates and loads all YAML configs into metadata
# MAGIC 3. Executes all registered ETL pipelines (Landing → Bronze → Silver → Gold)
# MAGIC 4. Prints logs showing exactly what happened at each step

# COMMAND ----------

# DBTITLE 1,Configuration Install idee dbx Framework Package
# Install the iDEE framework directly from source.
# Any edits to idee_dbx_framework/src/ take effect on next run — no wheel rebuild needed.
# When deployed via DAB, the bundle builds the wheel automatically (see databricks.yml).

%pip install ../../idee_dbx_framework --force-reinstall --no-cache-dir --no-deps -q
dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Run Pipeline
# ---------------------------------------------------------------------------
# Parameters — configure these for your environment
# ---------------------------------------------------------------------------
dbutils.widgets.text("catalog", "medtech_md_scion_dev", "Catalog")
dbutils.widgets.text("metadata_schema", "idee_metaschema", "Metadata Schema")
dbutils.widgets.text("app_schema", "idee_app", "Application Schema")
dbutils.widgets.text("config_dir", "../config/active", "Config Directory")
dbutils.widgets.text("framework_ddl_dir", "../../idee_dbx_framework/ddl/metadata", "Framework DDL Directory")
dbutils.widgets.text("app_ddl_dir", "../ddl", "Application DDL Directory")
dbutils.widgets.text("schema_dir", "../../idee_dbx_framework/schema", "Schema Directory")
dbutils.widgets.text("task_name", "", "Task Name (empty = run all)")

# =============================================================================
# ONE COMMAND — Import the framework and run the entire pipeline.
# When task_name is empty: full execution (all tasks + job registration).
# When task_name is set: single-task mode (used by multi-task Databricks Jobs).
# =============================================================================
task_name = dbutils.widgets.get("task_name").strip()

if task_name:
    # Single-task mode — called by each task in the multi-task Job DAG
    from idee_dbx.main import run_single_task  # noqa: E402
    run_single_task(
        spark,
        catalog     = dbutils.widgets.get("catalog"),
        metadata_schema = dbutils.widgets.get("metadata_schema"),
        app_schema  = dbutils.widgets.get("app_schema"),
        config_dir  = dbutils.widgets.get("config_dir"),
        task_name   = task_name,
        framework_ddl_dir = dbutils.widgets.get("framework_ddl_dir"),
        app_ddl_dir = dbutils.widgets.get("app_ddl_dir"),
        schema_dir  = dbutils.widgets.get("schema_dir"),
        dbutils     = dbutils,
    )
else:
    # Full execution mode — runs all tasks + registers jobs
    from idee_dbx.main import run_pipeline  # noqa: E402
    run_pipeline(
        spark,
        catalog     = dbutils.widgets.get("catalog"),
        metadata_schema = dbutils.widgets.get("metadata_schema"),
        app_schema  = dbutils.widgets.get("app_schema"),
        config_dir  = dbutils.widgets.get("config_dir"),
        framework_ddl_dir = dbutils.widgets.get("framework_ddl_dir"),
        app_ddl_dir = dbutils.widgets.get("app_ddl_dir"),
        schema_dir  = dbutils.widgets.get("schema_dir"),
        dbutils     = dbutils,
    )