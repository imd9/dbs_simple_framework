# Databricks notebook source
# MAGIC %md
# MAGIC # transform_contract_enrichment
# MAGIC Custom transform notebook for the iDEE framework (`column_mode: notebook`).
# MAGIC
# MAGIC Enriches `silver_contract` by joining with `gold_customer` on `customer_id`.
# MAGIC The result is a business-ready Gold table with contract details + customer context.
# MAGIC
# MAGIC **Cross-pipeline dependency:** This notebook reads from `gold_customer`, which is
# MAGIC produced by the `customer_etl_combined` pipeline. That pipeline must run first.

# COMMAND ----------

# DBTITLE 1,Parameters and sources
from pyspark.sql import functions as F

dbutils.widgets.text("staging_table", "medtech_md_scion_dev.idee_app._staging_manual_run", "Staging table")
dbutils.widgets.text("run_id", "manual", "Run ID")

STAGING_TABLE = dbutils.widgets.get("staging_table")
RUN_ID = dbutils.widgets.get("run_id")

SILVER_CONTRACT = "medtech_md_scion_dev.idee_app.silver_contract"
GOLD_CUSTOMER = "medtech_md_scion_dev.idee_app.gold_customer"

print(f"Run ID          : {RUN_ID}")
print(f"Staging table   : {STAGING_TABLE}")
print(f"Source (Silver) : {SILVER_CONTRACT}")
print(f"Join target     : {GOLD_CUSTOMER}")

# COMMAND ----------

# DBTITLE 1,Join silver_contract with gold_customer
# Read silver contracts (drop ETL audit columns for the join)
ETL_COLS = {"_ingested_at", "_run_id", "_pipeline_id", "_source_file"}

df_contracts = spark.table(SILVER_CONTRACT)
business_cols = [c for c in df_contracts.columns if c not in ETL_COLS]
df_contracts = df_contracts.select(*business_cols)

# Read gold_customer (only the columns we need for enrichment)
df_customers = spark.table(GOLD_CUSTOMER).select(
    F.col("customer_id"),
    F.col("customer_name"),
    F.col("email_address"),
    F.col("country_code"),
)

# LEFT JOIN: keep all contracts, enrich with customer details where available
df_enriched = df_contracts.join(
    df_customers,
    on="customer_id",
    how="left",
)

# Select final column order matching gold_contract DDL
df_enriched = df_enriched.select(
    "contract_id",
    "customer_id",
    "customer_name",
    "email_address",
    "country_code",
    "contract_type",
    "start_date",
    "end_date",
    "annual_value",
    "status",
)

total = df_enriched.count()
matched = df_enriched.filter(F.col("customer_name").isNotNull()).count()
print(f"Enriched rows   : {total}")
print(f"Customer match  : {matched}/{total}")

# COMMAND ----------

# DBTITLE 1,Write to staging table
if total == 0:
    raise ValueError(
        f"Silver contract table is empty. Ensure {SILVER_CONTRACT} is populated "
        f"before running the Gold enrichment step."
    )

(
    df_enriched.write.mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(STAGING_TABLE)
)

print(f"\nWrote {total} rows to {STAGING_TABLE}.")
print("Framework takes over: audit columns, DQ rules, target write.")