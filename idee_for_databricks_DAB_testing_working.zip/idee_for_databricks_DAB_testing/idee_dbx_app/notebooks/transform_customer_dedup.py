# Databricks notebook source
# MAGIC %md
# MAGIC # transform_customer_dedup
# MAGIC Custom transform notebook for the iDEE framework (column_mode: notebook).
# MAGIC
# MAGIC Reads BOTH bronze tables (external + landing), UNIONs them, and detects
# MAGIC cross-source duplicates: rows where the same CUSTOMER_ID appears in BOTH sources.
# MAGIC Those rows are flagged `_is_duplicate = true` so the DQ engine can quarantine them.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

dbutils.widgets.text("staging_table", "medtech_md_scion_dev.idee_app._staging_manual_run", "Staging table")
dbutils.widgets.text("run_id", "manual", "Run ID")

STAGING_TABLE = dbutils.widgets.get("staging_table")
RUN_ID = dbutils.widgets.get("run_id")

BRONZE_EXTERNAL = "medtech_md_scion_dev.idee_app.bronze_customer_external"
BRONZE_LANDING = "medtech_md_scion_dev.idee_app.bronze_customer_landing"

print(f"Run ID          : {RUN_ID}")
print(f"Staging table   : {STAGING_TABLE}")
print(f"Source 1 (Ext)  : {BRONZE_EXTERNAL}")
print(f"Source 2 (Land) : {BRONZE_LANDING}")

# COMMAND ----------

# DBTITLE 1,Read and standardize both bronze tables
ETL_COLS = {"_ingested_at", "_run_id", "_pipeline_id", "_source_file"}

def read_bronze(table_name, source_label):
    """Read a bronze table, drop ETL audit columns, tag with source origin."""
    df = spark.table(table_name)
    business_cols = [c for c in df.columns if c not in ETL_COLS]
    df = df.select(*business_cols)
    df = df.withColumn("_source_origin", F.lit(source_label))
    return df

# --- External source: already uses the elongated names ---
df_ext = read_bronze(BRONZE_EXTERNAL, "external")
df_external = df_ext.select(
    F.col("CUSTOMER_ID").alias("customer_id"),
    F.col("CUSTOMER_NAME").alias("customer_name"),
    F.col("EMAIL_ADDRESS").alias("email_address"),
    F.col("COUNTRY_CODE").alias("country_code"),
    F.col("CREATED_DATE").alias("created_date"),
    F.col("_source_origin"),
)

# --- Landing (SharePoint): map nicknames → elongated names ---
df_land = read_bronze(BRONZE_LANDING, "landing")
df_landing = df_land.select(
    F.col("CUST_ID").alias("customer_id"),
    F.col("CUST_NAME").alias("customer_name"),
    F.col("CUST_EMAIL").alias("email_address"),
    F.col("REGION").alias("country_code"),
    F.col("CREATED_DT").alias("created_date"),
    F.col("_source_origin"),
)

print(f"External rows  : {df_external.count()}")
print(f"Landing rows   : {df_landing.count()}")

# COMMAND ----------

# DBTITLE 1,Union, detect cross-source duplicates
combined_df = df_external.unionByName(df_landing)

# Detect duplicates: same customer_id appearing in BOTH sources
dup_window = Window.partitionBy("customer_id")
combined_df = combined_df.withColumn(
    "_source_count", F.size(F.collect_set("_source_origin").over(dup_window))
)
combined_df = combined_df.withColumn(
    "_is_duplicate", F.col("_source_count") > 1
).drop("_source_count")

total = combined_df.count()
dupes = combined_df.filter(F.col("_is_duplicate")).count()
print(f"Combined rows  : {total}")
print(f"Duplicates     : {dupes} (will be quarantined)")
print(f"Clean rows     : {total - dupes}")

# COMMAND ----------

if total == 0:
    raise ValueError(
        f"Both bronze tables produced 0 rows. Check that {BRONZE_EXTERNAL} "
        f"and {BRONZE_LANDING} are populated."
    )

(
    combined_df.write.mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(STAGING_TABLE)
)

print(f"\nWrote {total} rows to {STAGING_TABLE}.")
print("Framework takes over: audit columns, DQ rules (quarantine dupes), target write.")