# iDEE for Databricks — Framework

**Version 0.1.0** · config schemas v0.1 + v0.2 · reusable logic owned by the framework team.

Everything in this folder is shared across application teams. Application teams
**read** from here and **copy** the template; they do not modify anything in it.

For the downstream user's view, see `../idee_dbx_app/`.

---

## What the framework does today

It turns a filled YAML config into rows in the metadata tables, in three stages:

```
  filled config.yaml
          │
          ▼
   ┌─────────────┐   Is this config legal?
   │  VALIDATE   │   → checks against a versioned schema
   └─────────────┘   → fails loudly, lists every problem at once
          │
          ▼
   ┌─────────────┐   What metadata actions does it produce?
   │    PARSE    │   → builds a plan of MERGE statements
   └─────────────┘   → executes nothing
          │
          ▼
   ┌─────────────┐   Apply the plan
   │    LOAD     │   → writes to catalog.idee_metaschema.*
   └─────────────┘   → supports dry run
```

**Scope note.** v0.1 loads *metadata*, not data. There is no ingestion engine
yet — Bronze and Silver movement is the next increment. This is deliberate: the
config path is proven end to end before anything is built on top of it.

---

## Folder layout

```
idee_dbx_framework/
├── README.md                 you are here
├── CHANGELOG.md              version history + versioning policy
├── VERSION                   framework version (0.1.0)
├── requirements.txt          PyYAML, pytest
├── pytest.ini                test configuration
│
├── templates/                blank config template users copy
│   └── idee_pipeline_config_template.yaml
│
├── schema/                   versioned config contracts
│   └── pipeline_config_schema_v0_1.yaml
│
├── src/idee_dbx/             the framework code
│   ├── config_validator.py     is this config legal?
│   ├── config_parser.py        what actions does it produce?
│   ├── metadata_loader.py      apply them (only module touching Spark)
│   └── main.py                 CLI entry point
│
├── ddl/metadata/             framework-owned DDL (idee_metaschema)
│   ├── 00_verify_prerequisites.sql
│   ├── 01..05_create_*.sql
│   └── 99_verify_metadata_tables.sql
│
├── tests/                    PyTest suite
│   ├── conftest.py
│   ├── test_config_validator.py
│   ├── test_config_parser.py
│   └── fixtures/             valid + invalid configs
│
├── notebooks/
│   └── run_config_pipeline.py
│
└── docs/
    └── NAMING_CONVENTIONS.md
```

---

## Quick start

### 1. Install the metadata tables (once per environment)

Run the scripts in `ddl/metadata/` in filename order, substituting your
catalog and schema. Nothing is hardcoded:

```sql
-- with ${catalog} = medtech_md_scion_dev, ${metadata_schema} = idee_metaschema
```

`00_verify_prerequisites.sql` runs first and **creates nothing** — it confirms
the catalog and both schemas already exist. They are provisioned by the platform
team, not by this framework. If a schema is missing, stop and check the name
before running `01`–`05`.

Confirm the tables afterwards with `99_verify_metadata_tables.sql`.

### 2. Onboard a dataset

```bash
cp templates/idee_pipeline_config_template.yaml \
   ../idee_dbx_app/config/<pipeline_name>_config.yaml
```

Fill it in. Every field is commented with its meaning, allowed values, and
whether it is required.

### 3. Validate, parse, load

```bash
cd idee_dbx_framework

# Is it legal?
PYTHONPATH=src python -m idee_dbx.main validate \
  --config ../idee_dbx_app/config/customers_landing_to_bronze_config.yaml

# What would it do?
PYTHONPATH=src python -m idee_dbx.main parse \
  --config ../idee_dbx_app/config/customers_landing_to_bronze_config.yaml \
  --show-sql --catalog medtech_md_scion_dev

# Apply it (drop --dry-run to write for real)
PYTHONPATH=src python -m idee_dbx.main load \
  --config ../idee_dbx_app/config/customers_landing_to_bronze_config.yaml \
  --catalog medtech_md_scion_dev --metadata-schema idee_metaschema --dry-run
```

Inside Databricks, run `notebooks/run_config_pipeline.py` — same three stages,
driven by widgets.

---

## The metadata model

Six config tables plus two audit tables at different grains. A single config file maps onto
the first four:

| YAML section | Table | Rows |
|---|---|---|
| `pipeline:` | `pipeline_config` | 1 |
| `source:` | `source_config` | 1 |
| `target:` | `target_config` | 1 |
| `dataset:` | `dataset_config` | 1 |
| `columns:` | `column_config` | one per column (explicit mode only) |
| `quality:` | `quality_rule_config` | one per rule (inline engine only) |
| — | `config_parse_audit` | written when a config is parsed |
| — | `pipeline_audit` | written at run time, never configured |

**YAML keys are named exactly after their target table columns.** The parser
maps key to column with no translation layer. Renaming a key breaks the parse.

---

## Config schema versioning

Every config declares the contract it was written against:

```yaml
config_version: "0.1"
```

The validator loads the matching `schema/pipeline_config_schema_v0_1.yaml` and
checks against it. Validation rules are **data, not code** — adding a new config
format means adding a schema file, not editing Python.

When the format changes, add a new schema file and leave the old one in place.
Configs already deployed keep validating against the version they declare. The
policy is in `CHANGELOG.md`.

---

## Data quality: three engines

The `quality.engine` field decides where rules come from:

| `engine` | Rules live in | Format | Requires |
|---|---|---|---|
| `native` | a rule pack in a `dq_rules/` folder | YAML | `rules_path` |
| `great_expectations` | a GX expectation suite in Databricks | JSON | `suite_name` |
| `inline` | the config file itself | YAML | `rules` |

Only `inline` writes rows to `quality_rule_config`; the other two keep their
rules externally and are read at run time.

**Runtime enforcement is not implemented in v0.1.** All three engines validate
and parse correctly, but nothing yet executes the rules against data.

---

## Running the tests

```bash
cd idee_dbx_framework
pip install -r requirements.txt
python -m pytest
```

`pytest.ini` puts `src/` on the path, so no install step is needed.

For running the suite **inside Databricks** — including the workspace-storage
gotchas — see [`docs/TESTING_GUIDE.md`](docs/TESTING_GUIDE.md).

Coverage: happy path, version handling, required fields, type checking (including
that `bool` is not accepted as `int` — it subclasses `int` in Python), enums,
conditional requirements, cross-field integrity, warnings, malformed files, and
the validator/parser contract. Fixtures live in `tests/fixtures/`.

One test asserts that the **blank template fails validation** — otherwise
someone could deploy an unfilled template and the framework would accept it.

---

## Conventions

Full detail in `docs/NAMING_CONVENTIONS.md`. The essentials:

- YAML we author uses `.yaml`, never `.yml`. Only tool-mandated names deviate.
- Folders are lowercase `snake_case`.
- SQL is `NN_verb_object.sql`, run in filename order.
- Catalog and schema are **always parameters**, never hardcoded.
- IDs (`source_id`, `object_id`) are stable and never reused.

---

## What is not here, and why

Deferred until the config path is proven and the platform is ready:

| Not here | Waiting on |
|---|---|
| Databricks Asset Bundles, CI/CD | Bitbucket repos and AD groups |
| Bronze/Silver ingestion engines | this skeleton being signed off |
| Append, incremental, CDC runtime | full refresh working first |
| DQ runtime enforcement | ingestion engine |
| Gold layer modelling | Silver working |

The structure is deliberately repo-shaped so the move to Bitbucket is a copy,
not a redesign.
