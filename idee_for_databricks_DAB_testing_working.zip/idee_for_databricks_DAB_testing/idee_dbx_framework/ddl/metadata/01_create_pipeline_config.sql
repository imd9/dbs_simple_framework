-- =============================================================================
-- 01_create_pipeline_config.sql
-- =============================================================================
-- One row per TASK. Tasks are grouped under a shared pipeline_id (one per YAML).
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
--
-- pipeline_id = parent pipeline (one per YAML, from pipeline_name + config file name)
-- task_id     = unique per task (auto-generated from pipeline_name + task_name + config file name)
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.pipeline_config (
    pipeline_id       STRING  NOT NULL COMMENT 'Parent pipeline. One per YAML. Hash of pipeline_name + config file name.',
    task_id           STRING  NOT NULL COMMENT 'Auto-generated. Unique per task. Hash of pipeline_name + task_name + config file name.',
    task_name         STRING  NOT NULL COMMENT 'Short task name from YAML (e.g. bitbucket_to_bronze).',
    pipeline_name     STRING  NOT NULL COMMENT 'Full qualified name (e.g. customer_etl_combined_bitbucket_to_bronze).',
    description       STRING           COMMENT 'What this task does.',
    application       STRING           COMMENT 'Business application or use case this belongs to.',
    team              STRING           COMMENT 'Owning team.',
    owner_email       STRING           COMMENT 'Contact for failures.',
    schedule          STRING           COMMENT 'Intended schedule. Recorded in v0.1, not enforced.',
    tags              STRING           COMMENT 'Free-form tags, flattened as k=v;k=v.',
    config_file_name  STRING  NOT NULL COMMENT 'YAML file name. Part of the identity.',
    config_file_path  STRING  NOT NULL COMMENT 'Full path to the YAML. Lineage.',
    config_version    STRING           COMMENT 'Schema version the config declared.',
    active            BOOLEAN NOT NULL COMMENT 'FALSE = skip this task at run time.',
    created_at        TIMESTAMP        COMMENT 'Row insert time.',
    updated_at        TIMESTAMP        COMMENT 'Row last update time.',
    CONSTRAINT pk_pipeline_config PRIMARY KEY (task_id) RELY
)
USING DELTA
COMMENT 'iDEE metadata: pipeline tasks. One row per task, grouped by pipeline_id.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'metadata',
    'idee.owner'                 = 'framework'
);
