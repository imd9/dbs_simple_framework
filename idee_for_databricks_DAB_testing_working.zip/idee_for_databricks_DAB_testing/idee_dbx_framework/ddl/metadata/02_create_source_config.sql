-- =============================================================================
-- 02_create_source_config.sql
-- =============================================================================
-- Where a pipeline reads FROM.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
--
-- source_id hashes what the source POINTS AT, not which pipeline uses it, so
-- two pipelines reading the same location share a source_id. That is what
-- makes a source reusable.
--
-- Note source_type includes delta_table: reading FROM a table is how
-- bronze->silver and silver->gold pipelines work. Nothing here names a layer.
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.source_config (
    source_id           STRING  NOT NULL COMMENT 'Framework-generated. Hash of type + connection + location.',
    pipeline_id         STRING  NOT NULL COMMENT 'FK to pipeline_config (parent pipeline).',
    task_id             STRING  NOT NULL COMMENT 'FK to pipeline_config.task_id (unique per task).',
    source_name         STRING  NOT NULL COMMENT 'Friendly label.',
    source_description  STRING           COMMENT 'What this source is.',
    source_type         STRING  NOT NULL COMMENT 'cloud_files | delta_table | jdbc | lakeflow_connect | kafka | api',
    connection_ref      STRING           COMMENT 'UC connection name or secret scope ref. Never a raw credential.',
    root_path           STRING           COMMENT 'Root location for file sources.',
    source_table        STRING           COMMENT 'Three-part table name for table sources.',
    file_format         STRING           COMMENT 'csv | json | parquet | delta | avro',
    landing_required    BOOLEAN          COMMENT 'TRUE = stage into a landing volume before reading.',
    config_file_path    STRING  NOT NULL COMMENT 'Lineage back to the YAML.',
    created_at          TIMESTAMP        COMMENT 'Row insert time.',
    updated_at          TIMESTAMP        COMMENT 'Row last update time.',
    CONSTRAINT pk_source_config PRIMARY KEY (source_id) RELY
)
USING DELTA
COMMENT 'iDEE metadata: sources. Where each pipeline reads from.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'metadata',
    'idee.owner'                 = 'framework'
);
