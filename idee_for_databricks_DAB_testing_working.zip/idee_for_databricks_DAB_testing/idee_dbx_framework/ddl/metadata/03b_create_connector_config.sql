-- =============================================================================
-- 03b_create_connector_config.sql
-- =============================================================================
-- External data connectors that fetch files from remote sources.
-- Mirrors the original iDEE Connector_Definition pattern.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
--
-- The connector_configuration column holds a JSON object with all flexible
-- settings (URLs, filenames, auth details) so the schema stays stable as we
-- add new connector types.
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.connector_config (
    connector_id              STRING        NOT NULL  COMMENT 'Framework-generated. Deterministic hash ID.',
    connector_name            STRING        NOT NULL  COMMENT 'Unique connector name (from YAML pipeline_name + connector_type).',
    connector_description     STRING                  COMMENT 'Optional description of this connector.',
    connector_type_id         STRING        NOT NULL  COMMENT 'Connector type: bitbucket_http | github | gitlab | sharepoint | s3_http.',
    data_source_id            STRING        NOT NULL  COMMENT 'FK to source_config.source_id.',
    connector_configuration   STRING        NOT NULL  COMMENT 'JSON object: {secret_scope, secret_key, files: [{url, landing_filename, active}]}.',
    create_user_id            STRING        NOT NULL  COMMENT 'User who created this connector config.',
    create_timestamp          TIMESTAMP     NOT NULL  COMMENT 'Row creation time.',
    last_update_user_id       STRING        NOT NULL  COMMENT 'User who last updated this connector config.',
    last_update_timestamp     TIMESTAMP     NOT NULL  COMMENT 'Row last update time.',
    CONSTRAINT pk_connector_config PRIMARY KEY (connector_id) RELY
)
USING DELTA
COMMENT 'iDEE metadata: connector definitions. Mirrors original iDEE_Connector_Definition.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'metadata',
    'idee.owner'                 = 'framework'
);
