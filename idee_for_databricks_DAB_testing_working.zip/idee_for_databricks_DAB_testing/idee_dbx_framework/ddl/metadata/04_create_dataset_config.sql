-- =============================================================================
-- 04_create_dataset_config.sql
-- =============================================================================
-- What to process and how. The unit of work.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
--
-- column_mode is the single field that decides how columns are handled, and
-- replaces the earlier trio of allow_select_star / allow_select_columns /
-- allow_custom_notebook booleans, which could contradict each other:
--   star     -> pass every source column through
--   explicit -> use column_config for rename and cast
--   notebook -> run the referenced notebook (recorded in v0.1, not executed)
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.dataset_config (
    dataset_id           STRING  NOT NULL COMMENT 'Framework-generated. Hash of pipeline_id + object_name.',
    pipeline_id          STRING  NOT NULL COMMENT 'FK to pipeline_config (parent pipeline).',
    task_id              STRING  NOT NULL COMMENT 'FK to pipeline_config.task_id (unique per task).',
    source_id            STRING  NOT NULL COMMENT 'FK to source_config.',
    target_id            STRING  NOT NULL COMMENT 'FK to target_config.',
    object_name          STRING  NOT NULL COMMENT 'Logical dataset name.',
    description          STRING           COMMENT 'What this dataset is.',
    ingestion_method     STRING  NOT NULL COMMENT 'autoloader | delta_read | jdbc | lakeflow_connect | kafka | api',
    load_type            STRING  NOT NULL COMMENT 'FULL | INCREMENTAL | CDC | SNAPSHOT',
    column_mode          STRING  NOT NULL COMMENT 'star | explicit | notebook',
    primary_key          STRING           COMMENT 'Business key column(s), comma-separated. Composite keys allowed.',
    incremental_column   STRING           COMMENT 'Watermark column. Required for INCREMENTAL.',
    source_path          STRING           COMMENT 'File or pattern within the source root_path.',
    trim_all             BOOLEAN          COMMENT 'TRUE = trim every string column.',
    exclude_etl_columns  BOOLEAN          COMMENT 'TRUE = strip upstream ETL audit columns before writing. See NOTE.',
    dq_engine            STRING           COMMENT 'Which DQ engine this config chose: inline | native | great_expectations.',
    dq_aliases           STRING           COMMENT 'DQ alias map, flattened as alias=col1,col2;alias=col3. See NOTE.',
    notebook_name        STRING           COMMENT 'Notebook name when column_mode = notebook.',
    notebook_path        STRING           COMMENT 'Notebook path. Content is versioned in Bitbucket, not stored here.',
    active               BOOLEAN NOT NULL COMMENT 'FALSE = skip at run time.',
    config_file_path     STRING  NOT NULL COMMENT 'Lineage back to the YAML.',
    created_at           TIMESTAMP        COMMENT 'Row insert time.',
    updated_at           TIMESTAMP        COMMENT 'Row last update time.',
    CONSTRAINT pk_dataset_config PRIMARY KEY (dataset_id) RELY
)
USING DELTA
COMMENT 'iDEE metadata: datasets. What each pipeline processes and how.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'metadata',
    'idee.owner'                 = 'framework'
);

-- NOTE on dq_aliases:
--   Quality rule expressions are stored with {alias} placeholders intact,
--   because which physical column an alias resolves to is only knowable at run
--   time. The alias map therefore has to travel with the metadata — without it
--   the runtime DQ engine cannot resolve the placeholders it was handed.
--
-- NOTE on exclude_etl_columns:
--   ETL audit columns (_ingested_at, _run_id, _pipeline_id, _source_file)
--   record when a row was loaded and by which run. On a table-to-table hop a
--   plain SELECT * would copy the UPSTREAM values forward, so the new table
--   claims it was loaded when the old one was. Excluding them on read and
--   regenerating them on write keeps the audit trail honest.
