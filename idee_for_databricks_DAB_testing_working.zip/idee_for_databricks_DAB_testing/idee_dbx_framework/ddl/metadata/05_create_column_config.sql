-- =============================================================================
-- 05_create_column_config.sql
-- =============================================================================
-- One row per column, populated ONLY when column_mode = explicit.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
--
-- star and notebook modes produce no rows here: star passes everything
-- through, and notebook mode delegates column selection to the notebook.
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.column_config (
    dataset_id        STRING  NOT NULL COMMENT 'FK to dataset_config.',
    pipeline_id       STRING  NOT NULL COMMENT 'FK to pipeline_config (parent pipeline).',
    task_id           STRING  NOT NULL COMMENT 'FK to pipeline_config.task_id (unique per task).',
    source_column     STRING  NOT NULL COMMENT 'Column name exactly as it appears in the source.',
    target_column     STRING  NOT NULL COMMENT 'Standardised name in the target.',
    target_type       STRING  NOT NULL COMMENT 'STRING | BIGINT | INT | DOUBLE | DECIMAL | TIMESTAMP | DATE | BOOLEAN',
    column_position   INT     NOT NULL COMMENT 'Order in the YAML = order in the target.',
    config_file_path  STRING  NOT NULL COMMENT 'Lineage back to the YAML.',
    created_at        TIMESTAMP        COMMENT 'Row insert time.',
    updated_at        TIMESTAMP        COMMENT 'Row last update time.',
    CONSTRAINT pk_column_config PRIMARY KEY (dataset_id, source_column) RELY
)
USING DELTA
COMMENT 'iDEE metadata: explicit column mapping. Only for column_mode = explicit.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'metadata',
    'idee.owner'                 = 'framework'
);
