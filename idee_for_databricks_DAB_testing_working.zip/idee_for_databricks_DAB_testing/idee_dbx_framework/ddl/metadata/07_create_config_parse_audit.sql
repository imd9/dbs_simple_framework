-- =============================================================================
-- 07_create_config_parse_audit.sql
-- =============================================================================
-- AUDIT TABLE 1 OF 2 — the metadata side.
--
-- One row per attempt to parse and load a YAML config. Answers: which file was
-- parsed, when, did it succeed, how long did it take, what version was it?
--
-- This is a DIFFERENT GRAIN from pipeline_audit. This table is about the
-- CONFIG being read; pipeline_audit is about DATA being moved. Keeping them
-- separate is deliberate: parsing a config and running a pipeline are separate
-- events that fail for different reasons and are investigated by different
-- people.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.config_parse_audit (
    parse_id            STRING    NOT NULL COMMENT 'Unique per parse attempt.',
    config_file_name    STRING    NOT NULL COMMENT 'YAML file name.',
    config_file_path    STRING    NOT NULL COMMENT 'Full path to the YAML.',
    config_version      STRING             COMMENT 'Schema version the config declared.',
    pipeline_id         STRING             COMMENT 'Resolved pipeline, when parsing got far enough.',
    pipeline_name       STRING             COMMENT 'Resolved pipeline name.',
    action              STRING    NOT NULL COMMENT 'VALIDATE | PARSE | LOAD',
    status              STRING    NOT NULL COMMENT 'SUCCESS | FAILED',
    start_time          TIMESTAMP NOT NULL COMMENT 'When the attempt started.',
    end_time            TIMESTAMP          COMMENT 'When it finished.',
    duration_seconds    DOUBLE             COMMENT 'How long parsing took. Useful when files grow.',
    rows_planned        INT                COMMENT 'Metadata rows the parser planned to write.',
    rows_written        INT                COMMENT 'Metadata rows actually written.',
    error_count         INT                COMMENT 'Validation errors found.',
    warning_count       INT                COMMENT 'Advisory warnings raised.',
    error_message       STRING             COMMENT 'Detail when status = FAILED.',
    executed_by         STRING             COMMENT 'User or service principal that ran it.',
    created_at          TIMESTAMP          COMMENT 'Row insert time.',
    CONSTRAINT pk_config_parse_audit PRIMARY KEY (parse_id) RELY
)
USING DELTA
COMMENT 'iDEE metadata: config parse audit. What config was read, when, and did it work.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'metadata',
    'idee.owner'                 = 'framework'
);
