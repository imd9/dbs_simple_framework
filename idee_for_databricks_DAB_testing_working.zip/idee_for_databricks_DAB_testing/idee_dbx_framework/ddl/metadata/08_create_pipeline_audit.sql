-- =============================================================================
-- 08_create_pipeline_audit.sql
-- =============================================================================
-- AUDIT TABLE 2 OF 2 — the data side.
--
-- One row per pipeline run. Answers: what data moved, when, how much, and did
-- it work? Written by the execution engine at run time, never by a config file
-- and never by hand.
--
-- Different grain from config_parse_audit: that one records reading a YAML,
-- this one records moving data.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.pipeline_audit (
    run_id            STRING    NOT NULL COMMENT 'Unique per execution. Ties back to the Databricks run.',
    pipeline_id       STRING    NOT NULL COMMENT 'FK to pipeline_config.',
    pipeline_name     STRING             COMMENT 'Denormalised for readability.',
    dataset_id        STRING    NOT NULL COMMENT 'FK to dataset_config.',
    source_ref        STRING             COMMENT 'Resolved source path or table actually read.',
    target_ref        STRING             COMMENT 'Resolved target path or table actually written.',
    load_type         STRING             COMMENT 'FULL | INCREMENTAL | CDC | SNAPSHOT',
    column_mode       STRING             COMMENT 'star | explicit | notebook',
    start_time        TIMESTAMP NOT NULL COMMENT 'When the run started.',
    end_time          TIMESTAMP          COMMENT 'When it finished. NULL while running.',
    duration_seconds  DOUBLE             COMMENT 'Elapsed time.',
    rows_read         BIGINT             COMMENT 'Rows read from the source.',
    rows_written      BIGINT             COMMENT 'Rows written to the target.',
    rows_dropped      BIGINT             COMMENT 'Rows removed by a drop-action rule.',
    rows_quarantined  BIGINT             COMMENT 'Rows routed to quarantine.',
    rows_warned       BIGINT             COMMENT 'Rows that tripped a warn-action rule but passed through.',
    status            STRING    NOT NULL COMMENT 'STARTED | SUCCESS | FAILED | SKIPPED',
    error_message     STRING             COMMENT 'Detail when status = FAILED.',
    source_watermark  STRING             COMMENT 'Watermark used, for incremental runs.',
    executed_by       STRING             COMMENT 'User or service principal that ran it.',
    created_at        TIMESTAMP          COMMENT 'Row insert time.',
    CONSTRAINT pk_pipeline_audit PRIMARY KEY (run_id, dataset_id) RELY
)
USING DELTA
COMMENT 'iDEE metadata: pipeline run audit. What data moved, when, and did it work.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'metadata',
    'idee.owner'                 = 'framework'
);
