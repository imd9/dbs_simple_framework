-- =============================================================================
-- 99_verify_metadata_tables.sql
-- =============================================================================
-- Post-install check. Confirms all eight metadata tables exist and reports how
-- many rows each holds. Safe to run any time.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
-- =============================================================================

SELECT 'pipeline_config'      AS table_name, COUNT(*) AS row_count FROM ${catalog}.${metadata_schema}.pipeline_config
UNION ALL
SELECT 'source_config'        AS table_name, COUNT(*) AS row_count FROM ${catalog}.${metadata_schema}.source_config
UNION ALL
SELECT 'target_config'        AS table_name, COUNT(*) AS row_count FROM ${catalog}.${metadata_schema}.target_config
UNION ALL
SELECT 'dataset_config'       AS table_name, COUNT(*) AS row_count FROM ${catalog}.${metadata_schema}.dataset_config
UNION ALL
SELECT 'column_config'        AS table_name, COUNT(*) AS row_count FROM ${catalog}.${metadata_schema}.column_config
UNION ALL
SELECT 'quality_rule_config'  AS table_name, COUNT(*) AS row_count FROM ${catalog}.${metadata_schema}.quality_rule_config
UNION ALL
SELECT 'config_parse_audit'   AS table_name, COUNT(*) AS row_count FROM ${catalog}.${metadata_schema}.config_parse_audit
UNION ALL
SELECT 'pipeline_audit'       AS table_name, COUNT(*) AS row_count FROM ${catalog}.${metadata_schema}.pipeline_audit
ORDER BY table_name;
