-- =============================================================================
-- 01_create_quarantine_records.sql
-- =============================================================================
-- ONE shared quarantine table for every dataset.
--
-- OWNER      : Framework (the shape). Lives in the APPLICATION schema, because
--              it holds business data, not metadata.
-- RUNS       : Once per environment, alongside the metadata DDL.
-- PARAMETERS : ${catalog}, ${app_schema}
--
-- WHY ONE TABLE AND NOT ONE PER DATASET
--   A per-dataset quarantine table keeps typed columns, but it means every new
--   onboarding needs a hand-written DDL file — friction working directly
--   against "onboard a dataset by filling out one YAML file". One shared table
--   scales to any dataset with no new DDL.
--
-- WHY THE ROW IS STORED AS JSON
--   It is the only way one table can hold rows from datasets with different
--   shapes. Quarantined rows exist to be investigated, not analysed, so losing
--   column typing costs little. Query them with:
--
--     SELECT get_json_object(record_json, '$.CUSTOMER_ID') AS customer_id, ...
--     FROM  ${catalog}.${app_schema}.quarantine_records
--     WHERE pipeline_name = 'scion_customer_landing_to_bronze'
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${app_schema}.quarantine_records (
    run_id          STRING    NOT NULL COMMENT 'The run that rejected this row. FK to pipeline_audit.',
    pipeline_id     STRING    NOT NULL COMMENT 'FK to pipeline_config.',
    pipeline_name   STRING             COMMENT 'Denormalised so the table is readable on its own.',
    dataset_id      STRING    NOT NULL COMMENT 'FK to dataset_config.',
    failed_rules    STRING             COMMENT 'Comma-separated names of every rule this row failed.',
    record_json     STRING    NOT NULL COMMENT 'The rejected row, as JSON. Shape varies by dataset.',
    quarantined_at  TIMESTAMP NOT NULL COMMENT 'When the row was quarantined.'
)
USING DELTA
COMMENT 'Shared quarantine. Rows rejected by a data quality rule with action = quarantine.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'quarantine',
    'idee.owner'                 = 'framework'
);
