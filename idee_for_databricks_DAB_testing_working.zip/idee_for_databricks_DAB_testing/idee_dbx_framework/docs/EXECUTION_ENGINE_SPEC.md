> **Status note (v3).** This spec was written before the runtime contracts
> existed. It remains the best description of WHAT the engine must do; the
> HOW — the interface every component implements — is now fixed in
> `src/idee_dbx/runtime/contracts.py`. Read the contracts first, then this.
>
> Four things in this spec have since been decided or corrected:
>
> 1. **Column modes are three, not two.** `allow_select_star` true/false has
>    been replaced by `column_mode: star | explicit | notebook`. The notebook
>    mode — reference an external notebook for complex SQL — was missing here.
> 2. **ETL audit columns must be EXCLUDED on read** in star mode, not merely
>    added on write. Without that, a table-to-table hop copies the upstream
>    load timestamp forward and the audit trail silently lies.
> 3. **There are two audit tables.** `config_parse_audit` (which YAML parsed,
>    when, did it work) and `pipeline_audit` (what data moved). Different
>    grains, different failure modes, different readers.
> 4. **`delta_table` is a source type, not just a target type.** Reading FROM
>    a table is how bronze->silver and silver->gold work. Without it the engine
>    can only ever do the first hop.
>
> The open design decisions at the bottom have answers now; see
> `docs/DESIGN_DECISIONS.md`.

---

# iDEE Execution Engine Implementation Template

This file describes what still needs to be implemented for the V2 pipeline to be complete.

## Purpose

The current notebook and YAML flow do these parts correctly:
* Read a V2 YAML config
* Validate required sections
* Generate deterministic IDs
* Load metadata rows into the V2 metadata tables with MERGE

What is not built yet is the execution engine that reads the metadata back and actually moves data from source to target.

## Goal state

Given a V2 YAML file like [Vetted V2.yaml](#file-2368970559383709), the framework should be able to:
* Load the metadata for that pipeline from the metadata tables
* Read the source data
* Apply either `SELECT *` behavior or explicit column mapping
* Add an ingestion timestamp column
* Apply data quality rules
* Write to the configured target
* Record audit results

## Core runtime flow

### 1. Resolve pipeline run context
The engine should begin from one of these inputs:
* `config_file_path`
* `pipeline_name`
* `pipeline_id`

Recommended runtime sequence:
1. Resolve the pipeline from `pipeline_config`
2. Load related rows from:
   * `source_config`
   * `target_config`
   * `dataset_config`
   * `column_config` if `allow_select_star = false`
   * `quality_rule_config`
3. Create a `run_id`
4. Insert a STARTED row into `pipeline_audit`

## Metadata tables the engine should read

### `pipeline_config`
Needed for:
* pipeline identity
* YAML file lineage
* descriptive logging

### `source_config`
Needed for:
* source type
* connection reference
* root path
* file format
* landing requirement

### `target_config`
Needed for:
* target type
* target table or target path

### `dataset_config`
Needed for:
* object name
* ingestion method
* load type
* primary key
* incremental column
* source path pattern
* `allow_select_star`
* `trim_all`

### `column_config`
Only needed when `allow_select_star = false`.
Used for:
* source-to-target renaming
* explicit target typing

### `quality_rule_config`
Needed for:
* runtime DQ evaluation
* rule routing by action: `warn`, `drop`, `quarantine`, `fail`

### `pipeline_audit`
Needed for:
* run tracking
* row counts
* failure reporting
* execution timing

## Source reading requirements

The engine should support a source reader abstraction.
For V2, the source section currently allows:
* `cloud_files`
* `jdbc`
* `lakeflow_connect`
* `kafka`
* `api`

Initial implementation recommendation:
* Build `cloud_files` first
* Add other source types behind separate reader modules later

### Cloud files reader
Should combine:
* `root_path` from `source_config`
* `source_path` from `dataset_config`

Example resolved input path pattern:
* `root_path = /Volumes/idee_app/landing/customer`
* `source_path = incoming/*.csv`
* resolved path = `/Volumes/idee_app/landing/customer/incoming/*.csv`

Should also use `file_format` from `source_config`.

## Transformation behavior

### Path A: `allow_select_star = true`
This is the simplified runtime path.
The engine should:
1. Read the source dataset
2. Pass through all source columns unchanged
3. Add an ingestion timestamp column such as `_ingested_at`
4. Optionally trim all string columns when `trim_all = true`
5. Continue to DQ evaluation and target write

This is the runtime meaning of "select star" in the YAML.
The YAML flag does not itself execute SQL. It tells the engine to avoid explicit column mapping.

### Path B: `allow_select_star = false`
The engine should:
1. Read `column_config`
2. Select only configured source columns
3. Rename columns to `target_column`
4. Cast columns to `target_type`
5. Add `_ingested_at`
6. Continue to DQ evaluation and target write

## Ingestion timestamp requirement

Each execution should stamp the rows with a runtime ingestion column.
Recommended default:
* `_ingested_at TIMESTAMP`

This is different from metadata timestamps like `created_at` and `updated_at`.
Those track metadata row lifecycle.
`_ingested_at` tracks when data itself was processed.

## Data quality execution requirements

The engine should load rules from `quality_rule_config` and evaluate them against the transformed dataframe.

### Required rule actions

#### `warn`
* Keep the row
* Log warning counts
* Optionally persist warning details later

#### `drop`
* Remove failing rows from the output dataframe
* Count dropped rows in audit

#### `quarantine`
* Send failing rows to a quarantine target/table
* Keep passing rows moving forward
* Count quarantined rows in audit

#### `fail`
* Stop the pipeline when any failing row exists
* Write FAILED status to audit with error details

### Rule execution model
Recommended order:
1. Evaluate each rule as a boolean expression
2. Attach pass/fail indicators temporarily
3. Route rows based on rule action
4. Produce passing dataframe plus rejected/quarantined counts
5. Drop temporary rule columns before write

## Target writing requirements

The engine should support a target writer abstraction.
For V2, `target_config` currently allows these target types:
* `delta_table`
* `s3`
* `adls`
* `jdbc`

Initial implementation recommendation:
* Build `delta_table` first
* Add file-based and JDBC writers later

### Delta table writer
For `target_type = delta_table`, the engine should write to `target_table`.

Write behavior should depend on `load_type`:
* `FULL`: truncate/overwrite target then load fresh data
* `INCREMENTAL`: append or merge based on `incremental_column`
* `CDC`: merge by key with change semantics
* `SNAPSHOT`: keep point-in-time snapshot pattern

Initial implementation recommendation:
* Implement `FULL` first
* Stub the others with clear TODOs and validation errors

## Idempotency requirements

The metadata load is already idempotent because it uses MERGE.
The execution engine also needs clear idempotent behavior.

Examples:
* `FULL` loads should deterministically replace the target contents
* rerunning the same metadata load should not duplicate metadata rows
* audit rows should be unique per `run_id`

## Audit requirements

The engine should write to `pipeline_audit` at minimum:
* `run_id`
* `pipeline_id`
* `dataset_id`
* `layer`
* `start_time`
* `end_time`
* `rows_read`
* `rows_written`
* `rows_rejected`
* `status`
* `error_message`

Recommended statuses:
* `STARTED`
* `SUCCESS`
* `FAILED`
* `SKIPPED`

Recommended audit sequence:
1. Insert STARTED row before reading data
2. Update same run row after success/failure
3. Include row counts and error details

## Quarantine handling

The framework currently models quarantine as a DQ action, but the target side needs an actual implementation.
The engine should define:
* where quarantined data is written
* what metadata columns get added to quarantined rows
* how rule failure reasons are stored

Recommended quarantine metadata columns:
* `_quarantine_rule_name`
* `_quarantine_rule_action`
* `_quarantine_reason`
* `_quarantined_at`
* `_run_id`
* `_pipeline_id`

## Validation still needed before runtime execution

The current validation is structural.
The execution engine should add runtime validation for:
* source path exists or is reachable
* `target_table` is valid for `delta_table`
* primary key exists when required by load type
* incremental column exists when `load_type = INCREMENTAL`
* `column_config` source columns exist when `allow_select_star = false`
* DQ expressions reference valid columns

## Suggested module breakdown

A clean implementation could be split into these runtime components:
* `runtime/config_resolver.py`
* `runtime/source_readers.py`
* `runtime/transformer.py`
* `runtime/dq_engine.py`
* `runtime/target_writers.py`
* `runtime/audit_logger.py`
* `runtime/executor.py`

## Suggested executor contract

The main runtime entry point should do something conceptually like this:
1. Resolve pipeline metadata
2. Read source dataframe
3. Apply transformation path:
   * select-star path, or
   * explicit column mapping path
4. Apply DQ rules
5. Write target output
6. Write audit results
7. Return a structured execution summary

## Minimum viable implementation order

### Phase 1
* Resolve pipeline metadata from tables
* Support `cloud_files`
* Support `delta_table`
* Support `FULL`
* Support `allow_select_star = true`
* Add `_ingested_at`
* Write audit rows

### Phase 2
* Support explicit `column_config`
* Add rename/cast logic
* Support `trim_all`
* Support quarantine write path

### Phase 3
* Support `INCREMENTAL`
* Support `CDC`
* Support `SNAPSHOT`
* Support additional source and target types

## Open design decisions to settle

These should be agreed before coding the full engine:
* Where exactly quarantined rows should land
* Whether `_ingested_at` is always required or configurable
* Whether `FULL` means overwrite table or delete/insert
* Whether `pipeline_name` must be unique or only `pipeline_id`
* Whether deterministic IDs should stay hash-based or move to another convention
* Whether one YAML can ever expand to multiple datasets in a future version

## Definition of done for the execution engine

The pipeline is complete when a user can:
1. point the notebook at a V2 YAML file
2. load metadata successfully
3. run the execution engine
4. see source data arrive in the configured target
5. see `_ingested_at` on the output rows
6. see DQ actions enforced
7. see audit rows written
8. rerun safely without metadata duplication

## Immediate next implementation target

If the goal is to complete the current demo quickly, the next best build is:
* read metadata from V2 tables
* support `cloud_files` source reading
* support `allow_select_star = true`
* add `_ingested_at`
* write to the configured Delta target table
* write one audit row per run
