# Merge Notes — Yash's Engine into the Framework Package

Written so Yash can review what happened to his work, and so the reasoning
survives after we have both forgotten it.

---

## What Yash built

Five files, all in the application folder. No framework changes.

| | |
|---|---|
| Added | `Customers (Custom Notebook).yaml`, `transform_customer_combined.py` |
| Changed | two configs, `run_sample_pipeline.py` (910 lines) |

**His engine ran on a real cluster.** That was the single most valuable thing in
either branch, and it drove every decision below.

---

## What was kept, and what changed

### Kept as-is

**The staging-table contract for notebook mode.** A custom notebook writes its
output to a table; the framework picks it up. This is the load-bearing
discovery: `dbutils.notebook.run` executes in a **separate Spark session** on
serverless, so a temp view created inside the notebook is invisible to the
caller. A real table is the only thing that crosses the session boundary.

That is not obvious, it cost debugging time to find, and there is now a comment
in `transformer.py` and in the transform notebook telling future readers not to
"simplify" it back to a temp view.

**The DQ alias approach.** Resolving `{alias}` to whichever candidate column
actually exists, so a rule survives a column rename. Behaviour matches what ran
on the cluster.

**The union pattern in the transform notebook.** Two files with different column
names, standardised and unioned — a genuinely good demonstration of why notebook
mode has to exist.

### Moved

**The engine moved from the app notebook into `src/idee_dbx/runtime/`.**

Why: Ojoma's instruction, and the reason a second team could ever adopt this. If
the engine lives in the app folder, the next team copies it and gets a private
fork. Two forks drift within a month; your bug fix never reaches them.

Practically: the app notebook went from 910 lines to about 260, and the engine
gained 196 tests. You cannot unit-test a notebook cell.

### Changed

| Was | Now | Why |
|---|---|---|
| `allow_select_star` / `allow_select_columns` / `allow_custom_notebook` | `column_mode: star \| explicit \| notebook` | Three booleans encode eight states; five are contradictions. His own code had to resolve them with an if-chain that silently picked a winner. An enum makes the broken states unrepresentable. |
| Quarantine `mode("overwrite")` | `mode("append")` on a shared table | Overwrite wiped the previous run's quarantined rows. Losing the history of what was rejected defeats the point of quarantining. |
| Quarantine name from `bronze_` → `quarantine_` string replace | one shared `quarantine_records` table | The string replace silently misfires on any target not named `bronze_*`. Shared needs no per-dataset DDL, which matters for "onboard by filling out one file". |
| `inferSchema: true` on the bronze read | `inferSchema: false` | The same file can land with different types on different days depending on which rows Spark sampled. Bronze should preserve the source as text; casting is config-driven, later. |
| `rows_written = COUNT(*) FROM target` | count of rows actually written | Identical under FULL, wrong under append — it would report the whole table. |
| Audit `INSERT ... VALUES` positional | `MERGE` on named columns | Positional values break silently if a column is added. MERGE also lets the STARTED row and the final row be the same row. |
| Staging table hardcoded in two places | passed to the notebook as a parameter | The constant appeared in both the notebook and the engine. Now it is derived from `dataset_id` and passed in, so two notebook pipelines cannot collide. |

---

## What was added on top

**Ambiguity is refused, never guessed.** The question was raised: if `explicit`
is chosen but there are no columns, should the framework fall back to the
notebook, and vice versa?

We deliberately did not build that. `explicit` and `notebook` do not produce
similar data — they produce **completely different datasets**. The explicit
config maps five renamed customer columns; the notebook unions two files into
three. Falling back would write the wrong shape while the audit log claimed the
other mode ran. On a 2am scheduled run that is days of bad data and a metadata
trail that lies.

Instead:

**At validation time**
- `explicit` with no `columns:` → error
- `notebook` with no `notebook_path` → error
- `notebook` **and** a `columns:` block → error, rather than silently ignoring one
- the notebook path is checked for existence; missing is an error, unverifiable
  (validating off-cluster) is a warning

**At run time**
- staging table missing → error naming the table and the notebook
- staging table empty → error with the row count
- no `dbutils` → error explaining it only exists inside Databricks

**And a declared escape hatch**, so the fallback exists without being a guess:

```yaml
  column_mode: notebook
  on_empty_notebook: fail          # default
  # on_empty_notebook: use_columns # explicit opt-in; requires a columns: block
```

With `use_columns` the config still describes what happened, the audit stays
true, and someone chose the behaviour on purpose.

---

## Bugs fixed in both branches

Both had broken file references that would fail on first run.

**Mine:** the app notebook's config dropdown offered
`customers_select_star_config.yaml` and `customers_explicit_columns_config.yaml`
— files I had renamed and never updated the dropdown for.

**His:** the E2E notebook, `run_config_pipeline.py` and `conftest.py` all
referenced `customer_full_refresh_config.yaml`, which his config folder did not
contain. His tests would have failed.

Every file reference in the merged package has now been audited; the broken list
is empty.

---

## The config set

Three configs, one per column mode, forming a chain:

| File | Hop | Source | Mode |
|---|---|---|---|
| `customers_landing_to_bronze_config.yaml` | files → bronze | `cloud_files` | `star` |
| `customers_bronze_to_silver_config.yaml` | bronze → silver | `delta_table` | `explicit` |
| `customers_combined_landing_to_bronze_config.yaml` | 2 files → bronze | `cloud_files` | `notebook` |

Yash's "DDL Auto Creation" config was superseded by `bronze_to_silver`: both are
explicit mode, but the latter reads from a *table*, which is what proves the
engine is layer-agnostic. His deprecated configs were dropped.

---

## What still needs doing

**Run this on a cluster before the demo.** The 196 tests cover decision logic —
path resolution, column planning, alias resolution, action precedence, write
modes, audit rows. The Spark calls themselves are exercised only by fakes,
because pyspark is not available where the tests run.

Yash's version had the opposite property: proven on a cluster, no tests. The
merge has the structure and the tests; it needs the cluster run to get back the
confidence his version already had. That is the one outstanding risk, and it is
not optional.

**Jobs and scheduling are still not built.** `schedule` is recorded in metadata
and nothing acts on it. The notebooks run the ETL end to end; nothing creates a
Databricks Job.
