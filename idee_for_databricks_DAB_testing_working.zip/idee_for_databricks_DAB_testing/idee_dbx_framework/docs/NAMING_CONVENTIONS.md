# Naming Conventions

The rule we are working to: **anything named now must survive the move to
Bitbucket unchanged.** Renaming after CI/CD is wired up means broken paths, so
the conventions apply from the first file.

---

## File extensions

| Type | Extension | Why |
|---|---|---|
| YAML we author | `.yaml` | The YAML specification's own recommendation. Pick one and never mix. |
| YAML a tool mandates | whatever the tool requires | `databricks.yml` must be exactly that — the tool will not find `.yaml`. |
| Python | `.py` | — |
| SQL | `.sql` | — |
| Markdown | `.md` | — |

**Do not mix `.yaml` and `.yml` for files we control.** A folder containing both
is the single most common source of "the loader can't find my config" tickets.

---

## Folders

Lowercase `snake_case`, no spaces, no capitals.

```
config/    ddl/    docs/    schema/    src/    templates/    tests/
```

The reason is not aesthetics. Git is case-sensitive; Windows and macOS
filesystems are not. A folder that differs only by case between the repo and a
developer's laptop produces phantom diffs and merge conflicts that are painful
to unpick. Staying lowercase sidesteps the whole class of problem.

All folders in this project follow the rule, top level included:

```
idee_for_databricks/
├── idee_dbx_framework/
└── idee_dbx_app/
```

`dbx` is the conventional shorthand for Databricks and keeps the two sibling
folders visually parallel. Avoid `dbs` — it reads as "database".

---

## Python

| Thing | Convention | Example |
|---|---|---|
| Module | `snake_case.py`, named after what it does | `config_validator.py` |
| Package | short, lowercase, no underscores if avoidable | `idee_dbx` |
| Class | `PascalCase` | `ValidationResult` |
| Function | `snake_case`, verb-first | `validate_config_file()` |
| Constant | `UPPER_SNAKE_CASE` | `DEFAULT_SCHEMA_DIR` |
| Private helper | leading underscore | `_dotted_get()` |
| Test file | `test_<module>.py` | `test_config_validator.py` |
| Test function | `test_<condition>_<expected>` | `test_missing_config_version_fails` |

Module names say what the module *does*: `config_validator.py`, not
`validator2.py`, `utils.py`, or `helpers.py`. A file called `utils.py` becomes a
junk drawer within a month.

---

## SQL / DDL

Pattern: `NN_verb_object.sql`

```
00_verify_prerequisites.sql
01_create_source_config.sql
99_verify_metadata_tables.sql
```

- `NN` is a two-digit execution order — scripts run in filename sort order.
- `00` is preflight checks, `01`–`89` are objects, `90`+ are verification.
- Verb first: `create_`, `alter_`, `drop_`, `verify_`, `seed_`.

---

## Config files

| Kind | Location | Naming |
|---|---|---|
| Template (blank) | `idee_dbx_framework/templates/` | `idee_pipeline_config_template.yaml` |
| Filled config | `idee_dbx_app/config/` | `<application>_<object>_<source_layer>_to_<target_layer>_config.yaml` |
| Schema | `idee_dbx_framework/schema/` | `pipeline_config_schema_v<major>_<minor>.yaml` |

Filled example: `customers_landing_to_bronze_config.yaml`.

The file is named after the pipeline it contains, because pipeline identity is
(pipeline_name + config file name).

A filled config is **not** a template and must not carry `template` in its
name. That distinction is what keeps framework and application separate.

---

## Metadata identifiers

| Field | Pattern | Example |
|---|---|---|
| `source_id` | `src_<system>` | `src_customer_files` |
| `object_id` | `obj_<dataset>` | `obj_customer` |
| `rule_id` | `<object_id>__<slug>` | `obj_customer__email_format_check` |

IDs are **stable and never reused.** Audit history keys off them; recycling an
ID silently reassigns years of run history to the wrong dataset.

---

## Table names

| Layer | Pattern | Example |
|---|---|---|
| Metadata | `<name>_config`, `pipeline_audit` | `source_config` |
| Bronze | `bronze_<object>` | `bronze_customer` |
| Silver | `silver_<object>` | `silver_customer` |
| Quarantine | one shared table | `quarantine_records` |

Always reference tables three-part: `catalog.schema.table`. The validator
enforces this on `bronze_table`.

---

## Schemas vs folders

These are two different namespaces and must not be conflated:

| | Purpose | Names |
|---|---|---|
| **Unity Catalog schemas** | where *tables* live | `idee_metaschema`, `idee_app` |
| **Workspace folders** | where *files* live | `idee_dbx_framework`, `idee_dbx_app` |

`idee_metaschema` holds metadata tables only — never business data.
`idee_app` holds Bronze/Silver/Gold business tables — never metadata.

---

## Names to avoid

Banned outright in this project:

- Vague qualifiers: `lightweight`, `simple`, `new`, `final`, `v2`, `root`,
  `rootmaster`
- Throwaway names: `junk.py`, `test1.py`, `temp.sql`, `dry_run_test.py`,
  `scratch/`
- Generic dumping grounds: `utils.py`, `helpers.py`, `misc/`, `stuff/`
- Mixed styles in one tree: `MyFolder/` beside `my_folder/`

The test: if a name would need explaining to a new engineer six months from
now, rename it.

---

## Parameterisation

Catalog and schema names are **never hardcoded** — not in Python, not in SQL,
not in notebooks.

```sql
-- Correct
CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.source_config ( ... )

-- Wrong
CREATE TABLE IF NOT EXISTS medtech_md_scion_dev.idee_metaschema.source_config ( ... )
```

```python
# Correct
load_plan(plan, catalog=catalog, metadata_schema=metadata_schema)

# Wrong
load_plan(plan, catalog="medtech_md_scion_dev", metadata_schema="idee_metaschema")
```

The same artifact has to run against dev, QA, and prod without edits. Hardcoded
names make promotion a copy-and-modify exercise, which is where environment
drift starts.
