# Testing Guide — Framework Engineer

**Your role:** you built the framework. Your job is to prove it works *before*
any application team depends on it.

**What you test:** the framework code — validator, parser, loader — plus the
metadata DDL. You do **not** test anyone's business pipeline.

**How you test:** automated unit tests (PyTest), then a controlled end-to-end
run against the sample config.

> If you are the downstream user filling out a config, you want
> `idee_dbx_app/docs/DEMO_GUIDE.md` instead.

---

## Before you start

### One test suite, not two

A common misconception worth killing early: there is **one** PyTest suite, in
`idee_dbx_framework/tests/`. You run it **once, from the framework root**. There
is no separate suite for the app folder.

| Folder | How it is tested | Why |
|---|---|---|
| `idee_dbx_framework/` | PyTest unit tests | Reusable code every team depends on. Regressions here break everyone. |
| `idee_dbx_app/` | Running the actual validate → parse → load flow | It is sample data and one team's config. Nothing reusable to unit test. |

Unit tests protect the framework. The app folder is proven by *using* it.

### Set your paths once

Every notebook in this guide starts with the same block. Set it once, correctly,
and nothing else needs editing. Replace the email with yours.

```python
PROJECT_ROOT     = "/Workspace/Users/<your.email>@its.jnj.com/idee_for_databricks"
FRAMEWORK        = f"{PROJECT_ROOT}/idee_dbx_framework"
APP              = f"{PROJECT_ROOT}/idee_dbx_app"

CATALOG          = "medtech_md_scion_dev"   # your catalog
METADATA_SCHEMA  = "idee_metaschema"        # metadata tables only
APP_SCHEMA       = "idee_app"               # business tables
```

Using absolute paths built from one variable avoids the most common Databricks
failure: relying on the notebook's working directory, which differs between
Repos, workspace files, and job runs.

---

## Phase 1 — Confirm the layout landed correctly

Create a notebook called `01_framework_unit_tests` in
`idee_dbx_framework/notebooks/`. First cell:

```python
import os

for label, path in [("Framework", FRAMEWORK), ("App", APP)]:
    print(f"{label}: {'FOUND' if os.path.isdir(path) else 'MISSING'}  {path}")

print("\nFramework contents:")
for entry in sorted(os.listdir(FRAMEWORK)):
    print("  ", entry)
```

**Expect:** both FOUND, and the framework listing showing `src`, `tests`,
`schema`, `templates`, `ddl`, `docs`, `notebooks`, plus `README.md`,
`CHANGELOG.md`, `VERSION`, `requirements.txt`, `pytest.ini`.

**If a folder is MISSING**, the path is wrong — check the exact spelling and
capitalisation of your workspace user folder. Fix it here before going further;
every later step depends on it.

---

## Phase 2 — Install dependencies

```python
%pip install pytest pyyaml
```

```python
dbutils.library.restartPython()
```

`restartPython()` is required — without it the notebook keeps using the old
interpreter and your fresh install is invisible. Note that restarting clears
your variables, so **re-run the paths cell afterwards.**

Most Databricks runtimes already ship PyYAML; installing it anyway is harmless
and makes the notebook portable.

---

## Phase 3 — Run the unit tests

This is the core of your role. Two ways; try A first.

### Option A — PyTest from a Python cell (recommended)

```python
import os
import sys
import pytest

# Workspace storage may reject cache writes, so disable bytecode and caching.
sys.dont_write_bytecode = True

os.chdir(FRAMEWORK)
if f"{FRAMEWORK}/src" not in sys.path:
    sys.path.insert(0, f"{FRAMEWORK}/src")

exit_code = pytest.main([
    "tests/",
    "-v",
    "-p", "no:cacheprovider",   # do not write .pytest_cache to the workspace
    "--tb=short",
])

print(f"\nPyTest exit code: {exit_code}   (0 = all passed)")
```

**Why `-p no:cacheprovider`:** PyTest tries to write a `.pytest_cache` folder
next to your tests. Workspace file storage often refuses that write, and the
run dies with a permission error that looks like a test failure but is not.
Disabling the cache plugin sidesteps it entirely.

### Option B — shell fallback

If Option A misbehaves, run PyTest as a subprocess:

```python
%sh
cd /Workspace/Users/<your.email>@its.jnj.com/idee_for_databricks/idee_dbx_framework
PYTHONDONTWRITEBYTECODE=1 python -m pytest tests/ -v -p no:cacheprovider
```

`%sh` runs on the driver node. It works on classic clusters; on serverless
compute it may be restricted, in which case use Option A.

### Option C — copy to local disk (most robust)

If the workspace filesystem fights you on either of the above, copy to the
driver's local disk first. Local disk has no write restrictions:

```python
import shutil, subprocess, sys

LOCAL = "/tmp/idee_dbx_framework"
shutil.rmtree(LOCAL, ignore_errors=True)
shutil.copytree(FRAMEWORK, LOCAL)

result = subprocess.run(
    [sys.executable, "-m", "pytest", "tests/", "-v", "-p", "no:cacheprovider"],
    cwd=LOCAL, capture_output=True, text=True,
)
print(result.stdout[-6000:])
print(result.stderr[-2000:])
```

Remember this runs a *copy*. Re-copy after editing the framework, or you will
be testing stale code — an easy hour to lose.

---

## Phase 4 — Read the results

A healthy run ends with something like:

```
tests/test_config_parser.py::TestActionCounts::test_produces_one_source_row PASSED
...
======================== 80+ passed in 1.2s ========================
```

**Exit code 0 means every test passed.** That is your first green light.

### What the suite actually covers

Worth knowing, because "the tests pass" means little if you cannot say what
they checked:

| Test class | Proves |
|---|---|
| `TestValidConfigs` | A correct config passes, and the shipped demo config passes |
| `TestVersioning` | `config_version` is required; unknown versions are rejected |
| `TestRequiredFields` | Every required field is enforced; blanks count as missing |
| `TestTypeChecking` | Types are enforced — including that `bool` is not accepted as `int` |
| `TestEnumChecking` | Illegal enum values are rejected |
| `TestConditionalRules` | `INCREMENTAL` demands a watermark; `CDC`/`SNAPSHOT` demand a key; each DQ engine demands its own field |
| `TestIntegrityChecks` | Cross-field consistency: matching `source_id`, unique columns, three-part table names |
| `TestWarnings` | Advisory warnings fire without failing validation |
| `TestFileHandling` | Missing, empty, and malformed files fail cleanly — and the blank template does **not** validate |
| `TestSqlRendering` | MERGE statements are correct, ordered parent-before-child, quote-escaped, and catalog-parameterised |
| `TestValidatorParserContract` | Anything the validator accepts, the parser can handle |

The `bool`-is-not-`int` test exists because in Python `True` is genuinely an
instance of `int`, so a naive type check accepts `sequence: true`. The blank
template test exists because every placeholder in the template is syntactically
legal — without that check, someone could deploy an unfilled template and the
framework would happily accept it.

### If tests fail

Read the assertion, not just the count. `--tb=short` gives you the failing line.
Failures are almost always one of:

1. **Path wrong** — `conftest.py` cannot find `src/` or the app config. Check
   `PROJECT_ROOT`.
2. **Stale copy** — you edited the framework but ran Option C against an old
   copy. Re-copy.
3. **A real regression** — you changed framework code and broke behaviour. This
   is the suite doing its job. Fix the code, not the test, unless the test
   encoded a wrong expectation.

---

## Phase 5 — Prove the validator actually rejects bad input

Tests passing is necessary but unconvincing in a demo. Show it failing on
purpose. New cell:

```python
import sys
if f"{FRAMEWORK}/src" not in sys.path:
    sys.path.insert(0, f"{FRAMEWORK}/src")

from idee_dbx.config_validator import validate_config
import yaml, copy

with open(f"{APP}/config/customers_landing_to_bronze_config.yaml") as f:
    good = yaml.safe_load(f)

SCHEMA_DIR = f"{FRAMEWORK}/schema"

def show(label, mutate):
    cfg = copy.deepcopy(good)
    mutate(cfg)
    r = validate_config(cfg, config_path=label, schema_dir=SCHEMA_DIR)
    print(f"\n--- {label} ---")
    print(r.report())

show("Illegal load_type",        lambda c: c["dataset"].__setitem__("load_type", "UPSERT"))
show("Illegal column_mode",      lambda c: c["dataset"].__setitem__("column_mode", "everything"))
show("INCREMENTAL, no watermark", lambda c: c["dataset"].update({"load_type": "INCREMENTAL", "incremental_column": ""}))
show("Two-part table name",      lambda c: c["target"].__setitem__("target_table", "idee_app.bronze_customer"))
show("primary_key as a string",  lambda c: c["dataset"].__setitem__("primary_key", "CUSTOMER_ID"))
show("Duplicate column name",    lambda c: c["columns"][1].__setitem__("target_column", c["columns"][0]["target_column"]))
```

**Expect:** every one reports `Result: FAILED` with a specific, readable error
naming the field. That is far more persuasive than a wall of green dots.

Also confirm the template itself is rejected:

```python
from idee_dbx.config_validator import validate_config_file

r = validate_config_file(f"{FRAMEWORK}/templates/idee_pipeline_config_template.yaml",
                         schema_dir=SCHEMA_DIR)
print(r.report())
```

**Expect:** FAILED, complaining about unfilled placeholder text. An unfilled
template must never pass.

---

## Phase 6 — Create the metadata tables

**The framework does not create schemas.** `idee_metaschema` and `idee_app` are
provisioned by the platform team. Run the preflight check first — it verifies
they exist and creates nothing:

```python
sql = open(f"{FRAMEWORK}/ddl/metadata/00_verify_prerequisites.sql").read()
for k, v in {"catalog": CATALOG, "metadata_schema": METADATA_SCHEMA, "app_schema": APP_SCHEMA}.items():
    sql = sql.replace("${" + k + "}", v)
display(spark.sql(sql))
```

**Expect:** two rows, `idee_app` and `idee_metaschema`, both `FOUND`. A missing
row means the schema does not exist under that catalog — stop and check the name
before going further.

Now create the tables. The DDL uses `${catalog}` and `${metadata_schema}`
placeholders; nothing is hardcoded:

```python
import glob, os

def run_ddl(folder, substitutions, skip=("00_", "99_")):   # 00 and 99 return results
    for path in sorted(glob.glob(f"{folder}/*.sql")):
        name = os.path.basename(path)
        if name.startswith(skip):
            continue
        sql = open(path).read()
        for key, value in substitutions.items():
            sql = sql.replace("${" + key + "}", value)
        print(f"Running {name} ...", end=" ")
        spark.sql(sql)
        print("OK")

run_ddl(
    f"{FRAMEWORK}/ddl/metadata",
    {"catalog": CATALOG, "metadata_schema": METADATA_SCHEMA},
)
```

Then verify:

```python
sql = open(f"{FRAMEWORK}/ddl/metadata/99_verify_metadata_tables.sql").read()
sql = sql.replace("${catalog}", CATALOG).replace("${metadata_schema}", METADATA_SCHEMA)
display(spark.sql(sql))
```

**Expect:** eight rows — `pipeline_config`, `source_config`, `target_config`,
`dataset_config`, `column_config`, `quality_rule_config`, `config_parse_audit`,
`pipeline_audit` — each with `row_count` 0.

### If something goes wrong

**A schema shows as missing in the preflight.** The framework will not create it
— that is the platform team's job, and silently creating a mistyped schema is
worse than failing on it. Check the exact name, then ask them.

**Constraint syntax rejected.** The tables declare informational
`PRIMARY KEY ... RELY` and `FOREIGN KEY ... NOT ENFORCED RELY` constraints,
which need Unity Catalog and a recent runtime. If your runtime rejects them,
strip the `CONSTRAINT` lines — they are documentation for the optimiser, not
enforcement, and the framework works identically without them. Note it in the
changelog if you do.

---

## Phase 7 — Dry run

Open `idee_dbx_framework/notebooks/run_config_pipeline.py`, set the widgets:

| Widget | Value |
|---|---|
| Catalog | your catalog |
| Metadata schema | `idee_metaschema` |
| Config file | `{APP}/config/customers_landing_to_bronze_config.yaml` |
| Dry run | **true** |

Run all.

**Expect:** validation PASSES, the parse plan shows the rows for that pipeline, the MERGE statements print, and the load
reports `DRY RUN (nothing written)`.

Read the generated SQL before going further. This is the last checkpoint before
anything is written.

---

## Phase 8 — Live load

Set **Dry run = false**, run again.

**Expect:** `Mode: LIVE`, `Result: SUCCESS`, and the verification cell showing
the same counts as the dry run rows.

Confirm independently:

```python
display(spark.sql(f"""
    SELECT p.pipeline_name, d.object_name, d.column_mode, t.target_table,
           COUNT(c.source_column) AS mapped_columns
    FROM {CATALOG}.{METADATA_SCHEMA}.dataset_config d
    JOIN {CATALOG}.{METADATA_SCHEMA}.pipeline_config p ON p.pipeline_id = d.pipeline_id
    JOIN {CATALOG}.{METADATA_SCHEMA}.target_config   t ON t.target_id   = d.target_id
    LEFT JOIN {CATALOG}.{METADATA_SCHEMA}.column_config c ON c.dataset_id = d.dataset_id
    GROUP BY 1,2,3,4
"""))
```

---

## Phase 9 — The idempotency check

**Do not skip this.** It is the single most convincing thing you can show, and
the most common place a metadata framework quietly breaks.

Run the live load a **second** time, unchanged. Then re-run the verification.

**Expect: identical row counts — the same counts as the dry run.** Not 2 / 2 / 10 / 6.

The framework emits `MERGE` rather than `INSERT`, and derives deterministic
`rule_id`s (`<object_id>__<slug>`) instead of random UUIDs. If it used either
`INSERT` or UUIDs, a second run would silently double your metadata. Showing
stable counts across two runs proves re-running a config is safe — which
matters enormously once configs go into CI/CD.

---

## Phase 10 — What to show in the demo

Keep it to one complete unit. Suggested order, roughly ten minutes:

1. **The structure** — framework versus app, and why the split exists.
2. **Unit tests** — run PyTest live, land on green, and say what it covers.
3. **The validator refusing bad input** — Phase 5. This lands better than green
   dots because it shows the framework protecting people.
4. **The blank template being rejected** — a small detail that signals care.
5. **Dry run** — validated, parsed, here is exactly what would be written.
6. **Live load** — metadata rows appear.
7. **Run it twice** — counts unchanged. Explain idempotency in one sentence.

### Be straight about scope

Say this explicitly rather than letting anyone assume otherwise:

> This loads **metadata**, not data. There is no ingestion engine yet — Bronze
> and Silver movement is the next increment. We proved the config path end to
> end first, on purpose.

Claiming more than you built is the fastest way to lose credibility in a review.
Naming the boundary yourself is what makes the rest believable.

### Deferred, and why

| Not built | Reason |
|---|---|
| Asset bundles, CI/CD | Waiting on Bitbucket repos and AD groups |
| Bronze/Silver ingestion | Next increment, after this skeleton is signed off |
| DQ runtime enforcement | Needs the ingestion engine first |
| Append, incremental, CDC | Full refresh proven first |

---

## Quick reference

```python
# Unit tests
os.chdir(FRAMEWORK); sys.path.insert(0, f"{FRAMEWORK}/src")
pytest.main(["tests/", "-v", "-p", "no:cacheprovider"])

# Validate a config
from idee_dbx.config_validator import validate_config_file
print(validate_config_file(path, schema_dir=f"{FRAMEWORK}/schema").report())

# Parse it
from idee_dbx.config_parser import parse_config_file
plan = parse_config_file(path); print(plan.summary())

# See the SQL
for s in plan.to_merge_statements(CATALOG, METADATA_SCHEMA): print(s)

# Load it
from idee_dbx.metadata_loader import load_plan
print(load_plan(plan, CATALOG, METADATA_SCHEMA, dry_run=True, spark=spark).report())
```

From a terminal, outside Databricks:

```bash
cd idee_dbx_framework
pip install -r requirements.txt
python -m pytest

PYTHONPATH=src python -m idee_dbx.main parse \
  --config ../idee_dbx_app/config/customers_landing_to_bronze_config.yaml \
  --show-sql --catalog medtech_md_scion_dev
```
