"""
Config parser.

Answers one question: **what metadata actions does this config produce?**

The parser assumes the config is already valid — run config_validator first.
It translates a valid config into rows destined for the six metadata tables and
renders those rows as idempotent MERGE statements. It does not touch Spark;
applying the actions is metadata_loader's job.

Keeping parse and load separate is what makes a dry run possible: you see
exactly what would be written before anything is written.

Design notes
------------
IDs are generated here, never taken from the config. Users name things; the
framework assigns identifiers. Every ID is a deterministic hash of stable
inputs, so re-parsing the same config MERGEs onto the same rows instead of
inserting duplicates. A random UUID would silently double the metadata on every
re-run.

Every row also carries `config_file_path`, so any metadata row can be traced
back to the YAML file that produced it.

Usage
-----
    from idee_dbx.config_parser import parse_config_file

    plan = parse_config_file("path/to/customers_landing_to_bronze_config.yaml")
    print(plan.summary())
    for statement in plan.to_merge_statements("my_catalog", "idee_metaschema"):
        print(statement)
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

import yaml

# --- metadata table names, parents before children ---------------------------
TABLE_PIPELINE_CONFIG = "pipeline_config"
TABLE_SOURCE_CONFIG = "source_config"
TABLE_TARGET_CONFIG = "target_config"
TABLE_CONNECTOR_CONFIG = "connector_config"
TABLE_DATASET_CONFIG = "dataset_config"
TABLE_COLUMN_CONFIG = "column_config"
TABLE_QUALITY_RULE_CONFIG = "quality_rule_config"

TABLE_ORDER = [
    TABLE_PIPELINE_CONFIG,
    TABLE_SOURCE_CONFIG,
    TABLE_TARGET_CONFIG,
    TABLE_CONNECTOR_CONFIG,
    TABLE_DATASET_CONFIG,
    TABLE_COLUMN_CONFIG,
    TABLE_QUALITY_RULE_CONFIG,
]

# Business keys used to MERGE (upsert) rather than blindly insert.
MERGE_KEYS = {
    TABLE_PIPELINE_CONFIG: ["task_id"],
    TABLE_SOURCE_CONFIG: ["source_id"],
    TABLE_TARGET_CONFIG: ["target_id"],
    TABLE_CONNECTOR_CONFIG: ["connector_id"],
    TABLE_DATASET_CONFIG: ["dataset_id"],
    TABLE_COLUMN_CONFIG: ["dataset_id", "source_column"],
    TABLE_QUALITY_RULE_CONFIG: ["rule_id"],
}

# ---------------------------------------------------------------------------
# ETL audit columns
# ---------------------------------------------------------------------------
# Framework-managed columns appended to every target. They are the only record
# of when a row was loaded and by which run, so they must be regenerated on each
# hop rather than copied forward.
#
# In `star` mode with exclude_etl_columns = true, these names are excluded from
# the source read. Without that, a table-to-table copy carries the upstream
# load timestamp into the new table and the audit trail becomes a lie.
ETL_AUDIT_COLUMNS = [
    "_ingested_at",      # when this row was written by this pipeline
    "_run_id",           # the run that produced it
    "_pipeline_id",      # which pipeline produced it
    "_source_file",      # originating file, for file-based sources
]

ID_LENGTH = 12


# =============================================================================
# Plan objects
# =============================================================================
@dataclass
class MetadataAction:
    """One row headed for one metadata table."""

    table: str
    operation: str          # always "MERGE" in v0.1
    keys: Dict[str, Any]    # the business key identifying the row
    values: Dict[str, Any]  # the full row payload

    def describe(self) -> str:
        key_text = ", ".join(f"{k}={v!r}" for k, v in self.keys.items())
        return f"{self.operation:<6} {self.table:<22} ({key_text})"


@dataclass
class ParsePlan:
    """Everything a single config file would do to the metadata tables."""

    config_path: str
    pipeline_id: str = ""      # parent pipeline (one per YAML)
    task_id: str = ""          # auto-generated per task
    task_name: str = ""        # short task name from YAML (e.g. 'bitbucket_to_bronze')
    pipeline_name: str = ""    # full qualified name (e.g. 'customer_etl_combined_bitbucket_to_bronze')
    dataset_id: str = ""
    config_version: str = ""
    column_mode: str = ""
    execution_order: int = 50  # lower runs first; default 50
    actions: List[MetadataAction] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    def add(self, action: MetadataAction) -> None:
        self.actions.append(action)

    def actions_for(self, table: str) -> List[MetadataAction]:
        return [a for a in self.actions if a.table == table]

    def counts(self) -> Dict[str, int]:
        return {table: len(self.actions_for(table)) for table in TABLE_ORDER}

    def summary(self) -> str:
        """Human-readable plan, suitable for printing in a notebook cell."""
        lines = [
            f"Config       : {self.config_path}",
            f"Version      : {self.config_version}",
            f"Pipeline     : {self.pipeline_name}",
            f"Pipeline ID  : {self.pipeline_id}",
            f"Dataset ID   : {self.dataset_id}",
            f"Column mode  : {self.column_mode}",
            "",
            f"Planned metadata actions ({len(self.actions)} total):",
        ]
        for table, count in self.counts().items():
            lines.append(f"  {table:<22} {count} row(s)")

        lines.append("")
        lines.append("Detail:")
        lines.extend(f"  {a.describe()}" for a in self.actions)

        if self.notes:
            lines.append("")
            lines.append("Notes:")
            lines.extend(f"  - {n}" for n in self.notes)
        return "\n".join(lines)

    def to_merge_statements(self, catalog: str, metadata_schema: str) -> List[str]:
        """Render every action as a Databricks SQL MERGE statement."""
        return [
            _render_merge(action, catalog, metadata_schema)
            for table in TABLE_ORDER
            for action in self.actions_for(table)
        ]


# =============================================================================
# Identifiers
# =============================================================================
def generate_id(*parts: str) -> str:
    """
    Deterministic identifier from stable inputs.

    SHA-256 rather than MD5: the value is not a security control, but static
    analysis tooling (SonarQube) flags MD5 wherever it appears, and arguing the
    exception on every scan costs more than using SHA-256 here.
    """
    raw = "|".join(str(p) for p in parts if p not in (None, ""))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:ID_LENGTH]


def _slug(text: str) -> str:
    """Lowercase, underscore-separated, safe for an identifier."""
    out = "".join(ch.lower() if ch.isalnum() else "_" for ch in str(text)).strip("_")
    while "__" in out:
        out = out.replace("__", "_")
    return out


# =============================================================================
# SQL rendering
# =============================================================================
def _sql_literal(value: Any) -> str:
    """Render a Python value as a Databricks SQL literal."""
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)):
        return str(value)
    escaped = str(value).replace("\\", "\\\\").replace("'", "\\'")
    return f"'{escaped}'"


def _render_merge(action: MetadataAction, catalog: str, metadata_schema: str) -> str:
    """Build a MERGE statement for one row. Upsert semantics, idempotent."""
    target = f"{catalog}.{metadata_schema}.{action.table}"
    columns = list(action.values.keys())

    source_row = ", ".join(f"{_sql_literal(action.values[c])} AS {c}" for c in columns)
    on_clause = " AND ".join(f"tgt.{k} = src.{k}" for k in action.keys)
    updatable = [c for c in columns if c not in action.keys and c != "created_at"]
    update_set = ",\n           ".join(f"tgt.{c} = src.{c}" for c in updatable)
    insert_cols = ", ".join(columns)
    insert_vals = ", ".join(f"src.{c}" for c in columns)

    return (
        f"MERGE INTO {target} AS tgt\n"
        f"USING (SELECT {source_row}) AS src\n"
        f"   ON {on_clause}\n"
        f" WHEN MATCHED THEN UPDATE SET\n"
        f"           {update_set}\n"
        f" WHEN NOT MATCHED THEN INSERT ({insert_cols})\n"
        f"      VALUES ({insert_vals});"
    )


# =============================================================================
# Parsing
# =============================================================================
def _clean(value: Any) -> Any:
    """Normalise empty strings to None so they land as SQL NULL."""
    if isinstance(value, str) and value.strip() == "":
        return None
    return value


def _csv(value: Any) -> Any:
    """Render a list as a comma-separated string for storage in one column."""
    if isinstance(value, list):
        return ",".join(str(v) for v in value) or None
    return _clean(value)


def _tags_to_string(tags: Any) -> Any:
    """Flatten a free-form tags mapping to `k=v;k=v` for a single column."""
    if not isinstance(tags, dict) or not tags:
        return None
    return ";".join(f"{k}={v}" for k, v in sorted(tags.items()))


def _aliases_to_string(aliases: Any) -> Any:
    """
    Flatten the DQ alias map to `alias=col1,col2;alias=col3` for one column.

    Rule expressions are stored with {alias} placeholders intact, because which
    physical column an alias resolves to is only knowable at run time. The map
    therefore has to travel with the metadata, or the DQ engine cannot resolve
    the placeholders it was given.
    """
    if not isinstance(aliases, dict) or not aliases:
        return None
    parts = []
    for alias, candidates in sorted(aliases.items()):
        if isinstance(candidates, list):
            parts.append(f"{alias}={','.join(str(c) for c in candidates)}")
        else:
            parts.append(f"{alias}={candidates}")
    return ";".join(parts)


def parse_alias_string(text: Any) -> Dict[str, List[str]]:
    """Inverse of _aliases_to_string. Used by the runtime DQ engine."""
    result: Dict[str, List[str]] = {}
    if not text:
        return result
    for chunk in str(text).split(";"):
        if "=" not in chunk:
            continue
        alias, candidates = chunk.split("=", 1)
        result[alias.strip()] = [c.strip() for c in candidates.split(",") if c.strip()]
    return result


def parse_config(
    config: Dict[str, Any],
    config_path: str = "<in-memory>",
    parent_pipeline_id: str | None = None,
    task_id: str | None = None,
    task_name: str = "",
) -> ParsePlan:
    """Translate a valid config dict into a ParsePlan.

    Parameters
    ----------
    parent_pipeline_id : if set, used as pipeline_id (the parent pipeline).
    task_id : if set, used as the unique task identifier.
    task_name : short task name from YAML (e.g. 'bitbucket_to_bronze').

    For v0.1 single-task configs, task_id defaults to pipeline_id (same thing).
    For v0.2 multi-task configs, parse_multi_task_config() provides both.
    """
    pipeline = config.get("pipeline") or {}
    source = config.get("source") or {}
    target = config.get("target") or {}
    connector = config.get("connector") or {}
    dataset = config.get("dataset") or {}
    columns = config.get("columns") or []
    quality = config.get("quality") or {}

    config_file = str(Path(config_path).resolve()) if config_path != "<in-memory>" else config_path
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    pipeline_name = pipeline.get("pipeline_name", "")
    execution_order = pipeline.get("execution_order", 50)
    column_mode = dataset.get("column_mode", "")

    # --- identifiers ---------------------------------------------------------
    config_file_name = Path(config_path).name

    # pipeline_id = parent pipeline (one per YAML)
    # task_id = unique per task (auto-generated)
    if parent_pipeline_id:
        pipeline_id = parent_pipeline_id
    else:
        pipeline_id = generate_id(pipeline_name, config_file_name)

    if task_id is None:
        # v0.1 single-task: task_id = pipeline_id (same thing)
        task_id = pipeline_id

    # A source is identified by where it points, not by which pipeline uses it,
    # so two pipelines reading the same location share a source_id.
    source_id = generate_id(
        source.get("source_type", ""),
        source.get("connection_ref", ""),
        source.get("root_path", ""),
        source.get("source_table", ""),
    )
    target_id = generate_id(
        target.get("target_type", ""),
        target.get("target_table", ""),
        target.get("target_path", ""),
    )
    dataset_id = generate_id(task_id, dataset.get("object_name", ""))

    plan = ParsePlan(
        config_path=config_path,
        pipeline_id=pipeline_id,
        task_id=task_id,
        task_name=task_name,
        pipeline_name=pipeline_name,
        execution_order=execution_order,
        dataset_id=dataset_id,
        config_version=str(config.get("config_version", "")),
        column_mode=column_mode,
    )

    # --- pipeline_config -----------------------------------------------------
    plan.add(
        MetadataAction(
            table=TABLE_PIPELINE_CONFIG,
            operation="MERGE",
            keys={"task_id": task_id},
            values={
                "pipeline_id": pipeline_id,
                "task_id": task_id,
                "task_name": task_name or pipeline_name,
                "pipeline_name": pipeline_name,
                "description": _clean(pipeline.get("description")),
                "application": _clean(pipeline.get("application")),
                "team": _clean(pipeline.get("team")),
                "owner_email": _clean(pipeline.get("owner_email")),
                "schedule": _clean(pipeline.get("schedule")),
                "tags": _tags_to_string(pipeline.get("tags")),
                "config_file_name": config_file_name,
                "config_file_path": config_file,
                "config_version": plan.config_version,
                "active": pipeline.get("active", True),
                "created_at": now,
                "updated_at": now,
            },
        )
    )

    # --- source_config -------------------------------------------------------
    plan.add(
        MetadataAction(
            table=TABLE_SOURCE_CONFIG,
            operation="MERGE",
            keys={"source_id": source_id},
            values={
                "source_id": source_id,
                "pipeline_id": pipeline_id,
                "task_id": task_id,
                "source_name": _clean(source.get("source_name")),
                "source_description": _clean(source.get("source_description")),
                "source_type": _clean(source.get("source_type")),
                "connection_ref": _clean(source.get("connection_ref")),
                "root_path": _clean(source.get("root_path")),
                "source_table": _clean(source.get("source_table")),
                "file_format": _clean(source.get("file_format")),
                "landing_required": source.get("landing_required", False),
                "config_file_path": config_file,
                "created_at": now,
                "updated_at": now,
            },
        )
    )

    # --- target_config -------------------------------------------------------
    plan.add(
        MetadataAction(
            table=TABLE_TARGET_CONFIG,
            operation="MERGE",
            keys={"target_id": target_id},
            values={
                "target_id": target_id,
                "pipeline_id": pipeline_id,
                "task_id": task_id,
                "target_name": _clean(target.get("target_name")),
                "target_type": _clean(target.get("target_type")),
                "target_table": _clean(target.get("target_table")),
                "target_path": _clean(target.get("target_path")),
                "config_file_path": config_file,
                "created_at": now,
                "updated_at": now,
            },
        )
    )

    # --- connector_config (enterprise pattern: single JSON config column) -----
    if connector:
        connector_type = connector.get("connector_type", "")
        secret_ref = connector.get("secret_ref", "")

        # Parse secret_ref as "scope/key" format
        secret_scope = ""
        secret_key = ""
        if secret_ref and "/" in secret_ref:
            parts = secret_ref.split("/", 1)
            secret_scope = parts[0]
            secret_key = parts[1]

        # Build connector_configuration JSON (flexible payload)
        files_payload = []
        for file_entry in (connector.get("files") or []):
            if not isinstance(file_entry, dict):
                continue
            files_payload.append({
                "url": file_entry.get("url", ""),
                "landing_filename": file_entry.get("landing_filename", ""),
                "active": file_entry.get("active", True),
            })

        connector_configuration = json.dumps({
            "secret_scope": secret_scope,
            "secret_key": secret_key,
            "files": files_payload,
        }, indent=None)

        connector_id = generate_id(pipeline_id, connector_type)
        connector_name = f"{pipeline_name}_{connector_type}"
        owner_email = pipeline.get("owner_email", "framework")

        plan.add(
            MetadataAction(
                table=TABLE_CONNECTOR_CONFIG,
                operation="MERGE",
                keys={"connector_id": connector_id},
                values={
                    "connector_id": connector_id,
                    "connector_name": connector_name,
                    "connector_description": _clean(connector.get("description")),
                    "connector_type_id": _clean(connector_type),
                    "data_source_id": source_id,
                    "connector_configuration": connector_configuration,
                    "create_user_id": owner_email,
                    "create_timestamp": now,
                    "last_update_user_id": owner_email,
                    "last_update_timestamp": now,
                },
            )
        )

    # --- dataset_config ------------------------------------------------------
    plan.add(
        MetadataAction(
            table=TABLE_DATASET_CONFIG,
            operation="MERGE",
            keys={"dataset_id": dataset_id},
            values={
                "dataset_id": dataset_id,
                "pipeline_id": pipeline_id,
                "task_id": task_id,
                "source_id": source_id,
                "target_id": target_id,
                "object_name": _clean(dataset.get("object_name")),
                "description": _clean(dataset.get("description")),
                "ingestion_method": _clean(dataset.get("ingestion_method")),
                "load_type": _clean(dataset.get("load_type")),
                "column_mode": _clean(column_mode),
                "primary_key": _csv(dataset.get("primary_key")),
                "incremental_column": _clean(dataset.get("incremental_column")),
                "source_path": _clean(dataset.get("source_path")),
                "trim_all": dataset.get("trim_all", False),
                "exclude_etl_columns": dataset.get("exclude_etl_columns", True),
                # The engine choice must reach the runtime. Without it the
                # executor cannot tell a native-engine config from an inline one
                # with no rules, and would silently skip data quality entirely.
                "dq_engine": _clean(quality.get("engine")),
                "dq_aliases": _aliases_to_string(quality.get("aliases")),
                "notebook_name": _clean(dataset.get("notebook_name")),
                "notebook_path": _clean(dataset.get("notebook_path")),
                "active": dataset.get("active", True),
                "config_file_path": config_file,
                "created_at": now,
                "updated_at": now,
            },
        )
    )

    # --- column_config: only in explicit mode --------------------------------
    if column_mode == "explicit":
        for position, column in enumerate(columns, start=1):
            if not isinstance(column, dict):
                continue
            source_column = column.get("source_column")
            plan.add(
                MetadataAction(
                    table=TABLE_COLUMN_CONFIG,
                    operation="MERGE",
                    keys={"dataset_id": dataset_id, "source_column": source_column},
                    values={
                        "dataset_id": dataset_id,
                        "pipeline_id": pipeline_id,
                        "task_id": task_id,
                        "source_column": source_column,
                        "target_column": _clean(column.get("target_column")),
                        "target_type": _clean(column.get("target_type")),
                        # Column order in the YAML is column order in the target.
                        "column_position": position,
                        "config_file_path": config_file,
                        "created_at": now,
                        "updated_at": now,
                    },
                )
            )

    # --- quality_rule_config: only for the inline engine ---------------------
    engine = quality.get("engine")

    if engine == "inline":
        for rule in quality.get("rules") or []:
            if not isinstance(rule, dict):
                continue
            rule_name = rule.get("rule_name", "")
            rule_id = generate_id(dataset_id, _slug(rule_name))
            plan.add(
                MetadataAction(
                    table=TABLE_QUALITY_RULE_CONFIG,
                    operation="MERGE",
                    keys={"rule_id": rule_id},
                    values={
                        "rule_id": rule_id,
                        "dataset_id": dataset_id,
                        "pipeline_id": pipeline_id,
                        "task_id": task_id,
                        "rule_name": rule_name,
                        "rule_expression": _clean(rule.get("rule_expression")),
                        "action": _clean(rule.get("action")),
                        "severity": _clean(rule.get("severity")),
                        "active": rule.get("active", True),
                        "rule_source": "inline",
                        "config_file_path": config_file,
                        "created_at": now,
                        "updated_at": now,
                    },
                )
            )

    # --- notes ---------------------------------------------------------------
    _add_notes(plan, dataset, quality, column_mode)
    return plan


def _add_notes(plan: ParsePlan, dataset: Dict, quality: Dict, column_mode: str) -> None:
    """Explain what the plan will and will not do, in plain language."""
    if column_mode == "star":
        if dataset.get("exclude_etl_columns", True):
            plan.notes.append(
                f"column_mode = star — all source columns pass through; the ETL audit "
                f"columns {ETL_AUDIT_COLUMNS} are excluded from the read and regenerated "
                f"on write. No column_config rows are produced."
            )
        else:
            plan.notes.append(
                "column_mode = star with exclude_etl_columns = false — upstream ETL audit "
                "columns will be copied into the target. Traceability will be misleading."
            )
    elif column_mode == "explicit":
        plan.notes.append(
            f"column_mode = explicit — {len(plan.actions_for(TABLE_COLUMN_CONFIG))} "
            f"column_config row(s); unlisted columns are dropped."
        )
    elif column_mode == "notebook":
        plan.notes.append(
            f"column_mode = notebook — the reference to '{dataset.get('notebook_name')}' at "
            f"'{dataset.get('notebook_path')}' is recorded. The notebook content is NOT stored "
            f"(it is versioned in Bitbucket) and the framework does not execute it yet."
        )

    engine = quality.get("engine")
    if engine == "inline":
        plan.notes.append(
            f"quality.engine = inline — {len(plan.actions_for(TABLE_QUALITY_RULE_CONFIG))} "
            f"rule row(s) written to {TABLE_QUALITY_RULE_CONFIG}"
        )
    elif engine == "native":
        plan.notes.append(
            f"quality.engine = native — rules read at run time from "
            f"'{quality.get('rules_path')}'. No rows written to {TABLE_QUALITY_RULE_CONFIG}."
        )
    elif engine == "great_expectations":
        plan.notes.append(
            f"quality.engine = great_expectations — validation runs against GX suite "
            f"'{quality.get('suite_name')}'. No rows written to {TABLE_QUALITY_RULE_CONFIG}."
        )

    if dataset.get("load_type") == "FULL":
        plan.notes.append("load_type = FULL — the target is replaced on each run")


# =============================================================================
# Multi-task parsing (v0.2)
# =============================================================================
def parse_multi_task_config(
    config: Dict[str, Any], config_path: str = "<in-memory>"
) -> List[ParsePlan]:
    """
    Parse a v0.2 multi-task config into a list of ParsePlans (one per task).

    Generates:
    - ONE pipeline_id for the entire YAML (from pipeline_name + config_file_name)
    - ONE task_id per task (auto-generated from pipeline_name + task_name + config_file_name)

    The shared `pipeline:` section is merged with each task. Each task gets its
    own row in pipeline_config, grouped by the shared pipeline_id.
    """
    shared_pipeline = config.get("pipeline") or {}
    shared_connector = config.get("connector") or {}
    tasks = config.get("tasks") or []
    base_name = shared_pipeline.get("pipeline_name", "")
    config_file_name = Path(config_path).name

    # ONE pipeline_id for the entire YAML (the parent)
    parent_pipeline_id = generate_id(base_name, config_file_name)

    plans: List[ParsePlan] = []
    for i, task in enumerate(tasks):
        if not isinstance(task, dict):
            continue

        task_short_name = task.get("task_name", "")
        task_pipeline_name = f"{base_name}_{task_short_name}" if task_short_name else base_name

        # Auto-generate task_id (unique per task)
        task_id = generate_id(base_name, task_short_name, config_file_name)

        # Build a v0.1-compatible config dict for the existing parse_config()
        task_config: Dict[str, Any] = {
            "config_version": config.get("config_version", "0.2"),
            "pipeline": {
                **shared_pipeline,
                "pipeline_name": task_pipeline_name,
                "description": task.get("description", shared_pipeline.get("description", "")),
            },
            "source": task.get("source") or {},
            "target": task.get("target") or {},
            "dataset": task.get("dataset") or {},
            "columns": task.get("columns") or [],
            "quality": task.get("quality") or {},
        }

        # Connector belongs to the first task (landing stage) only
        if i == 0 and shared_connector:
            task_config["connector"] = shared_connector

        # Map v0.2 source fields to v0.1 fields the parser expects
        source = task_config["source"]
        if "source_path" in source and "root_path" not in source:
            source["root_path"] = source["source_path"]
        if "source_format" in source and "file_format" not in source:
            source["file_format"] = source["source_format"]

        plan = parse_config(
            task_config,
            config_path=config_path,
            parent_pipeline_id=parent_pipeline_id,
            task_id=task_id,
            task_name=task_short_name,
        )
        plans.append(plan)

    return plans


def parse_config_auto(
    config: Dict[str, Any], config_path: str = "<in-memory>"
) -> List[ParsePlan]:
    """
    Auto-detect config version and parse accordingly.

    Returns a list of ParsePlans:
    - v0.1 (single-task): returns [plan] (one-element list)
    - v0.2 (multi-task):  returns [plan_task1, plan_task2, ...]
    """
    has_tasks = "tasks" in config and isinstance(config.get("tasks"), list)

    if has_tasks:
        return parse_multi_task_config(config, config_path=config_path)
    else:
        return [parse_config(config, config_path=config_path)]


def parse_config_file(config_path: Path | str) -> ParsePlan:
    """Read a config file from disk and parse it into a ParsePlan (v0.1 only)."""
    config_path = Path(config_path)
    with open(config_path, "r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    return parse_config(config, config_path=str(config_path))


def parse_config_file_auto(config_path: Path | str) -> List[ParsePlan]:
    """Read a config file and auto-detect v0.1 or v0.2, returning a list of plans."""
    config_path = Path(config_path)
    with open(config_path, "r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    return parse_config_auto(config, config_path=str(config_path))
