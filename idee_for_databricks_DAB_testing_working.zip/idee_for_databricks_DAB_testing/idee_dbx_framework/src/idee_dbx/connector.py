"""
idee_dbx.connector — Fetch source data from remote systems.

Reads the connector: section from a pipeline YAML and downloads each active
file to the landing Volume before pipeline execution begins.

Supported connector_type values:
    bitbucket_http  — Bitbucket Server or Cloud (browse URLs auto-converted)
    s3_http         — S3 / ABFSS / GCS paths (uses dbutils.fs)
    github          — GitHub raw/blob URLs
    sharepoint      — SharePoint/OneDrive direct download links
    local           — no-op, file is already in the Volume

Usage (from a pipeline notebook):
    from idee_dbx.connector import run_connector
    run_connector(config_path="path/to/config.yaml", dbutils=dbutils)
"""

import re
from urllib.parse import urlparse, parse_qs

import requests
import yaml


# =============================================================================
# URL resolution — convert browser URLs to raw-content API endpoints
# =============================================================================

def _resolve_raw_url(url: str, connector_type: str) -> tuple[str, dict]:
    """Convert a browser URL to a raw-content API URL.

    Returns (raw_url, extra_headers). The caller adds Authorization.
    """
    parsed = urlparse(url)
    host = parsed.hostname or ""
    path_parts = [p for p in parsed.path.split("/") if p]

    # --- Bitbucket Server ---
    if connector_type == "bitbucket_http" and "projects" in path_parts and "repos" in path_parts:
        proj_idx = path_parts.index("projects")
        repo_idx = path_parts.index("repos")
        project = path_parts[proj_idx + 1]
        repo = path_parts[repo_idx + 1]

        if "browse" in path_parts:
            file_start = path_parts.index("browse") + 1
        elif "raw" in path_parts:
            file_start = path_parts.index("raw") + 1
        else:
            file_start = repo_idx + 2

        file_path = "/".join(path_parts[file_start:])
        branch = parse_qs(parsed.query).get("at", ["main"])[0]
        branch = re.sub(r"^refs/heads/", "", branch)

        raw_url = (
            f"{parsed.scheme}://{parsed.netloc}"
            f"/rest/api/1.0/projects/{project}/repos/{repo}/raw/{file_path}"
            f"?at={branch}"
        )
        return raw_url, {}

    # --- Bitbucket Cloud ---
    if connector_type == "bitbucket_http" and "bitbucket.org" in host:
        workspace = path_parts[0]
        repo = path_parts[1]
        branch = path_parts[3]
        file_path = "/".join(path_parts[4:])
        raw_url = (
            f"https://api.bitbucket.org/2.0/repositories"
            f"/{workspace}/{repo}/src/{branch}/{file_path}"
        )
        return raw_url, {}

    # --- GitHub ---
    if connector_type == "github" and "github.com" in host:
        if "blob" in path_parts:
            blob_idx = path_parts.index("blob")
            owner = path_parts[0]
            repo = path_parts[1]
            branch = path_parts[blob_idx + 1]
            file_path = "/".join(path_parts[blob_idx + 2:])
            raw_url = f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{file_path}"
            return raw_url, {}

    # --- SharePoint / OneDrive ---
    if connector_type == "sharepoint":
        return url, {}

    # --- Fallback: use URL as-is ---
    return url, {}


# =============================================================================
# Core fetch logic
# =============================================================================

def _fetch_files(connector: dict, landing_path: str, dbutils) -> list[dict]:
    """Fetch each active file entry to landing_path. Returns status list."""
    connector_type = connector.get("connector_type", "bitbucket_http")
    secret_ref = connector.get("secret_ref", "")
    files = connector.get("files", [])

    if not files:
        return []

    # Resolve token from secret_ref (format: "scope/key")
    token = None
    if secret_ref and connector_type not in ("local", "s3_http"):
        scope, key = secret_ref.split("/", 1)
        token = dbutils.secrets.get(scope=scope, key=key)

    results = []
    for entry in files:
        url = entry.get("url", "").strip()
        filename = entry.get("landing_filename", "")
        active = entry.get("active", True)

        if not active:
            results.append({"filename": filename, "bytes": 0, "status": "SKIPPED (inactive)"})
            continue
        if not url:
            results.append({"filename": filename, "bytes": 0, "status": "SKIPPED (no URL)"})
            continue

        try:
            # --- Cloud storage (S3 / ABFSS / GCS) ---
            if connector_type == "s3_http" or url.startswith(("s3://", "abfss://", "gs://")):
                dest = f"{landing_path.rstrip('/')}/{filename}"
                dbutils.fs.cp(url, dest)
                size = dbutils.fs.ls(dest)[0].size
                results.append({"filename": filename, "bytes": size, "status": "OK"})

            # --- HTTP-based connectors ---
            else:
                raw_url, extra_headers = _resolve_raw_url(url, connector_type)
                headers = {**extra_headers}
                if token:
                    headers["Authorization"] = f"Bearer {token}"

                resp = requests.get(raw_url, headers=headers, timeout=60)
                resp.raise_for_status()

                dest = f"{landing_path.rstrip('/')}/{filename}"
                dbutils.fs.put(dest, resp.text, overwrite=True)
                results.append({"filename": filename, "bytes": len(resp.content), "status": "OK"})

        except Exception as e:
            results.append({"filename": filename, "bytes": 0, "status": f"FAILED: {e}"})

    # Clear token from memory
    if token:
        del token

    return results


# =============================================================================
# Public API
# =============================================================================

def run_connector(config_path: str, dbutils, landing_path: str | None = None) -> list[dict]:
    """Execute the connector: section from a pipeline YAML config.

    Args:
        config_path: Path to the pipeline YAML file.
        dbutils: Databricks dbutils instance (for secrets and fs).
        landing_path: Override landing path. If None, derived from
                      the first hop's source.source_path in the YAML.

    Returns:
        List of {filename, bytes, status} dicts. Empty list if no
        connector section or no active files.

    Raises:
        RuntimeError: If any file fetch fails.
    """
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    connector = config.get("connector")
    if not connector:
        print("  Connector: no connector section — skipping.")
        return []

    files = connector.get("files", [])
    has_active = any(
        f.get("active", True) and f.get("url", "").strip()
        for f in files
    )

    if not has_active:
        print("  Connector: no active files — using existing landing data.")
        return []

    # Derive landing path if not explicitly provided
    if landing_path is None:
        first_hop = config["hops"][0]
        landing_path = first_hop["source"].get("source_path")
        if landing_path is None:
            # source_type: connector — derive staging path from target table
            target_table = first_hop.get("target", {}).get("target_table", "")
            if target_table:
                parts = target_table.split(".")
                catalog = parts[0] if len(parts) >= 1 else "main"
                schema = parts[1] if len(parts) >= 2 else "default"
                landing_path = f"/Volumes/{catalog}/{schema}/landing/connector_staging/"
            else:
                landing_path = "/tmp/idee_connector_staging/"

    connector_type = connector.get("connector_type", "unknown")
    print(f"  Connector: {connector_type}")
    print(f"  Landing  : {landing_path}")

    results = _fetch_files(connector, landing_path, dbutils)

    for r in results:
        icon = "OK" if r["status"] == "OK" else "FAIL" if "FAILED" in r["status"] else "SKIP"
        print(f"    [{icon}] {r['filename']} ({r['bytes']:,} bytes)")

    failures = [r for r in results if "FAILED" in r["status"]]
    if failures:
        raise RuntimeError(
            f"Connector fetch failed for {len(failures)} file(s). "
            "Check URLs and token, then retry."
        )

    return results
