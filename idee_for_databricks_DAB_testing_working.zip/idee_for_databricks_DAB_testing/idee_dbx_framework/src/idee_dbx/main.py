"""
Command-line entry point for the iDEE Databricks framework.

This is the single command an application user runs. It wires the three stages
together and prints what happened at each step.

CLI Commands (single-config)
----------------------------
    python -m idee_dbx.main validate --config <yaml>
    python -m idee_dbx.main parse    --config <yaml> --show-sql --catalog X
    python -m idee_dbx.main load     --config <yaml> --catalog X

Asset Bundle Commands (used by asset_bundle_commands notebook)
--------------------------------------------------------------
    from idee_dbx.main import setup_metadata_tables, setup_app_tables
    from idee_dbx.main import load_all_configs, execute_all_pipelines

    # Command 1: Create metadata + application tables
    setup_metadata_tables(spark, catalog, metadata_schema, framework_ddl_dir)
    setup_app_tables(spark, catalog, app_schema, app_ddl_dir)

    # Command 2: Parse all YAML configs and load into metadata tables
    plans = load_all_configs(config_dir, catalog, metadata_schema, schema_dir)

    # Command 3: Execute all ETL pipelines registered in metadata
    execute_all_pipelines(spark, plans, catalog, metadata_schema, app_schema)

Exit codes: 0 = success, 1 = validation or load failure, 2 = bad invocation.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .config_parser import parse_config
from .config_validator import DEFAULT_SCHEMA_DIR, validate_config_file

_BAR = "=" * 78


def _banner(title: str) -> None:
    print(f"\n{_BAR}\n{title}\n{_BAR}")


def _run_validate(args: argparse.Namespace) -> int:
    _banner("STEP 1 — CONFIG VALIDATION")
    print(f"Framework version : {__version__}")
    print(f"Schema directory  : {args.schema_dir}\n")

    result = validate_config_file(args.config, schema_dir=args.schema_dir)
    print(result.report())

    if not result.is_valid:
        print("\nValidation failed. Fix the errors above and re-run.")
        return 1

    print("\nConfig schema validation passed.")
    return 0


def _run_parse(args: argparse.Namespace) -> int:
    exit_code = _run_validate(args)
    if exit_code != 0:
        return exit_code

    result = validate_config_file(args.config, schema_dir=args.schema_dir)

    _banner("STEP 2 — CONFIG PARSING")
    plan = parse_config(result.config, config_path=str(args.config))
    print(plan.summary())

    if args.show_sql:
        _banner("GENERATED MERGE STATEMENTS")
        for statement in plan.to_merge_statements(args.catalog, args.metadata_schema):
            print(statement)
            print()

    print("\nParser completed. Metadata action list generated.")
    return 0


def _run_load(args: argparse.Namespace) -> int:
    exit_code = _run_validate(args)
    if exit_code != 0:
        return exit_code

    result = validate_config_file(args.config, schema_dir=args.schema_dir)

    _banner("STEP 2 — CONFIG PARSING")
    plan = parse_config(result.config, config_path=str(args.config))
    print(plan.summary())

    _banner("STEP 3 — METADATA LOAD")
    from .metadata_loader import load_plan  # imported here so parse works without pyspark

    load_result = load_plan(
        plan,
        catalog=args.catalog,
        metadata_schema=args.metadata_schema,
        dry_run=args.dry_run,
    )
    print(load_result.report())

    if not load_result.succeeded:
        return 1

    print("\nLoad complete." if not args.dry_run else "\nDry run complete — nothing was written.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="idee_dbx",
        description="iDEE for Databricks — validate, parse, and load pipeline configs.",
    )
    parser.add_argument("--version", action="version", version=f"idee_dbx {__version__}")

    subparsers = parser.add_subparsers(dest="command", required=True)

    def add_common(sub: argparse.ArgumentParser) -> None:
        sub.add_argument("--config", required=True, type=Path, help="Path to the filled config YAML file")
        sub.add_argument(
            "--schema-dir",
            default=DEFAULT_SCHEMA_DIR,
            type=Path,
            help="Directory holding the versioned schema files",
        )

    validate_cmd = subparsers.add_parser("validate", help="Validate a config against its schema version")
    add_common(validate_cmd)
    validate_cmd.set_defaults(func=_run_validate)

    parse_cmd = subparsers.add_parser("parse", help="Validate then show the metadata actions produced")
    add_common(parse_cmd)
    parse_cmd.add_argument("--show-sql", action="store_true", help="Print the generated MERGE statements")
    parse_cmd.add_argument("--catalog", default="<catalog>", help="Catalog name used when rendering SQL")
    parse_cmd.add_argument("--metadata-schema", default="idee_metaschema", help="Metadata schema name")
    parse_cmd.set_defaults(func=_run_parse)

    load_cmd = subparsers.add_parser("load", help="Validate, parse, then write to the metadata tables")
    add_common(load_cmd)
    load_cmd.add_argument("--catalog", required=True, help="Unity Catalog name to load into")
    load_cmd.add_argument("--metadata-schema", default="idee_metaschema", help="Metadata schema name")
    load_cmd.add_argument("--dry-run", action="store_true", help="Show statements without executing them")
    load_cmd.set_defaults(func=_run_load)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


# ===========================================================================
# Asset Bundle Commands — high-level functions for post-deployment execution
# Each function = one deployment step (setup, load, execute)
# run_pipeline() wraps ALL steps into a single call for end-user notebooks.
# ===========================================================================

import glob
import os


def setup_metadata_tables(
    spark,
    catalog: str,
    metadata_schema: str,
    framework_ddl_dir: str | Path,
) -> None:
    """Run all framework DDL scripts to ensure metadata tables exist.

    This is idempotent — safe to run on every deployment.
    Equivalent bundle step: create_metadata_schema
    """
    _banner("SETUP — Metadata Tables")
    ddl_files = sorted(glob.glob(f"{framework_ddl_dir}/*.sql"))
    print(f"  DDL directory : {framework_ddl_dir}")
    print(f"  Found         : {len(ddl_files)} file(s)\n")

    for path in ddl_files:
        sql = open(path).read()
        sql = sql.replace("${catalog}", catalog).replace("${metadata_schema}", metadata_schema)
        fname = os.path.basename(path)
        print(f"  [{fname}]", end=" ")
        spark.sql(sql)
        print("\u2713")

    print(f"\n\u2705 Metadata schema ready.")


def setup_app_tables(
    spark,
    catalog: str,
    app_schema: str,
    app_ddl_dir: str | Path,
) -> None:
    """Run all application DDL scripts to ensure app tables exist.

    This is idempotent — safe to run on every deployment.
    Equivalent bundle step: create_app_tables
    """
    _banner("SETUP — Application Tables")
    ddl_files = sorted(glob.glob(f"{app_ddl_dir}/*.sql"))
    print(f"  DDL directory : {app_ddl_dir}")
    print(f"  Found         : {len(ddl_files)} file(s)\n")

    for path in ddl_files:
        sql = open(path).read()
        sql = sql.replace("${catalog}", catalog).replace("${app_schema}", app_schema)
        fname = os.path.basename(path)
        print(f"  [{fname}]", end=" ")
        spark.sql(sql)
        print("\u2713")

    print(f"\n\u2705 Application tables ready.")


def load_all_configs(
    config_dir: str | Path,
    catalog: str,
    metadata_schema: str,
    schema_dir: str | Path | None = None,
) -> list:
    """Validate, parse, and load ALL YAML configs in a directory into metadata.

    Returns the list of parsed plans (needed by execute_all_pipelines).
    Equivalent bundle step: load_configs
    """
    from .config_parser import parse_config_file_auto
    from .metadata_loader import load_plan

    if schema_dir is None:
        schema_dir = DEFAULT_SCHEMA_DIR

    _banner("LOAD \u2014 Configs to Metadata Tables")
    config_path = Path(config_dir)
    if config_path.is_file():
        # Single file mode
        config_files = [str(config_path)]
        print(f"  Config file      : {config_dir}")
    else:
        # Directory mode (original behavior)
        config_files = sorted(glob.glob(f"{config_dir}/*.yaml"))
        print(f"  Config directory : {config_dir}")
    print(f"  Found            : {len(config_files)} config(s)\n")

    if not config_files:
        print("  [WARN] No YAML files found. Nothing to load.")
        return []

    plans = []
    for config_file in config_files:
        fname = os.path.basename(config_file)

        # Validate
        validation = validate_config_file(config_file, schema_dir=schema_dir)
        if not validation.is_valid:
            print(f"  \u274c [{fname}] VALIDATION FAILED")
            for err in validation.errors:
                print(f"      {err}")
            raise ValueError(f"Config validation failed: {fname}")

        # Parse (returns a list of plans per config)
        file_plans = parse_config_file_auto(config_file)
        plans.extend(file_plans)

        # Load each plan into metadata
        for plan in file_plans:
            load_plan(plan, catalog=catalog, metadata_schema=metadata_schema, dry_run=False)
        print(f"  \u2713 [{fname}] {len(file_plans)} task(s) \u2192 metadata loaded")

    print(f"\n\u2705 {len(config_files)} config(s) processed \u2014 metadata tables updated.")
    return plans


def execute_all_pipelines(
    spark,
    plans: list,
    catalog: str,
    metadata_schema: str,
    app_schema: str,
    dbutils=None,
) -> None:
    """Execute all pipelines from the parsed plans.

    Each plan's tasks are run in dependency order (Landing \u2192 Bronze \u2192 Silver \u2192 Gold).
    Equivalent bundle step: execute_pipelines
    """
    from .runtime import execute_pipeline
    import importlib
    from .runtime import source_readers as _sr
    importlib.reload(_sr)

    _banner("EXECUTE \u2014 Pipeline Tasks")
    # Sort by execution_order so cross-pipeline dependencies resolve correctly
    plans = sorted(plans, key=lambda p: p.execution_order)

    print(f"  Total tasks: {len(plans)}\n")

    for i, plan in enumerate(plans, 1):
        summary = execute_pipeline(
            spark,
            catalog=catalog,
            pipeline_name=plan.pipeline_name,
            metadata_schema=metadata_schema,
            app_schema=app_schema,
            dbutils=dbutils,
        )
        status = "\u2713" if summary.succeeded else "\u274c"
        print(f"  {status} Task {i}/{len(plans)}: {plan.pipeline_name} | "
              f"{summary.rows_read} read | {summary.rows_written} written")

    print(f"\n\u2705 All pipeline tasks executed successfully.")


def register_pipeline_jobs(
    config_dir: str | Path,
    catalog: str,
    metadata_schema: str,
    app_schema: str,
    framework_ddl_dir: str | Path,
    app_ddl_dir: str | Path,
    schema_dir: str | Path | None = None,
    notebook_path: str | None = None,
    dbutils=None,
) -> None:
    """Create or update a Databricks Job for each pipeline config.

    For every YAML with job.create_job = true, this registers (or updates)
    a standalone job in the Databricks Jobs UI. Each job runs independently
    and is named after pipeline.pipeline_name.

    The job task runs the pipeline_builder notebook with config_dir pointing
    to the specific YAML file, so each pipeline is fully isolated.
    """
    import yaml
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.jobs import (
        Task,
        NotebookTask,
        JobSettings,
        CronSchedule,
        PauseStatus,
    )

    _banner("REGISTER — Databricks Jobs")

    # Resolve the notebook path (the calling notebook = pipeline_builder)
    if notebook_path is None and dbutils is not None:
        try:
            ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
            notebook_path = ctx.notebookPath().get()
        except Exception:
            pass

    if notebook_path is None:
        print("  [SKIP] Cannot determine notebook path — job registration skipped.")
        print("         Pass notebook_path explicitly or run from a Databricks notebook.")
        return

    # Resolve config files
    config_path = Path(config_dir)
    if config_path.is_file():
        config_files = [config_path]
    else:
        config_files = sorted(Path(config_dir).glob("*.yaml"))

    print(f"  Notebook task    : {notebook_path}")
    print(f"  Configs found    : {len(config_files)}\n")

    if not config_files:
        print("  [WARN] No YAML files found. No jobs to register.")
        return

    w = WorkspaceClient()
    jobs_created = 0
    jobs_updated = 0

    for config_file in config_files:
        with open(config_file) as f:
            cfg = yaml.safe_load(f)

        job_cfg = cfg.get("job", {})
        if not job_cfg.get("create_job", False):
            print(f"  [SKIP] {config_file.name} — job.create_job is false or missing")
            continue

        pipeline_name = cfg["pipeline"]["pipeline_name"]
        job_description = job_cfg.get("description", cfg["pipeline"].get("description", ""))

        # Build notebook task parameters — same params pipeline_builder uses
        task_params = {
            "catalog": catalog,
            "metadata_schema": metadata_schema,
            "app_schema": app_schema,
            "config_dir": str(config_file),
            "framework_ddl_dir": str(framework_ddl_dir),
            "app_ddl_dir": str(app_ddl_dir),
        }
        if schema_dir:
            task_params["schema_dir"] = str(schema_dir)

        # Build schedule (convert interval/unit to cron or periodic)
        schedule = None
        schedule_cfg = job_cfg.get("schedule", {})
        if schedule_cfg and schedule_cfg.get("interval"):
            unit = schedule_cfg.get("unit", "DAYS").upper()
            interval = schedule_cfg.get("interval", 1)
            # Map to cron expression for the Jobs API
            cron_map = {
                "HOURS": f"0 0 0/{interval} * * ?",
                "DAYS": f"0 0 6 */{interval} * ?",  # 6 AM daily
                "WEEKS": f"0 0 6 ? * MON",           # Monday 6 AM
            }
            cron_expr = cron_map.get(unit, f"0 0 6 */{interval} * ?")
            schedule = CronSchedule(
                quartz_cron_expression=cron_expr,
                timezone_id="UTC",
                pause_status=PauseStatus.UNPAUSED,
            )

        # Build tags
        tags = job_cfg.get("tags", {})
        tags["managed_by"] = "idee_pipeline_builder"
        tags["pipeline_name"] = pipeline_name

        # Timeout
        timeout_seconds = job_cfg.get("timeout_minutes", 60) * 60

        # Parse the config to get individual task names for multi-task DAG
        from .config_parser import parse_config_file_auto
        file_plans = parse_config_file_auto(str(config_file))

        # Build one Databricks Job task per pipeline task, chained with depends_on
        from databricks.sdk.service.jobs import TaskDependency
        job_tasks = []
        prev_task_key = None

        for plan in file_plans:
            # Task key: short name (e.g. "landing_to_bronze"), derived from pipeline_name
            # pipeline_name is like "contracts_etl_landing_to_bronze"
            short_name = plan.pipeline_name.replace(f"{pipeline_name}_", "", 1)
            task_key = short_name or plan.pipeline_name

            # Each task calls the SAME notebook with a task_name param
            single_task_params = {**task_params, "task_name": plan.pipeline_name}
            nb_task = NotebookTask(
                notebook_path=notebook_path,
                base_parameters=single_task_params,
            )

            depends = [TaskDependency(task_key=prev_task_key)] if prev_task_key else []
            job_tasks.append(
                Task(
                    task_key=task_key,
                    notebook_task=nb_task,
                    depends_on=depends if depends else None,
                    timeout_seconds=timeout_seconds,
                )
            )
            prev_task_key = task_key

        # Check if a job with this name already exists (update vs create)
        existing_job_id = None
        try:
            for job_entry in w.jobs.list(name=pipeline_name):
                # Match by managed_by tag to avoid collisions with user-created jobs
                job_tags = job_entry.settings.tags or {}
                if job_tags.get("managed_by") == "idee_pipeline_builder":
                    existing_job_id = job_entry.job_id
                    break
        except Exception:
            pass

        if existing_job_id:
            # Update existing job
            w.jobs.reset(
                job_id=existing_job_id,
                new_settings=JobSettings(
                    name=pipeline_name,
                    tasks=job_tasks,
                    schedule=schedule,
                    tags=tags,
                    max_concurrent_runs=1,
                ),
            )
            print(f"  \u2713 [{pipeline_name}] Job updated (id: {existing_job_id}) — {len(job_tasks)} tasks")
            jobs_updated += 1
        else:
            # Create new job
            created = w.jobs.create(
                name=pipeline_name,
                tasks=job_tasks,
                schedule=schedule,
                tags=tags,
                max_concurrent_runs=1,
            )
            print(f"  \u2713 [{pipeline_name}] Job created (id: {created.job_id}) — {len(job_tasks)} tasks")
            jobs_created += 1

    print(f"\n\u2705 Job registration complete — {jobs_created} created, {jobs_updated} updated.")


def run_single_task(
    spark,
    catalog: str,
    metadata_schema: str,
    app_schema: str,
    config_dir: str | Path,
    task_name: str,
    framework_ddl_dir: str | Path,
    app_ddl_dir: str | Path,
    schema_dir: str | Path | None = None,
    dbutils=None,
) -> None:
    """Run a SINGLE named task from a pipeline config.

    Used by multi-task Databricks Jobs where each job task runs one
    pipeline task independently. Tables are created (idempotent), config
    is loaded, but only the specified task is executed.

    Parameters
    ----------
    task_name : the full pipeline task name (e.g. 'contracts_etl_landing_to_bronze')
    """
    from .runtime import execute_pipeline
    import importlib
    from .runtime import source_readers as _sr
    importlib.reload(_sr)

    print("="*78)
    print(f"  iDEE Pipeline Builder — Single Task Execution")
    print("="*78)
    print(f"  Task           : {task_name}")
    print(f"  Config         : {config_dir}")
    print(f"  Catalog        : {catalog}")
    print()

    # Step 1: Create tables (idempotent)
    setup_metadata_tables(spark, catalog, metadata_schema, framework_ddl_dir)
    setup_app_tables(spark, catalog, app_schema, app_ddl_dir)

    # Step 2: Load config
    plans = load_all_configs(
        config_dir=config_dir,
        catalog=catalog,
        metadata_schema=metadata_schema,
        schema_dir=schema_dir,
    )

    # Step 3: Execute ONLY the named task
    matching = [p for p in plans if p.pipeline_name == task_name]
    if not matching:
        available = [p.pipeline_name for p in plans]
        raise ValueError(
            f"Task '{task_name}' not found in config. Available: {available}"
        )

    plan = matching[0]
    summary = execute_pipeline(
        spark,
        catalog=catalog,
        pipeline_name=plan.pipeline_name,
        metadata_schema=metadata_schema,
        app_schema=app_schema,
        dbutils=dbutils,
    )
    status = "\u2713" if summary.succeeded else "\u274c"
    print(f"\n  {status} {plan.pipeline_name} | {summary.rows_read} read | {summary.rows_written} written")

    if not summary.succeeded:
        raise RuntimeError(f"Task '{task_name}' failed.")

    print(f"\n" + "="*78)
    print(f"  \u2705 TASK COMPLETE")
    print("="*78)


def run_pipeline(
    spark,
    catalog: str,
    metadata_schema: str,
    app_schema: str,
    config_dir: str | Path,
    framework_ddl_dir: str | Path,
    app_ddl_dir: str | Path,
    schema_dir: str | Path | None = None,
    dbutils=None,
) -> None:
    """Single entry point — runs the ENTIRE pipeline end-to-end.

    This is what Ojoma asked for: one import, one command, everything happens.
    Wraps setup + load + execute + job registration.

    Parameters
    ----------
    spark : SparkSession
    catalog : target Unity Catalog catalog name
    metadata_schema : schema for framework metadata tables
    app_schema : schema for application (bronze/silver/gold) tables
    config_dir : path to folder containing *.yaml pipeline configs
    framework_ddl_dir : path to folder containing framework DDL scripts
    app_ddl_dir : path to folder containing application DDL scripts
    schema_dir : (optional) path to JSON schema for validation
    dbutils : (optional) Databricks dbutils reference
    """
    print("="*78)
    print("  iDEE Pipeline Builder — Full Execution")
    print("="*78)
    print(f"  Catalog          : {catalog}")
    print(f"  Metadata schema  : {metadata_schema}")
    print(f"  App schema       : {app_schema}")
    print(f"  Config directory : {config_dir}")
    print(f"  Framework DDL    : {framework_ddl_dir}")
    print(f"  App DDL          : {app_ddl_dir}")
    print()

    # Step 1: Create tables
    setup_metadata_tables(spark, catalog, metadata_schema, framework_ddl_dir)
    setup_app_tables(spark, catalog, app_schema, app_ddl_dir)

    # Step 2: Load configs
    plans = load_all_configs(
        config_dir=config_dir,
        catalog=catalog,
        metadata_schema=metadata_schema,
        schema_dir=schema_dir,
    )

    # Step 3: Execute pipelines
    execute_all_pipelines(spark, plans, catalog, metadata_schema, app_schema, dbutils=dbutils)

    # Step 4: Register Databricks Jobs (one per pipeline config)
    register_pipeline_jobs(
        config_dir=config_dir,
        catalog=catalog,
        metadata_schema=metadata_schema,
        app_schema=app_schema,
        framework_ddl_dir=framework_ddl_dir,
        app_ddl_dir=app_ddl_dir,
        schema_dir=schema_dir,
        dbutils=dbutils,
    )

    print("\n" + "="*78)
    print("  \u2705 PIPELINE BUILDER COMPLETE")
    print("="*78)


if __name__ == "__main__":
    sys.exit(main())
