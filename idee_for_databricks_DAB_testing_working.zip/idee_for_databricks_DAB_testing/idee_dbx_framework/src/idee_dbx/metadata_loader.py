"""
Metadata loader.

Answers one question: **apply the parsed plan to the metadata tables.**

This is the only module that talks to Spark. Keeping it separate from the
parser means the parse step stays pure and testable off-cluster, and a dry run
costs nothing.

Everything is parameterised — catalog and schema are arguments, never
hardcoded — so the same code runs against dev, QA, and prod unchanged.

Usage (inside Databricks)
-------------------------
    from idee_dbx.config_parser import parse_config_file
    from idee_dbx.metadata_loader import load_plan

    plan = parse_config_file("/Workspace/.../customers_landing_to_bronze_config.yaml")
    result = load_plan(plan, catalog="my_catalog", metadata_schema="idee_metaschema")
    print(result.report())
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Optional

from .config_parser import ParsePlan


@dataclass
class LoadResult:
    """Outcome of applying a plan to the metadata tables."""

    catalog: str
    metadata_schema: str
    dry_run: bool
    statements_run: int = 0
    statements_failed: int = 0
    executed: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    @property
    def succeeded(self) -> bool:
        return self.statements_failed == 0

    def report(self) -> str:
        mode = "DRY RUN (nothing written)" if self.dry_run else "LIVE"
        lines = [
            f"Target      : {self.catalog}.{self.metadata_schema}",
            f"Mode        : {mode}",
            f"Statements  : {self.statements_run} run, {self.statements_failed} failed",
            f"Result      : {'SUCCESS' if self.succeeded else 'FAILED'}",
        ]
        if self.errors:
            lines.append("")
            lines.append("Errors:")
            lines.extend(f"  [ERROR] {e}" for e in self.errors)
        return "\n".join(lines)


def _resolve_spark(spark: Optional[Any] = None) -> Any:
    """
    Return a SparkSession.

    Inside a Databricks notebook `spark` already exists in the global scope;
    outside one we build a session. Passing an explicit session (as the tests
    do) bypasses both.
    """
    if spark is not None:
        return spark
    try:
        from pyspark.sql import SparkSession  # imported lazily: absent off-cluster
    except ImportError as exc:  # pragma: no cover - depends on runtime
        raise RuntimeError(
            "pyspark is not available. Run this inside Databricks, or use "
            "dry_run=True to preview the statements without executing them."
        ) from exc
    return SparkSession.builder.getOrCreate()


def load_plan(
    plan: ParsePlan,
    catalog: str,
    metadata_schema: str,
    dry_run: bool = False,
    spark: Optional[Any] = None,
    stop_on_error: bool = True,
) -> LoadResult:
    """
    Apply a ParsePlan to the metadata tables.

    Parameters
    ----------
    plan             : the plan produced by config_parser
    catalog          : Unity Catalog name (parameterised, never hardcoded)
    metadata_schema  : schema holding the metadata tables (e.g. idee_metaschema)
    dry_run          : when True, render statements but execute nothing
    spark            : optional SparkSession; resolved automatically if omitted
    stop_on_error    : halt on the first failure rather than continuing
    """
    result = LoadResult(catalog=catalog, metadata_schema=metadata_schema, dry_run=dry_run)
    statements = plan.to_merge_statements(catalog, metadata_schema)

    if dry_run:
        result.executed = statements
        result.statements_run = len(statements)
        return result

    session = _resolve_spark(spark)

    for statement in statements:
        try:
            session.sql(statement)
            result.executed.append(statement)
            result.statements_run += 1
        except Exception as exc:  # noqa: BLE001 - surfaced to the caller in the report
            result.statements_failed += 1
            first_line = statement.splitlines()[0] if statement else ""
            result.errors.append(f"{first_line} -> {exc}")
            if stop_on_error:
                break

    return result
