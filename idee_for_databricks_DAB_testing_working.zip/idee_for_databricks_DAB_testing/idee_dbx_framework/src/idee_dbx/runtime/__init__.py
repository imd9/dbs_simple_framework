"""
Runtime execution engine.

The metadata side (validator, parser, loader) registers what a pipeline should
do. This package does it: reads the source, shapes the data, applies quality
rules, writes the target, and records the run.

Start with `contracts.py` — it defines the interface every component here
implements, and it is the agreement that lets several people build components
in parallel without them failing to fit together.

    resolve  ->  read  ->  transform  ->  apply_dq  ->  write

Nothing here names a medallion layer. The same executor runs landing->bronze,
bronze->silver and silver->gold; only the config differs.

Implemented in v0.1
-------------------
    sources      cloud_files, delta_table
    column modes star, explicit
    DQ           inline
    targets      delta_table
    load types   FULL

Everything else raises a specific error naming what is missing, rather than
guessing at the semantics.
"""

from .contracts import (  # noqa: F401
    ComponentNotRegistered,
    DQEngine,
    DQResult,
    ExecutionSummary,
    ReadResult,
    RunContext,
    SourceReader,
    TargetWriter,
    Transformer,
    TransformResult,
    WriteResult,
    DQ_ENGINES,
    SOURCE_READERS,
    TARGET_WRITERS,
    TRANSFORMERS,
    get_dq_engine,
    get_source_reader,
    get_target_writer,
    get_transformer,
)
from .config_resolver import (  # noqa: F401
    PipelineNotFound,
    new_run_id,
    resolve_from_metadata,
    resolve_from_plan,
)
from .executor import execute, execute_from_plan, execute_pipeline  # noqa: F401
