"""
Audit logger — writes the run record.

The executor calls this, not the individual components. One place, one truth,
and it still works when a component raises partway through.

Two writes per run: a STARTED row before any data is touched, then an update
with the outcome. The STARTED row matters — without it, a run that dies hard
leaves no trace at all, and "nothing happened" is indistinguishable from "it
never started".

Row construction is pure so it can be tested without Spark.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Optional

from .contracts import ExecutionSummary, RunContext

AUDIT_TABLE = "pipeline_audit"
PARSE_AUDIT_TABLE = "config_parse_audit"


# =============================================================================
# Pure row construction
# =============================================================================
def build_started_row(ctx: RunContext, source_ref: str = "", target_ref: str = "") -> Dict[str, Any]:
    """The row written before any data is read."""
    return {
        "run_id": ctx.run_id,
        "pipeline_id": ctx.pipeline_id,
        "pipeline_name": ctx.pipeline_name,
        "dataset_id": ctx.dataset_id,
        "source_ref": source_ref or None,
        "target_ref": target_ref or None,
        "load_type": ctx.load_type,
        "column_mode": ctx.column_mode,
        "start_time": ctx.started_at or datetime.now(timezone.utc),
        "end_time": None,
        "duration_seconds": None,
        "rows_read": None,
        "rows_written": None,
        "rows_dropped": None,
        "rows_quarantined": None,
        "rows_warned": None,
        "status": "STARTED",
        "error_message": None,
        "source_watermark": None,
        "executed_by": None,
        "created_at": datetime.now(timezone.utc),
    }


def build_final_row(ctx: RunContext, summary: ExecutionSummary) -> Dict[str, Any]:
    """The row written once the run has finished, one way or another."""
    row = build_started_row(ctx, summary.target, summary.target)
    row.update(
        {
            "end_time": summary.ended_at,
            "duration_seconds": summary.duration_seconds,
            "rows_read": summary.rows_read,
            "rows_written": summary.rows_written,
            "rows_dropped": summary.rows_dropped,
            "rows_quarantined": summary.rows_quarantined,
            "rows_warned": summary.rows_warned,
            "status": summary.status,
            "error_message": summary.error_message,
        }
    )
    return row


# =============================================================================
# SQL
# =============================================================================
def _literal(value: Any) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, datetime):
        return f"TIMESTAMP '{value.strftime('%Y-%m-%d %H:%M:%S')}'"
    escaped = str(value).replace("\\", "\\\\").replace("'", "\\'")
    return f"'{escaped}'"


def build_audit_merge(row: Dict[str, Any], catalog: str, metadata_schema: str) -> str:
    """
    MERGE rather than INSERT, keyed on (run_id, dataset_id).

    The STARTED row and the final row are the same run, so the second write
    updates the first instead of leaving two rows to reconcile.
    """
    target = f"{catalog}.{metadata_schema}.{AUDIT_TABLE}"
    columns = list(row.keys())
    source_row = ", ".join(f"{_literal(row[c])} AS {c}" for c in columns)
    updatable = [c for c in columns if c not in ("run_id", "dataset_id", "created_at")]
    update_set = ",\n           ".join(f"tgt.{c} = src.{c}" for c in updatable)

    return (
        f"MERGE INTO {target} AS tgt\n"
        f"USING (SELECT {source_row}) AS src\n"
        f"   ON tgt.run_id = src.run_id AND tgt.dataset_id = src.dataset_id\n"
        f" WHEN MATCHED THEN UPDATE SET\n"
        f"           {update_set}\n"
        f" WHEN NOT MATCHED THEN INSERT ({', '.join(columns)})\n"
        f"      VALUES ({', '.join('src.' + c for c in columns)});"
    )


# =============================================================================
# Writers
# =============================================================================
def write_started(ctx: RunContext, spark: Any, source_ref: str = "", target_ref: str = "") -> None:
    """Record that the run began. Skipped on a dry run."""
    if ctx.dry_run:
        return
    row = build_started_row(ctx, source_ref, target_ref)
    spark.sql(build_audit_merge(row, ctx.catalog, ctx.metadata_schema))


def write_final(ctx: RunContext, summary: ExecutionSummary, spark: Any) -> None:
    """
    Record the outcome.

    Deliberately swallows its own failures: an audit write that raises would
    mask the real error the caller is trying to report. A warning on stdout is
    the lesser evil.
    """
    if ctx.dry_run:
        return
    try:
        row = build_final_row(ctx, summary)
        spark.sql(build_audit_merge(row, ctx.catalog, ctx.metadata_schema))
    except Exception as exc:  # noqa: BLE001
        print(f"WARNING: could not write the audit row for run {ctx.run_id}: {exc}")
