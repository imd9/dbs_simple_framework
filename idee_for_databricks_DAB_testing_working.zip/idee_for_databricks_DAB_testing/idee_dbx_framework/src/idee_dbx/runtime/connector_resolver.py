"""
Connector Resolver — fetches files from remote sources before the pipeline reads.

    resolve_connector(ctx, spark)  →  ConnectorResult

Called by the executor before the source reader. If a connector_config row exists
for this pipeline, it fetches each active file and drops it into the landing zone
(Volume path from source_config.root_path).

If no connector is configured, it's a no-op (returns immediately with fetched=0).
If dry_run=True, it logs what WOULD happen without fetching.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, List

import requests


@dataclass
class ConnectorResult:
    """What the connector step did."""
    fetched: int = 0
    skipped: int = 0
    notes: List[str] = field(default_factory=list)
    failed: bool = False
    error_message: str = ""


def resolve_connector(ctx: Any, spark: Any) -> ConnectorResult:
    """
    Fetch remote files into the landing zone, if a connector is configured.

    Steps:
    1. Query connector_config for this pipeline_id
    2. Parse connector_configuration JSON
    3. Get token from Databricks Secrets
    4. HTTP GET each file → save to Volume
    """
    result = ConnectorResult()

    # Query the metadata table for a connector row
    table = f"{ctx.catalog}.{ctx.metadata_schema}.connector_config"

    try:
        row = (
            spark.table(table)
            .filter(f"data_source_id = '{ctx.source.get('source_id', '')}'")
            .first()
        )
    except Exception:
        # Table might not exist in older deployments — not an error
        result.notes.append("connector_config table not found or not queryable — skipping")
        return result

    if row is None:
        # No connector configured for this pipeline — normal path
        return result

    # Parse the configuration JSON
    try:
        config = json.loads(row["connector_configuration"])
    except (json.JSONDecodeError, TypeError) as e:
        result.failed = True
        result.error_message = f"Invalid connector_configuration JSON: {e}"
        return result

    secret_scope = config.get("secret_scope", "")
    secret_key = config.get("secret_key", "")
    files = config.get("files", [])
    connector_type = row["connector_type_id"]

    if not files:
        result.notes.append("connector configured but no files listed")
        return result

    # Resolve the landing path from source config
    root_path = ctx.source.get("root_path", "")
    if not root_path:
        result.failed = True
        result.error_message = "source.root_path is empty — cannot determine where to save fetched files"
        return result

    # Dry run: report what WOULD happen
    if ctx.dry_run:
        for f in files:
            if f.get("active", True):
                result.notes.append(
                    f"[DRY RUN] would fetch {f.get('landing_filename', '?')} "
                    f"from {f.get('url', '(no url)')[:60]}..."
                )
                result.fetched += 1
            else:
                result.skipped += 1
        return result

    # Live run: get the token
    if not ctx.dbutils:
        result.failed = True
        result.error_message = "dbutils not available — cannot access Databricks Secrets"
        return result

    try:
        token = ctx.dbutils.secrets.get(scope=secret_scope, key=secret_key)
    except Exception as e:
        result.failed = True
        result.error_message = f"Failed to retrieve secret {secret_scope}/{secret_key}: {e}"
        return result

    # Build auth headers based on connector type
    headers = _build_auth_headers(connector_type, token)

    # Fetch each active file
    for file_entry in files:
        if not file_entry.get("active", True):
            result.skipped += 1
            continue

        url = file_entry.get("url", "")
        landing_filename = file_entry.get("landing_filename", "")

        if not url:
            result.notes.append(f"skipping {landing_filename} — no URL configured")
            result.skipped += 1
            continue

        if not landing_filename:
            result.notes.append(f"skipping — no landing_filename for URL")
            result.skipped += 1
            continue

        # Fetch
        try:
            dest_path = f"{root_path}/{landing_filename}"
            _fetch_and_save(url, headers, dest_path, ctx.dbutils)
            result.fetched += 1
            result.notes.append(f"fetched {landing_filename} → {dest_path}")
        except Exception as e:
            result.failed = True
            result.error_message = f"Failed to fetch {landing_filename}: {e}"
            return result

    return result


def _build_auth_headers(connector_type: str, token: str) -> dict:
    """Build HTTP headers based on connector type."""
    connector_type = connector_type.lower()

    if connector_type in ("bitbucket_http", "bitbucket"):
        return {"Authorization": f"Bearer {token}"}
    elif connector_type in ("github",):
        return {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3.raw"}
    elif connector_type in ("gitlab",):
        return {"PRIVATE-TOKEN": token}
    elif connector_type in ("sharepoint",):
        return {"Authorization": f"Bearer {token}", "Accept": "application/json"}
    else:
        # Generic bearer token fallback
        return {"Authorization": f"Bearer {token}"}


def _fetch_and_save(url: str, headers: dict, dest_path: str, dbutils: Any) -> None:
    """HTTP GET a file and write it to the Volume path."""
    response = requests.get(url, headers=headers, timeout=120)
    response.raise_for_status()

    # Write to UC Volume via dbutils or direct file write
    # Volumes are accessible as /Volumes/... paths on the local filesystem
    with open(dest_path, "wb") as f:
        f.write(response.content)
