"""
Data quality engine — the third stage.

Runs before the write, because you cannot quarantine a row you have already
written.

Each rule is a Spark SQL boolean where TRUE means the row passes. Rules are
evaluated together, then rows are routed by the action of whichever rule they
failed. A rule with action `fail` sets `failed_hard` and returns normally; it
does not raise, because the executor still needs to write a FAILED audit row
and that is awkward from inside an exception.

Alias resolution is a pure function and unit-tested. It is the part most likely
to go wrong, since it depends on what columns actually turned up at run time.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from ..config_parser import parse_alias_string
from .contracts import DQ_ENGINES, DQResult, RunContext, TransformResult

# Order matters: the strictest action a row trips is the one that decides its
# fate. A row failing both a `warn` and a `fail` rule must not be let through.
ACTION_SEVERITY = {"warn": 0, "drop": 1, "quarantine": 2, "fail": 3}


class DQFailed(Exception):
    """A rule could not be evaluated. Distinct from a rule finding bad rows."""


# =============================================================================
# Pure helpers
# =============================================================================
def resolve_expression(
    expression: str,
    aliases: Dict[str, List[str]],
    available_columns: List[str],
) -> str:
    """
    Replace {alias} placeholders with the first candidate column that exists.

    Aliases let one rule survive a column rename: write it against `{email}`
    and it works whether the source called it EMAIL_ADDRESS or email_address.

    Raises when no candidate matches, rather than substituting a name that is
    not there — a rule that silently evaluates against a missing column is
    worse than no rule, because it looks like it passed.
    """
    if not expression:
        return expression

    available_lookup = {c.lower(): c for c in available_columns}

    def substitute(match: re.Match) -> str:
        alias = match.group(1)
        candidates = aliases.get(alias, [alias])
        for candidate in candidates:
            actual = available_lookup.get(str(candidate).lower())
            if actual:
                return actual
        raise DQFailed(
            f"rule references {{{alias}}} but none of its candidate columns "
            f"{candidates} exist. Available: {sorted(available_columns)}"
        )

    return re.sub(r"\{(\w+)\}", substitute, expression)


def strictest_action(actions: List[str]) -> Optional[str]:
    """Given the actions a row tripped, return the one that decides its fate."""
    if not actions:
        return None
    return max(actions, key=lambda a: ACTION_SEVERITY.get(a, -1))


def prepare_rules(
    rules: List[Dict[str, Any]],
    alias_text: Any,
    available_columns: List[str],
) -> List[Tuple[Dict[str, Any], str]]:
    """Resolve every active rule's expression. Returns (rule, resolved_expr)."""
    aliases = parse_alias_string(alias_text)
    prepared = []
    for rule in rules:
        if rule.get("active") is False:
            continue
        resolved = resolve_expression(rule.get("rule_expression", ""), aliases, available_columns)
        prepared.append((rule, resolved))
    return prepared


# =============================================================================
# Engine
# =============================================================================
def apply_inline_rules(ctx: RunContext, transformed: TransformResult, spark: Any) -> DQResult:
    """Evaluate the rules stored in quality_rule_config against the frame."""
    from pyspark.sql import functions as F

    df = transformed.df
    rules = ctx.rules

    if not rules:
        total = df.count()
        return DQResult(passing_df=df, rows_passed=total)

    prepared = prepare_rules(rules, ctx.dataset.get("dq_aliases"), df.columns)
    if not prepared:
        total = df.count()
        return DQResult(passing_df=df, rows_passed=total)

    # Tag each row with the actions it tripped, then route once. Evaluating
    # every rule in a single pass avoids re-scanning the data per rule.
    flag_columns = []
    for index, (rule, expression) in enumerate(prepared):
        flag = f"__dq_{index}"
        try:
            df = df.withColumn(
                flag,
                F.when(F.expr(expression), F.lit(None).cast("string")).otherwise(
                    F.lit(rule.get("action", "warn"))
                ),
            )
        except Exception as exc:  # noqa: BLE001
            raise DQFailed(
                f"rule '{rule.get('rule_name')}' could not be evaluated. "
                f"Expression: {expression} -> {exc}"
            ) from exc
        flag_columns.append(flag)

    failed_names = F.concat_ws(
        ",",
        *[
            F.when(F.col(flag).isNotNull(), F.lit(rule.get("rule_name")))
            for flag, (rule, _) in zip(flag_columns, prepared)
        ],
    )
    # -1 means "this rule passed". greatest() then picks the strictest action
    # any rule assigned to the row, so a row failing both warn and fail is
    # treated as fail.
    worst = F.greatest(*[_severity_expr(F.col(flag)) for flag in flag_columns])

    df = df.withColumn("__dq_worst", worst).withColumn("__dq_failed_rules", failed_names)

    total = df.count()
    passing = df.filter(F.col("__dq_worst") < ACTION_SEVERITY["drop"])
    dropped = df.filter(F.col("__dq_worst") == ACTION_SEVERITY["drop"])
    quarantined = df.filter(F.col("__dq_worst") == ACTION_SEVERITY["quarantine"])
    hard_failed = df.filter(F.col("__dq_worst") == ACTION_SEVERITY["fail"])

    rows_dropped = dropped.count()
    rows_quarantined = quarantined.count()
    rows_failed = hard_failed.count()
    rows_warned = df.filter(F.col("__dq_worst") == ACTION_SEVERITY["warn"]).count()

    internal = flag_columns + ["__dq_worst", "__dq_failed_rules"]
    passing_clean = passing.drop(*internal)

    quarantined_out = None
    if rows_quarantined:
        # Keep the reason columns; the quarantine writer needs them.
        quarantined_out = quarantined.drop(*flag_columns)

    failed_rule_names = []
    if rows_failed:
        failed_rule_names = [
            rule.get("rule_name")
            for rule, _ in prepared
            if rule.get("action") == "fail"
        ]

    return DQResult(
        passing_df=passing_clean,
        quarantined_df=quarantined_out,
        rows_passed=total - rows_dropped - rows_quarantined - rows_failed,
        rows_dropped=rows_dropped,
        rows_quarantined=rows_quarantined,
        rows_warned=rows_warned,
        failed_hard=rows_failed > 0,
        failed_rule_names=failed_rule_names,
    )


def _severity_expr(column: Any) -> Any:
    """
    Map a flag column holding an action name to its numeric severity.

    NULL (the rule passed) becomes -1, below every real action.
    """
    from pyspark.sql import functions as F

    expression = F.lit(-1)
    for action, rank in ACTION_SEVERITY.items():
        expression = F.when(column == action, F.lit(rank)).otherwise(expression)
    return expression


def apply_native_rules(ctx: RunContext, transformed: TransformResult, spark: Any) -> DQResult:
    """Not implemented in v0.1 — rules live in an external YAML pack."""
    raise DQFailed(
        "quality.engine 'native' is not executed in v0.1. Rules would be read from "
        f"'{ctx.dataset.get('rules_path')}'. Use the inline engine for now."
    )


def apply_gx_rules(ctx: RunContext, transformed: TransformResult, spark: Any) -> DQResult:
    """Not implemented in v0.1 — rules live in a Great Expectations suite."""
    raise DQFailed(
        "quality.engine 'great_expectations' is not executed in v0.1. "
        "Use the inline engine for now."
    )


# =============================================================================
# Registration
# =============================================================================
DQ_ENGINES["inline"] = apply_inline_rules
DQ_ENGINES["native"] = apply_native_rules
DQ_ENGINES["great_expectations"] = apply_gx_rules
