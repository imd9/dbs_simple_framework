"""
Executor — orchestrates the four stages and owns the audit trail.

    resolve  ->  read  ->  transform  ->  apply_dq  ->  write

It looks each component up from the registries by what the metadata says, so
adding a source type or a column mode never means editing this file. If the
metadata asks for something nobody has built, `ComponentNotRegistered` says so
by name.

Nothing here mentions bronze, silver or gold. The same call runs every hop.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from ..config_parser import ParsePlan
from . import audit_logger
from .config_resolver import resolve_from_metadata, resolve_from_plan
from .contracts import (
    ExecutionSummary,
    RunContext,
    get_dq_engine,
    get_source_reader,
    get_target_writer,
    get_transformer,
)

# Importing these registers their components in the registries.
from . import dq_engine as _dq_engine  # noqa: F401
from . import source_readers as _source_readers  # noqa: F401
from . import target_writers as _target_writers  # noqa: F401
from . import transformer as _transformer  # noqa: F401

from .target_writers import write_quarantine
from .transformer import drop_staging_table


def execute(ctx: RunContext, spark: Any) -> ExecutionSummary:
    """
    Run one pipeline.

    Always returns a summary — including on failure. Raising instead would make
    the caller responsible for the audit row, and it would get skipped exactly
    when it matters most.
    """
    summary = ExecutionSummary(
        run_id=ctx.run_id,
        pipeline_id=ctx.pipeline_id,
        pipeline_name=ctx.pipeline_name,
        status="STARTED",
        started_at=ctx.started_at or datetime.now(timezone.utc),
    )

    if ctx.dataset.get("active") is False:
        summary.status = "SKIPPED"
        summary.ended_at = datetime.now(timezone.utc)
        summary.notes.append("dataset.active is false")
        return summary

    target_ref = ctx.target.get("target_table") or ctx.target.get("target_path") or ""
    audit_logger.write_started(ctx, spark, target_ref=target_ref)

    try:
        # --- 1. read ---------------------------------------------------------
        reader = get_source_reader(ctx.source.get("source_type", ""))
        read = reader(ctx, spark)
        summary.rows_read = read.rows_read
        summary.notes.append(f"read {read.rows_read} row(s) from {read.source_description}")

        # --- 2. transform ----------------------------------------------------
        transform = get_transformer(ctx.column_mode)
        transformed = transform(ctx, read, spark)
        summary.notes.extend(transformed.notes)

        # --- 3. data quality -------------------------------------------------
        dq = get_dq_engine(_quality_engine(ctx))
        dq_result = dq(ctx, transformed, spark)
        summary.rows_dropped = dq_result.rows_dropped
        summary.rows_quarantined = dq_result.rows_quarantined
        summary.rows_warned = dq_result.rows_warned

        if dq_result.rows_quarantined:
            written = write_quarantine(ctx, dq_result, spark)
            summary.notes.append(f"quarantined {written} row(s)")

        # A `fail` rule stops the run before the write. Writing first and
        # failing after would leave the target holding data the rules rejected.
        if dq_result.failed_hard:
            summary.status = "FAILED"
            summary.ended_at = datetime.now(timezone.utc)
            summary.error_message = (
                f"data quality rule(s) with action 'fail' matched: {dq_result.failed_rule_names}. "
                f"Nothing was written."
            )
            audit_logger.write_final(ctx, summary, spark)
            return summary

        # --- 4. write --------------------------------------------------------
        writer = get_target_writer(ctx.target.get("target_type", ""))
        write = writer(ctx, dq_result, spark)
        summary.rows_written = write.rows_written
        summary.target = write.target
        summary.notes.append(f"wrote {write.rows_written} row(s) to {write.target} ({write.write_mode})")

        summary.status = "SUCCESS"

    except Exception as exc:  # noqa: BLE001 — reported through the summary and the audit row
        summary.status = "FAILED"
        summary.error_message = f"{type(exc).__name__}: {exc}"

    finally:
        # Notebook mode leaves a staging table behind. Clean it up whether the
        # run succeeded or not, so a re-run is not confused by stale output.
        if ctx.column_mode == "notebook" and not ctx.dry_run:
            drop_staging_table(ctx, spark)

    summary.ended_at = datetime.now(timezone.utc)
    audit_logger.write_final(ctx, summary, spark)
    return summary


def _quality_engine(ctx: RunContext) -> str:
    """
    Which DQ engine the config asked for.

    Read from metadata rather than inferred. Inferring it from "are there any
    rule rows?" would make a native-engine config indistinguishable from an
    inline one with no rules, and the run would silently skip data quality
    instead of failing — the exact silent substitution this framework refuses
    everywhere else.
    """
    return (ctx.dataset.get("dq_engine") or "inline").lower()


# =============================================================================
# Convenience entry points
# =============================================================================
def execute_from_plan(
    plan: ParsePlan,
    spark: Any,
    catalog: str,
    metadata_schema: str = "idee_metaschema",
    app_schema: str = "idee_app",
    dry_run: bool = False,
    dbutils: Any = None,
) -> ExecutionSummary:
    """
    Run straight from a parsed config, without reading the metadata tables.

    Useful for a dry run before anything has been loaded, and for testing.
    """
    ctx = resolve_from_plan(
        plan, catalog, metadata_schema, dry_run=dry_run, app_schema=app_schema, dbutils=dbutils
    )
    return execute(ctx, spark)


def execute_pipeline(
    spark: Any,
    catalog: str,
    pipeline_name: Optional[str] = None,
    pipeline_id: Optional[str] = None,
    metadata_schema: str = "idee_metaschema",
    app_schema: str = "idee_app",
    dry_run: bool = False,
    dbutils: Any = None,
) -> ExecutionSummary:
    """
    Run a pipeline by name or id, reading its metadata from the tables.

    This is the real entry point: a scheduled job knows a pipeline name, not a
    file path.
    """
    ctx = resolve_from_metadata(
        spark,
        catalog=catalog,
        metadata_schema=metadata_schema,
        pipeline_name=pipeline_name,
        pipeline_id=pipeline_id,
        dry_run=dry_run,
        app_schema=app_schema,
        dbutils=dbutils,
    )
    return execute(ctx, spark)
