"""
Source readers — the first stage. One reader per source type.

Each reader answers "give me a DataFrame for this source" and nothing else. No
transformation, no filtering, no audit columns. Keeping them thin is what lets
a new source type be added without touching anything downstream.

Path resolution is a pure function so it can be tested without Spark, which
matters because joining a root path to a relative path is exactly the kind of
thing that breaks on a trailing slash and is tedious to debug on a cluster.
"""

from __future__ import annotations

from typing import Any, Optional

from .contracts import ReadResult, RunContext, SOURCE_READERS


class SourceNotReadable(Exception):
    """The source could not be read. The message says why."""


# =============================================================================
# Pure helpers
# =============================================================================
def resolve_source_path(root_path: Optional[str], source_path: Optional[str]) -> str:
    """
    Join the source root to the dataset's relative path.

    Handles the trailing-slash cases so callers never have to:

        ("/Volumes/x/landing/", "incoming/*.csv") -> "/Volumes/x/landing/incoming/*.csv"
        ("/Volumes/x/landing",  "/incoming/a.csv") -> "/Volumes/x/landing/incoming/a.csv"
        ("/Volumes/x/landing/", None)              -> "/Volumes/x/landing"
    """
    root = (root_path or "").rstrip("/")
    relative = (source_path or "").strip().lstrip("/")
    if not root:
        raise SourceNotReadable("source.root_path is empty — nothing to read from")
    return f"{root}/{relative}" if relative else root


def build_read_options(file_format: str, has_header: bool = True) -> dict:
    """
    Reader options per file format.

    inferSchema is deliberately OFF. Bronze should preserve the source as text;
    inferring types here means the same file can land with different types on
    different days depending on which rows Spark happened to sample. Casting is
    the transformer's job, driven by column_config.
    """
    fmt = (file_format or "").lower()
    if fmt == "csv":
        return {"header": str(has_header).lower(), "inferSchema": "false"}
    if fmt == "json":
        return {"multiLine": "false"}
    return {}


# =============================================================================
# Readers
# =============================================================================
def read_cloud_files(ctx: RunContext, spark: Any) -> ReadResult:
    """
    Read files from cloud storage.

    A plain batch read, not Auto Loader streaming. That is deliberate for
    load_type = FULL: Auto Loader checkpoints which files it has already seen,
    and combining that with an overwrite would replace the whole target using
    only the newest file. Streaming belongs with append and incremental loads.
    """
    source = ctx.source
    file_format = (source.get("file_format") or "").lower()
    if not file_format:
        raise SourceNotReadable("source.file_format is required for cloud_files")

    path = resolve_source_path(source.get("root_path"), ctx.dataset.get("source_path"))
    options = build_read_options(file_format)

    try:
        df = spark.read.format(file_format).options(**options).load(path)
    except Exception as exc:  # noqa: BLE001 — re-raised with the path, which is the useful part
        raise SourceNotReadable(f"could not read {file_format} from '{path}': {exc}") from exc

    return ReadResult(df=df, rows_read=df.count(), source_description=path)


def read_delta_table(ctx: RunContext, spark: Any) -> ReadResult:
    """
    Read from an existing table.

    This is what makes the second and third hops possible: bronze -> silver and
    silver -> gold both read a table rather than files. Same engine, different
    reader.
    """
    table = ctx.source.get("source_table")
    if not table:
        raise SourceNotReadable("source.source_table is required for delta_table")

    try:
        df = spark.table(table)
    except Exception as exc:  # noqa: BLE001
        raise SourceNotReadable(f"could not read table '{table}': {exc}") from exc

    return ReadResult(df=df, rows_read=df.count(), source_description=table)


def read_connector(ctx: RunContext, spark: Any) -> ReadResult:
    """
    Read files fetched by the connector (Bitbucket, S3, GitHub, SharePoint).

    The connector step has already downloaded the file to a staging path.
    This reader figures out where that staging path is and reads from it
    using the file_format in the source config.
    """
    source = ctx.source
    file_format = (source.get("file_format") or "csv").lower()

    # Determine staging path: use root_path if available, else derive from target
    root_path = (source.get("root_path") or "").strip()
    if not root_path:
        # Derive staging path from target table (catalog.schema)
        target_table = ctx.target.get("target_table", "")
        if target_table:
            parts = target_table.split(".")
            catalog = parts[0] if len(parts) >= 1 else "main"
            schema = parts[1] if len(parts) >= 2 else "default"
            root_path = f"/Volumes/{catalog}/{schema}/landing/connector_staging"
        else:
            raise SourceNotReadable(
                "Cannot determine connector staging path — "
                "source.root_path is empty and target_table is not set."
            )

    path = resolve_source_path(root_path, ctx.dataset.get("source_path"))
    options = build_read_options(file_format, has_header=True)

    try:
        df = spark.read.format(file_format).options(**options).load(path)
    except Exception as exc:  # noqa: BLE001
        raise SourceNotReadable(
            f"could not read connector staging {file_format} from '{path}': {exc}"
        ) from exc

    return ReadResult(df=df, rows_read=df.count(), source_description=f"connector:{path}")


# =============================================================================
# Registration
# =============================================================================
SOURCE_READERS["cloud_files"] = read_cloud_files
SOURCE_READERS["delta_table"] = read_delta_table
SOURCE_READERS["connector"] = read_connector
SOURCE_READERS["api"] = read_connector  # alias — config parser maps connector → api

# jdbc, lakeflow_connect, kafka are intentionally absent. Asking for one
# raises ComponentNotRegistered with a clear message rather than failing oddly
# somewhere downstream.
