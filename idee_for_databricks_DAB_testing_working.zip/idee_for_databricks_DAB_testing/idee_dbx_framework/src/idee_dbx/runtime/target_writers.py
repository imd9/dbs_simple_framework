"""
Target writers — the final data stage. One writer per target type.

Write mode is decided by load_type. Only FULL is implemented; the rest raise a
clear error rather than falling back to something plausible, because a load
type that silently does the wrong thing is worse than one that refuses.

FULL means overwrite, not truncate-then-insert. Delta's overwrite is atomic: a
concurrent reader sees either the old version or the new one, never an empty
table. Truncate-then-insert leaves a real window where the table is empty, and
it muddles time travel.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from .contracts import DQResult, RunContext, TARGET_WRITERS, WriteResult

# The shared quarantine table. One table for every dataset, rather than one per
# dataset: a per-dataset table would need hand-written DDL for every new
# onboarding, which works directly against "onboard by filling out one file".
QUARANTINE_TABLE = "quarantine_records"

WRITE_MODES = {
    "FULL": "overwrite",
    "INCREMENTAL": "append",
    "CDC": "merge",
    "SNAPSHOT": "overwrite",
}

IMPLEMENTED_LOAD_TYPES = {"FULL"}


class WriteFailed(Exception):
    """The target could not be written. The message says why."""


# =============================================================================
# Pure helpers
# =============================================================================
def decide_write_mode(load_type: str) -> str:
    """Map a load type to a Spark write mode, refusing what is not built."""
    load_type = (load_type or "").upper()
    if load_type not in WRITE_MODES:
        raise WriteFailed(f"unknown load_type '{load_type}'. Expected one of {sorted(WRITE_MODES)}")
    if load_type not in IMPLEMENTED_LOAD_TYPES:
        raise WriteFailed(
            f"load_type '{load_type}' is not implemented in v0.1. "
            f"Only {sorted(IMPLEMENTED_LOAD_TYPES)} is supported so far — "
            f"the config validates, but the engine will not guess at the semantics."
        )
    return WRITE_MODES[load_type]


def quarantine_table_name(catalog: str, app_schema: str) -> str:
    return f"{catalog}.{app_schema}.{QUARANTINE_TABLE}"


def split_table_name(table: str) -> Dict[str, str]:
    """Split a three-part name so a writer can find the schema it belongs to."""
    parts = (table or "").split(".")
    if len(parts) != 3:
        raise WriteFailed(f"'{table}' is not a three-part name (catalog.schema.table)")
    return {"catalog": parts[0], "schema": parts[1], "table": parts[2]}


# =============================================================================
# Writers
# =============================================================================
def write_delta_table(ctx: RunContext, dq: DQResult, spark: Any) -> WriteResult:
    """Write the passing rows to a Delta table."""
    table = ctx.target.get("target_table")
    if not table:
        raise WriteFailed("target.target_table is required for target_type delta_table")

    mode = decide_write_mode(ctx.load_type)
    rows = dq.passing_df.count()

    if ctx.dry_run:
        return WriteResult(rows_written=0, target=table, write_mode=f"{mode} (dry run)")

    try:
        (
            dq.passing_df.write.format("delta")
            .mode(mode)
            # Bronze schemas move when a source adds a column. Allowing the
            # target to follow is intended for FULL overwrite; it would be the
            # wrong default for append.
            .option("overwriteSchema", "true" if mode == "overwrite" else "false")
            .saveAsTable(table)
        )
    except Exception as exc:  # noqa: BLE001
        raise WriteFailed(f"could not write to '{table}' in mode '{mode}': {exc}") from exc

    return WriteResult(rows_written=rows, target=table, write_mode=mode)


def write_quarantine(ctx: RunContext, dq: DQResult, spark: Any) -> int:
    """
    Append failing rows to the shared quarantine table.

    The failing row is stored as JSON rather than as typed columns, which is
    what lets one table serve every dataset. Quarantined rows exist to be
    investigated, not analysed, so losing column typing costs little and saves
    a DDL file per onboarding.
    """
    if dq.quarantined_df is None or ctx.dry_run:
        return 0

    from pyspark.sql import functions as F

    table = quarantine_table_name(ctx.catalog, ctx.app_schema)
    business_columns = [c for c in dq.quarantined_df.columns if not c.startswith("__dq_")]

    rows = (
        dq.quarantined_df.select(
            F.lit(ctx.run_id).alias("run_id"),
            F.lit(ctx.pipeline_id).alias("pipeline_id"),
            F.lit(ctx.pipeline_name).alias("pipeline_name"),
            F.lit(ctx.dataset_id).alias("dataset_id"),
            F.col("__dq_failed_rules").alias("failed_rules"),
            F.to_json(F.struct(*[F.col(c) for c in business_columns])).alias("record_json"),
            F.current_timestamp().alias("quarantined_at"),
        )
    )

    count = rows.count()
    try:
        rows.write.format("delta").mode("append").saveAsTable(table)
    except Exception as exc:  # noqa: BLE001
        raise WriteFailed(f"could not write quarantine rows to '{table}': {exc}") from exc
    return count


# =============================================================================
# Registration
# =============================================================================
TARGET_WRITERS["delta_table"] = write_delta_table

# s3, adls and jdbc are intentionally absent. Asking for one raises
# ComponentNotRegistered with a clear message.
