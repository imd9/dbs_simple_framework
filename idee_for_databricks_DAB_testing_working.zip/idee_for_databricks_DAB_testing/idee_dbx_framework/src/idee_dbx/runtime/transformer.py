"""
Transformers — the second stage. One per column_mode.

A transformer takes the raw source frame and returns it in target shape. By the
time it returns, the ETL audit columns are attached; the transformer owns that,
not the writer, so they can never be added twice or forgotten.

The column-selection logic is pure and unit-tested. The Spark calls around it
are deliberately thin, because the part that goes wrong is deciding *which*
columns, not calling `.select()`.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from ..config_parser import ETL_AUDIT_COLUMNS
from .contracts import ReadResult, RunContext, TransformResult, TRANSFORMERS


class TransformFailed(Exception):
    """The frame could not be shaped for the target. The message says why."""


# =============================================================================
# Pure planning
# =============================================================================
def plan_star_columns(available: List[str], exclude_etl: bool = True) -> List[str]:
    """
    Which source columns survive in star mode.

    Not literally every column: the framework's own audit columns are dropped
    when exclude_etl is true, because they are regenerated on write. Copying
    them forward would make the target claim it was loaded when the SOURCE was,
    and the failure is silent until someone audits it.
    """
    if not exclude_etl:
        return list(available)
    return [c for c in available if c not in ETL_AUDIT_COLUMNS]


def plan_explicit_columns(
    column_config: List[Dict[str, Any]],
    available: List[str],
) -> List[Tuple[str, str, str]]:
    """
    Resolve the configured mapping to (source_column, target_column, target_type).

    Fails loudly when a configured column is absent from the source. Silently
    producing a null column instead would hide a schema change until someone
    noticed the data was wrong.
    """
    missing = [
        c["source_column"] for c in column_config if c.get("source_column") not in available
    ]
    if missing:
        raise TransformFailed(
            f"column_config references columns that are not in the source: {missing}. "
            f"Source has: {sorted(available)}"
        )
    return [
        (c["source_column"], c["target_column"], c["target_type"])
        for c in sorted(column_config, key=lambda r: r.get("column_position", 0))
    ]


def plan_trim_columns(
    schema_types: Dict[str, str],
    selected: List[str],
    trim_all: bool,
) -> List[str]:
    """Which columns get trimmed: string columns only, and only when asked."""
    if not trim_all:
        return []
    return [c for c in selected if schema_types.get(c, "").lower() == "string"]


# =============================================================================
# ETL audit columns
# =============================================================================
def add_etl_columns(df: Any, ctx: RunContext, source_description: str) -> Any:
    """
    Attach the framework's audit columns.

    Owned by the transformer so there is exactly one place they are added.
    `_ingested_at` is the processing time of THIS run, never inherited.
    """
    from pyspark.sql import functions as F  # imported lazily: absent off-cluster

    return (
        df.withColumn("_ingested_at", F.current_timestamp())
        .withColumn("_run_id", F.lit(ctx.run_id))
        .withColumn("_pipeline_id", F.lit(ctx.pipeline_id))
        .withColumn("_source_file", F.lit(source_description))
    )


def _schema_types(df: Any) -> Dict[str, str]:
    return {field.name: field.dataType.simpleString() for field in df.schema.fields}


# =============================================================================
# Transformers
# =============================================================================
def transform_star(ctx: RunContext, read: ReadResult, spark: Any) -> TransformResult:
    """Pass every source column through, minus the framework's own."""
    from pyspark.sql import functions as F

    exclude_etl = bool(ctx.dataset.get("exclude_etl_columns", True))
    available = read.df.columns
    selected = plan_star_columns(available, exclude_etl)

    if not selected:
        raise TransformFailed("no columns left after excluding ETL audit columns")

    df = read.df.select(*selected)

    for column in plan_trim_columns(_schema_types(read.df), selected, bool(ctx.dataset.get("trim_all"))):
        df = df.withColumn(column, F.trim(F.col(column)))

    df = add_etl_columns(df, ctx, read.source_description)

    notes = [f"star mode: {len(selected)} source column(s) passed through"]
    dropped = [c for c in available if c not in selected]
    if dropped:
        notes.append(f"excluded upstream ETL columns: {dropped}")

    return TransformResult(df=df, columns_out=df.columns, notes=notes)


def transform_explicit(ctx: RunContext, read: ReadResult, spark: Any) -> TransformResult:
    """Rename and cast per column_config. Unlisted source columns are dropped."""
    from pyspark.sql import functions as F

    mapping = plan_explicit_columns(ctx.columns, read.df.columns)
    if not mapping:
        raise TransformFailed("column_mode is 'explicit' but column_config is empty")

    trim_all = bool(ctx.dataset.get("trim_all"))
    source_types = _schema_types(read.df)

    projections = []
    for source_column, target_column, target_type in mapping:
        expression = F.col(source_column)
        # Trim before casting: " 42 " casts to null, "42" does not.
        if trim_all and source_types.get(source_column, "").lower() == "string":
            expression = F.trim(expression)
        projections.append(expression.cast(target_type).alias(target_column))

    df = read.df.select(*projections)
    df = add_etl_columns(df, ctx, read.source_description)

    return TransformResult(
        df=df,
        columns_out=df.columns,
        notes=[f"explicit mode: {len(mapping)} column(s) mapped, renamed and cast"],
    )


def staging_table_for(ctx: RunContext) -> str:
    """
    Where a custom notebook hands its output back to the framework.

    Keyed on dataset_id so two notebook pipelines cannot collide, and so a
    failed run leaves an inspectable table rather than clobbering another
    pipeline's data.
    """
    return f"{ctx.catalog}.{ctx.app_schema}._staging_{ctx.dataset_id}"


def transform_notebook(ctx: RunContext, read: ReadResult, spark: Any) -> TransformResult:
    """
    Run a user-supplied notebook and pick up what it produced.

    THE CONTRACT
        The framework passes the notebook a `staging_table` parameter. The
        notebook does whatever it likes — joins, unions, window functions, any
        SQL too complex for a YAML file — and writes its result to that table.
        The framework then reads it, adds the ETL audit columns, applies quality
        rules, writes the target, and drops the staging table.

    WHY A TABLE AND NOT A TEMP VIEW
        `dbutils.notebook.run` executes in a SEPARATE Spark session on
        serverless compute, so a temp view created inside the notebook is
        invisible to the caller. A real table is the only thing that survives
        the session boundary. This cost real debugging time to discover; do not
        "simplify" it back to a temp view.

    WHY IT NEVER FALLS BACK SILENTLY
        If the notebook produces nothing, the default is to fail. An empty
        notebook usually means a genuine problem — deleted file, wrong path,
        failed upstream step — and quietly substituting the `columns:` mapping
        would write a completely different dataset while the audit log claimed
        the notebook ran. The fallback exists, but only when the config asks
        for it by name via `on_empty_notebook: use_columns`.
    """
    notebook_path = ctx.dataset.get("notebook_path")
    if not notebook_path:
        raise TransformFailed("column_mode is 'notebook' but dataset.notebook_path is empty")

    if ctx.dbutils is None:
        raise TransformFailed(
            "notebook mode needs dbutils, which only exists inside Databricks. "
            "Pass it in when resolving the context: resolve_from_metadata(..., dbutils=dbutils)."
        )

    staging_table = staging_table_for(ctx)
    timeout = int(ctx.dataset.get("notebook_timeout_seconds") or 600)
    notes = [f"notebook mode: running {notebook_path}"]

    if ctx.dry_run:
        raise TransformFailed(
            "notebook mode cannot be dry-run: the notebook has to execute before there is "
            "anything to inspect. Run with dry_run = false."
        )

    # --- run the notebook -----------------------------------------------------
    try:
        ctx.dbutils.notebook.run(
            notebook_path,
            timeout,
            {"staging_table": staging_table, "run_id": ctx.run_id},
        )
    except Exception as exc:  # noqa: BLE001
        raise TransformFailed(
            f"notebook '{notebook_path}' failed: {exc}. "
            f"Open it directly and run it to see the error in context."
        ) from exc

    # --- pick up what it produced --------------------------------------------
    try:
        df = spark.table(staging_table)
    except Exception as exc:  # noqa: BLE001
        raise TransformFailed(
            f"notebook '{notebook_path}' ran, but did not create the staging table "
            f"'{staging_table}'. The notebook must write its output there — it is passed in "
            f"as the `staging_table` parameter. ({exc})"
        ) from exc

    row_count = df.count()

    if row_count == 0:
        if ctx.on_empty_notebook != "use_columns":
            raise TransformFailed(
                f"notebook '{notebook_path}' ran and created '{staging_table}', but it holds "
                f"0 rows. Nothing was written. This is usually a real problem — check the "
                f"notebook's source paths and any upstream step. To fall back to the "
                f"columns: mapping instead, set dataset.on_empty_notebook: use_columns "
                f"(and supply a columns: section)."
            )
        notes.append(
            f"notebook produced 0 rows; falling back to the columns: mapping because "
            f"on_empty_notebook is 'use_columns'"
        )
        result = transform_explicit(ctx, read, spark)
        result.notes = notes + result.notes
        return result

    notes.append(f"notebook produced {row_count} row(s) via {staging_table}")

    # Trim before the audit columns are attached, so they are never trimmed.
    from pyspark.sql import functions as F

    if ctx.dataset.get("trim_all"):
        for column in plan_trim_columns(_schema_types(df), df.columns, True):
            df = df.withColumn(column, F.trim(F.col(column)))

    df = add_etl_columns(df, ctx, read.source_description or notebook_path)
    return TransformResult(df=df, columns_out=df.columns, notes=notes)


def drop_staging_table(ctx: RunContext, spark: Any) -> None:
    """Clean up after notebook mode. Safe to call when there is nothing to drop."""
    try:
        spark.sql(f"DROP TABLE IF EXISTS {staging_table_for(ctx)}")
    except Exception as exc:  # noqa: BLE001 - cleanup failure must not mask a real error
        print(f"WARNING: could not drop the staging table: {exc}")


# =============================================================================
# Registration
# =============================================================================
TRANSFORMERS["star"] = transform_star
TRANSFORMERS["explicit"] = transform_explicit
TRANSFORMERS["notebook"] = transform_notebook
