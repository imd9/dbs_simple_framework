"""
Unit tests for idee_dbx.config_parser.

Covers: row counts per table across all three column modes, field mapping
fidelity, deterministic ID generation, source reuse, SQL rendering, and
idempotency.
"""

from __future__ import annotations

import pytest

from idee_dbx.config_parser import (
    ETL_AUDIT_COLUMNS,
    TABLE_COLUMN_CONFIG,
    TABLE_DATASET_CONFIG,
    TABLE_PIPELINE_CONFIG,
    TABLE_QUALITY_RULE_CONFIG,
    TABLE_SOURCE_CONFIG,
    TABLE_TARGET_CONFIG,
    generate_id,
    parse_config,
    parse_config_file,
)

CATALOG = "test_catalog"
METADATA_SCHEMA = "idee_metaschema"


def only(plan, table):
    actions = plan.actions_for(table)
    assert len(actions) == 1, f"expected 1 action for {table}, got {len(actions)}"
    return actions[0]


# =============================================================================
# Row counts
# =============================================================================
class TestActionCounts:
    @pytest.mark.parametrize(
        "table",
        [TABLE_PIPELINE_CONFIG, TABLE_SOURCE_CONFIG, TABLE_TARGET_CONFIG, TABLE_DATASET_CONFIG],
    )
    def test_one_row_per_core_table(self, star_config, table):
        assert len(parse_config(star_config).actions_for(table)) == 1

    def test_star_mode_produces_no_column_rows(self, star_config):
        """star passes everything through, so there is nothing to map."""
        assert parse_config(star_config).actions_for(TABLE_COLUMN_CONFIG) == []

    def test_explicit_mode_produces_one_row_per_column(self, explicit_config):
        plan = parse_config(explicit_config)
        assert len(plan.actions_for(TABLE_COLUMN_CONFIG)) == len(explicit_config["columns"])

    def test_notebook_mode_produces_no_column_rows(self, notebook_config):
        """The notebook decides its own columns."""
        assert parse_config(notebook_config).actions_for(TABLE_COLUMN_CONFIG) == []

    def test_columns_ignored_when_mode_is_star(self, star_config):
        star_config["columns"] = [
            {"source_column": "A", "target_column": "a", "target_type": "STRING"}
        ]
        assert parse_config(star_config).actions_for(TABLE_COLUMN_CONFIG) == []

    def test_inline_rules_produce_rule_rows(self, star_config):
        assert len(parse_config(star_config).actions_for(TABLE_QUALITY_RULE_CONFIG)) == 1


# =============================================================================
# Field mapping
# =============================================================================
class TestFieldMapping:
    def test_pipeline_fields_map(self, star_config):
        values = only(parse_config(star_config), TABLE_PIPELINE_CONFIG).values
        pipeline = star_config["pipeline"]
        assert values["pipeline_name"] == pipeline["pipeline_name"]
        assert values["team"] == pipeline["team"]
        assert values["owner_email"] == pipeline["owner_email"]

    def test_config_file_lineage_on_every_row(self, star_config):
        """Every metadata row must trace back to the YAML that produced it."""
        plan = parse_config(star_config, config_path="/tmp/x_config.yaml")
        for action in plan.actions:
            assert action.values.get("config_file_path")

    def test_tags_flattened_to_string(self, star_config):
        values = only(parse_config(star_config), TABLE_PIPELINE_CONFIG).values
        assert values["tags"] == "domain=test"

    def test_primary_key_list_becomes_csv(self, star_config):
        star_config["dataset"]["primary_key"] = ["id", "region"]
        values = only(parse_config(star_config), TABLE_DATASET_CONFIG).values
        assert values["primary_key"] == "id,region"

    def test_column_mode_recorded_on_dataset(self, notebook_config):
        values = only(parse_config(notebook_config), TABLE_DATASET_CONFIG).values
        assert values["column_mode"] == "notebook"

    def test_notebook_reference_recorded_not_content(self, notebook_config):
        values = only(parse_config(notebook_config), TABLE_DATASET_CONFIG).values
        assert values["notebook_name"] == "customer_gold_aggregation"
        assert values["notebook_path"].startswith("/Workspace/")
        assert "notebook_content" not in values

    def test_column_position_preserves_yaml_order(self, explicit_config):
        plan = parse_config(explicit_config)
        positions = [a.values["column_position"] for a in plan.actions_for(TABLE_COLUMN_CONFIG)]
        assert positions == list(range(1, len(positions) + 1))

    def test_empty_strings_become_none(self, star_config):
        star_config["dataset"]["source_path"] = ""
        values = only(parse_config(star_config), TABLE_DATASET_CONFIG).values
        assert values["source_path"] is None

    def test_dataset_links_source_and_target(self, star_config):
        plan = parse_config(star_config)
        dataset = only(plan, TABLE_DATASET_CONFIG).values
        assert dataset["source_id"] == only(plan, TABLE_SOURCE_CONFIG).values["source_id"]
        assert dataset["target_id"] == only(plan, TABLE_TARGET_CONFIG).values["target_id"]


# =============================================================================
# ETL audit columns
# =============================================================================
class TestEtlAuditColumns:
    def test_exclusion_default_is_true(self, star_config):
        del star_config["dataset"]["exclude_etl_columns"]
        values = only(parse_config(star_config), TABLE_DATASET_CONFIG).values
        assert values["exclude_etl_columns"] is True

    def test_star_mode_notes_the_excluded_columns(self, star_config):
        plan = parse_config(star_config)
        assert any(all(c in n for c in ETL_AUDIT_COLUMNS) for n in plan.notes)

    def test_disabling_exclusion_warns_in_notes(self, star_config):
        star_config["dataset"]["exclude_etl_columns"] = False
        plan = parse_config(star_config)
        assert any("misleading" in n.lower() for n in plan.notes)


# =============================================================================
# Identifiers
# =============================================================================
class TestIdentifiers:
    def test_ids_are_deterministic(self, star_config):
        """Re-parsing must yield identical IDs, or MERGE would duplicate rows."""
        first = [a.values for a in parse_config(star_config, "/tmp/a.yaml").actions]
        second = [a.values for a in parse_config(star_config, "/tmp/a.yaml").actions]
        assert [v.get("pipeline_id") for v in first] == [v.get("pipeline_id") for v in second]

    def test_renaming_the_file_creates_a_new_pipeline(self, star_config):
        """
        Pipeline identity is (pipeline_name + file name).

        Copying a YAML to a new filename must produce a NEW pipeline rather
        than silently overwriting the original.
        """
        a = parse_config(star_config, "/tmp/original.yaml").pipeline_id
        b = parse_config(star_config, "/tmp/copy.yaml").pipeline_id
        assert a != b

    def test_renaming_the_pipeline_creates_a_new_pipeline(self, star_config):
        a = parse_config(star_config, "/tmp/x.yaml").pipeline_id
        star_config["pipeline"]["pipeline_name"] = "something_else"
        b = parse_config(star_config, "/tmp/x.yaml").pipeline_id
        assert a != b

    def test_same_location_yields_same_source_id(self, star_config):
        """
        A source is identified by where it points, not by who uses it — so two
        pipelines reading the same place share a source_id. That is what makes
        a source reusable.
        """
        a = only(parse_config(star_config, "/tmp/one.yaml"), TABLE_SOURCE_CONFIG).values["source_id"]
        star_config["pipeline"]["pipeline_name"] = "a_different_pipeline"
        b = only(parse_config(star_config, "/tmp/two.yaml"), TABLE_SOURCE_CONFIG).values["source_id"]
        assert a == b

    def test_different_location_yields_different_source_id(self, star_config):
        a = only(parse_config(star_config), TABLE_SOURCE_CONFIG).values["source_id"]
        star_config["source"]["root_path"] = "/Volumes/test/somewhere_else"
        b = only(parse_config(star_config), TABLE_SOURCE_CONFIG).values["source_id"]
        assert a != b

    def test_rule_ids_are_unique_within_a_dataset(self, star_config):
        star_config["quality"]["rules"].append(
            {
                "rule_name": "Another rule",
                "rule_expression": "1 = 1",
                "action": "warn",
                "severity": "warning",
                "active": True,
            }
        )
        ids = [a.values["rule_id"] for a in parse_config(star_config).actions_for(TABLE_QUALITY_RULE_CONFIG)]
        assert len(ids) == len(set(ids))

    def test_generate_id_is_stable_and_short(self):
        assert generate_id("a", "b") == generate_id("a", "b")
        assert generate_id("a", "b") != generate_id("b", "a")
        assert len(generate_id("a")) == 12

    def test_no_id_comes_from_the_config(self, star_config):
        """Users name things; the framework assigns identifiers."""
        flat = str(star_config)
        for key in ("pipeline_id", "source_id", "target_id", "dataset_id"):
            assert key not in flat


# =============================================================================
# SQL rendering
# =============================================================================
class TestSqlRendering:
    def test_statement_count_matches_action_count(self, explicit_config):
        plan = parse_config(explicit_config)
        assert len(plan.to_merge_statements(CATALOG, METADATA_SCHEMA)) == len(plan.actions)

    def test_all_statements_are_merges(self, star_config):
        for s in parse_config(star_config).to_merge_statements(CATALOG, METADATA_SCHEMA):
            assert s.startswith("MERGE INTO")

    def test_parent_tables_render_before_children(self, explicit_config):
        """FK order: pipeline, then source/target, then dataset, then columns."""
        joined = "\n".join(parse_config(explicit_config).to_merge_statements(CATALOG, METADATA_SCHEMA))
        assert joined.index("pipeline_config") < joined.index("source_config")
        assert joined.index("target_config") < joined.index("dataset_config")
        assert joined.index("dataset_config") < joined.index("column_config")

    def test_single_quotes_are_escaped(self, star_config):
        star_config["pipeline"]["description"] = "O'Brien's pipeline"
        statement = parse_config(star_config).to_merge_statements(CATALOG, METADATA_SCHEMA)[0]
        assert "O\\'Brien\\'s" in statement

    def test_booleans_render_unquoted(self, star_config):
        joined = "\n".join(parse_config(star_config).to_merge_statements(CATALOG, METADATA_SCHEMA))
        assert "TRUE AS active" in joined

    def test_none_renders_as_null(self, star_config):
        star_config["dataset"]["source_path"] = ""
        joined = "\n".join(parse_config(star_config).to_merge_statements(CATALOG, METADATA_SCHEMA))
        assert "NULL AS source_path" in joined

    def test_created_at_is_not_overwritten_on_update(self, star_config):
        """MERGE must not reset created_at when the row already exists."""
        statement = parse_config(star_config).to_merge_statements(CATALOG, METADATA_SCHEMA)[0]
        update_block = statement.split("WHEN MATCHED THEN UPDATE SET")[1].split("WHEN NOT MATCHED")[0]
        assert "created_at" not in update_block

    def test_catalog_is_parameterised(self, star_config):
        statements = parse_config(star_config).to_merge_statements("other_catalog", "other_schema")
        targets = [s.splitlines()[0] for s in statements]
        assert all(t.startswith("MERGE INTO other_catalog.other_schema.") for t in targets)


# =============================================================================
# Plan reporting and files
# =============================================================================
class TestPlanAndFiles:
    def test_summary_is_printable(self, star_config):
        summary = parse_config(star_config).summary()
        assert star_config["pipeline"]["pipeline_name"] in summary
        assert "pipeline_config" in summary

    def test_counts_cover_every_table(self, star_config):
        counts = parse_config(star_config).counts()
        assert set(counts) == {
            TABLE_PIPELINE_CONFIG,
            TABLE_SOURCE_CONFIG,
            TABLE_TARGET_CONFIG,
            TABLE_DATASET_CONFIG,
            TABLE_COLUMN_CONFIG,
            TABLE_QUALITY_RULE_CONFIG,
        }

    def test_every_shipped_app_config_parses(self, app_config_paths):
        assert app_config_paths
        for path in app_config_paths:
            plan = parse_config_file(path)
            assert plan.pipeline_id
            assert len(plan.actions) >= 4

    def test_parsing_is_idempotent(self, app_config_paths):
        """Same input, same plan — a second run must not change anything."""
        path = app_config_paths[0]
        first = [a.values for a in parse_config_file(path).actions]
        second = [a.values for a in parse_config_file(path).actions]
        for a, b in zip(first, second):
            for key in a:
                if key not in ("created_at", "updated_at"):
                    assert a[key] == b[key]


# =============================================================================
# Validator/parser contract
# =============================================================================
class TestValidatorParserContract:
    @pytest.mark.parametrize("fixture", ["star_config", "explicit_config", "notebook_config"])
    def test_anything_valid_can_be_parsed(self, request, schema_dir, fixture):
        from idee_dbx.config_validator import validate_config

        config = request.getfixturevalue(fixture)
        result = validate_config(config, schema_dir=schema_dir)
        assert result.is_valid, result.errors

        plan = parse_config(config)
        assert len(plan.actions) >= 4
