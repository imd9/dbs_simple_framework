"""
Unit tests for idee_dbx.config_validator.

Covers: the happy path across all three column modes, version handling,
required fields, types, enums, list-valued fields, mutually exclusive fields,
conditional requirements, cross-field integrity, warnings, and file handling.

Each test asserts on the specific error raised, not merely that validation
failed — otherwise a test can pass for the wrong reason.
"""

from __future__ import annotations

import pytest

from idee_dbx.config_validator import (
    ValidationResult,
    load_schema,
    validate_config,
    validate_config_file,
)


def errors_mentioning(result: ValidationResult, needle: str) -> list[str]:
    return [e for e in result.errors if needle.lower() in e.lower()]


# =============================================================================
# Happy path — all three column modes
# =============================================================================
class TestValidConfigs:
    def test_star_config_passes(self, star_config, schema_dir):
        r = validate_config(star_config, schema_dir=schema_dir)
        assert r.is_valid, r.errors

    def test_explicit_config_passes(self, explicit_config, schema_dir):
        r = validate_config(explicit_config, schema_dir=schema_dir)
        assert r.is_valid, r.errors

    def test_notebook_config_passes(self, notebook_config, schema_dir):
        r = validate_config(notebook_config, schema_dir=schema_dir)
        assert r.is_valid, r.errors

    def test_records_versions(self, star_config, schema_dir):
        r = validate_config(star_config, schema_dir=schema_dir)
        assert r.config_version == "0.1"
        assert r.schema_version == "0.1"

    def test_every_shipped_app_config_passes(self, app_config_paths, schema_dir):
        """Every filled config in the app folder must validate."""
        assert app_config_paths, "no app configs found"
        for path in app_config_paths:
            r = validate_config_file(path, schema_dir=schema_dir)
            assert r.is_valid, f"{path.name} failed: {r.errors}"

    def test_report_is_printable(self, star_config, schema_dir):
        report = validate_config(star_config, schema_dir=schema_dir).report()
        assert "PASSED" in report


# =============================================================================
# Version handling
# =============================================================================
class TestVersioning:
    def test_missing_config_version_fails(self, star_config, schema_dir):
        del star_config["config_version"]
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "config_version")

    def test_old_key_name_gets_a_specific_hint(self, fixture_dir, schema_dir):
        """A config using config_template_version should be told to rename it."""
        r = validate_config_file(fixture_dir / "invalid_old_version_key_config.yaml", schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "config_template_version")

    def test_unsupported_version_fails(self, fixture_dir, schema_dir):
        r = validate_config_file(fixture_dir / "invalid_unsupported_version_config.yaml", schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "9.9")

    def test_load_schema_returns_expected_version(self, schema_dir):
        schema = load_schema("0.1", schema_dir)
        assert schema["schema_version"] == "0.1"

    def test_load_schema_raises_for_unknown_version(self, schema_dir):
        with pytest.raises(FileNotFoundError):
            load_schema("42.0", schema_dir)


# =============================================================================
# Required sections and fields
# =============================================================================
class TestRequiredFields:
    @pytest.mark.parametrize("section", ["pipeline", "source", "target", "dataset", "quality"])
    def test_missing_section_fails(self, star_config, schema_dir, section):
        del star_config[section]
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, section)

    def test_missing_pipeline_name_fails(self, star_config, schema_dir):
        del star_config["pipeline"]["pipeline_name"]
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "pipeline_name")

    @pytest.mark.parametrize("field", ["source_name", "source_type"])
    def test_missing_source_field_fails(self, star_config, schema_dir, field):
        del star_config["source"][field]
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, f"source.{field}")

    @pytest.mark.parametrize("field", ["target_name", "target_type"])
    def test_missing_target_field_fails(self, star_config, schema_dir, field):
        del star_config["target"][field]
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, f"target.{field}")

    @pytest.mark.parametrize("field", ["object_name", "ingestion_method", "load_type", "column_mode"])
    def test_missing_dataset_field_fails(self, star_config, schema_dir, field):
        del star_config["dataset"][field]
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, f"dataset.{field}")

    def test_blank_string_counts_as_missing(self, star_config, schema_dir):
        star_config["pipeline"]["pipeline_name"] = "   "
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid

    def test_missing_fields_fixture_reports_several(self, fixture_dir, schema_dir):
        r = validate_config_file(fixture_dir / "invalid_missing_required_config.yaml", schema_dir=schema_dir)
        assert not r.is_valid
        # Every problem is reported at once, not just the first.
        assert len(r.errors) >= 3


# =============================================================================
# Types
# =============================================================================
class TestTypeChecking:
    def test_string_where_boolean_expected_fails(self, star_config, schema_dir):
        star_config["dataset"]["trim_all"] = "yes"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "expected boolean")

    def test_bool_is_not_accepted_as_string(self, star_config, schema_dir):
        star_config["pipeline"]["description"] = True
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "expected string")


# =============================================================================
# Enums
# =============================================================================
class TestEnumChecking:
    def test_invalid_source_type_fails(self, star_config, schema_dir):
        star_config["source"]["source_type"] = "sftp"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "source_type")

    def test_invalid_load_type_fails(self, star_config, schema_dir):
        star_config["dataset"]["load_type"] = "UPSERT"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "load_type")

    def test_invalid_column_mode_fails(self, star_config, schema_dir):
        star_config["dataset"]["column_mode"] = "everything"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "column_mode")

    def test_invalid_target_type_fails(self, star_config, schema_dir):
        star_config["target"]["target_type"] = "hive"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "target_type")

    def test_invalid_column_target_type_fails(self, explicit_config, schema_dir):
        explicit_config["columns"][0]["target_type"] = "VARCHAR"
        r = validate_config(explicit_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "target_type")

    def test_bad_enum_fixture_flags_action_and_severity(self, fixture_dir, schema_dir):
        r = validate_config_file(fixture_dir / "invalid_bad_enum_config.yaml", schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "action")
        assert errors_mentioning(r, "severity")


# =============================================================================
# List-valued fields
# =============================================================================
class TestListFields:
    def test_primary_key_must_be_a_list(self, star_config, schema_dir):
        star_config["dataset"]["primary_key"] = "id"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "must be a list")

    def test_composite_primary_key_is_allowed(self, star_config, schema_dir):
        star_config["dataset"]["primary_key"] = ["id", "region"]
        r = validate_config(star_config, schema_dir=schema_dir)
        assert r.is_valid, r.errors

    def test_tags_must_be_a_mapping(self, star_config, schema_dir):
        star_config["pipeline"]["tags"] = ["a", "b"]
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "tags")


# =============================================================================
# Mutually exclusive fields
# =============================================================================
class TestExactlyOneOf:
    def test_target_table_and_path_together_fails(self, star_config, schema_dir):
        star_config["target"]["target_path"] = "s3://bucket/path"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "only one")

    def test_neither_target_table_nor_path_fails(self, star_config, schema_dir):
        del star_config["target"]["target_table"]
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid


# =============================================================================
# Conditional requirements
# =============================================================================
class TestConditionalRules:
    def test_incremental_without_watermark_fails(self, star_config, schema_dir):
        star_config["dataset"]["load_type"] = "INCREMENTAL"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "incremental_column")

    def test_incremental_with_watermark_passes(self, star_config, schema_dir):
        star_config["dataset"]["load_type"] = "INCREMENTAL"
        star_config["dataset"]["incremental_column"] = "updated_at"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert r.is_valid, r.errors

    @pytest.mark.parametrize("load_type", ["CDC", "SNAPSHOT"])
    def test_cdc_and_snapshot_require_primary_key(self, star_config, schema_dir, load_type):
        star_config["dataset"]["load_type"] = load_type
        star_config["dataset"]["primary_key"] = []
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "primary_key")

    def test_cloud_files_requires_root_path(self, star_config, schema_dir):
        star_config["source"]["root_path"] = ""
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "root_path")

    def test_delta_source_requires_source_table(self, explicit_config, schema_dir):
        explicit_config["source"]["source_table"] = ""
        r = validate_config(explicit_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "source_table")

    def test_explicit_mode_requires_columns(self, explicit_config, schema_dir):
        explicit_config["columns"] = []
        r = validate_config(explicit_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "columns")

    @pytest.mark.parametrize("field", ["notebook_path", "notebook_name"])
    def test_notebook_mode_requires_notebook_fields(self, notebook_config, schema_dir, field):
        notebook_config["dataset"][field] = ""
        r = validate_config(notebook_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, field)

    def test_native_engine_requires_rules_path(self, star_config, schema_dir):
        star_config["quality"]["engine"] = "native"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "rules_path")

    def test_gx_engine_requires_suite_name(self, star_config, schema_dir):
        star_config["quality"]["engine"] = "great_expectations"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "suite_name")

    def test_inline_engine_requires_at_least_one_rule(self, star_config, schema_dir):
        star_config["quality"]["rules"] = []
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "rules")


# =============================================================================
# Cross-field integrity
# =============================================================================
class TestIntegrityChecks:
    def test_duplicate_target_column_fails(self, explicit_config, schema_dir):
        explicit_config["columns"][1]["target_column"] = explicit_config["columns"][0]["target_column"]
        r = validate_config(explicit_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "duplicate")

    def test_duplicate_source_column_fails(self, explicit_config, schema_dir):
        explicit_config["columns"][1]["source_column"] = explicit_config["columns"][0]["source_column"]
        r = validate_config(explicit_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "duplicate")

    def test_duplicate_rule_name_fails(self, star_config, schema_dir):
        star_config["quality"]["rules"].append(dict(star_config["quality"]["rules"][0]))
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "duplicate")

    @pytest.mark.parametrize("bad", ["bronze_test", "idee_app.bronze_test", "a.b.c.d"])
    def test_target_table_must_be_three_part(self, star_config, schema_dir, bad):
        star_config["target"]["target_table"] = bad
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "three-part")

    def test_source_table_must_be_three_part(self, explicit_config, schema_dir):
        explicit_config["source"]["source_table"] = "bronze_test"
        r = validate_config(explicit_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "three-part")


# =============================================================================
# Warnings — advisory, must not fail validation
# =============================================================================
class TestWarnings:
    def test_star_without_etl_exclusion_warns(self, star_config, schema_dir):
        """The audit-column trap: warn, but do not block."""
        star_config["dataset"]["exclude_etl_columns"] = False
        r = validate_config(star_config, schema_dir=schema_dir)
        assert r.is_valid
        assert any("traceability" in w.lower() for w in r.warnings)

    def test_inactive_pipeline_warns_but_passes(self, star_config, schema_dir):
        star_config["pipeline"]["active"] = False
        r = validate_config(star_config, schema_dir=schema_dir)
        assert r.is_valid
        assert any("skipped" in w.lower() for w in r.warnings)

    def test_columns_ignored_in_star_mode_warns(self, star_config, schema_dir):
        star_config["columns"] = [
            {"source_column": "A", "target_column": "a", "target_type": "STRING"}
        ]
        r = validate_config(star_config, schema_dir=schema_dir)
        assert r.is_valid
        assert any("ignored" in w.lower() for w in r.warnings)

    def test_notebook_mode_warns_it_is_not_executed(self, notebook_config, schema_dir):
        r = validate_config(notebook_config, schema_dir=schema_dir)
        assert r.is_valid
        assert any("not execute" in w.lower() for w in r.warnings)

    def test_credential_in_connection_ref_warns(self, star_config, schema_dir):
        star_config["source"]["connection_ref"] = "jdbc://host?password=hunter2"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert any("credential" in w.lower() for w in r.warnings)


# =============================================================================
# Notebook mode — the ambiguous states must be unreachable
# =============================================================================
class TestNotebookModeSafety:
    """
    The design choice here is worth stating: when a config is ambiguous the
    framework REFUSES rather than picking a winner. `explicit` and `notebook`
    do not produce similar data — they produce completely different datasets.
    Silently substituting one for the other would write the wrong shape while
    the audit log claimed otherwise.
    """

    def test_notebook_mode_with_a_columns_block_is_an_error(self, notebook_config, schema_dir):
        notebook_config["columns"] = [
            {"source_column": "A", "target_column": "a", "target_type": "STRING"}
        ]
        r = validate_config(notebook_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "columns")

    def test_declaring_the_fallback_makes_columns_allowed(self, notebook_config, schema_dir):
        """`use_columns` is an explicit opt-in, so both sections are then required."""
        notebook_config["dataset"]["on_empty_notebook"] = "use_columns"
        notebook_config["columns"] = [
            {"source_column": "A", "target_column": "a", "target_type": "STRING"}
        ]
        r = validate_config(notebook_config, schema_dir=schema_dir)
        assert r.is_valid, r.errors

    def test_declaring_the_fallback_without_columns_is_an_error(self, notebook_config, schema_dir):
        notebook_config["dataset"]["on_empty_notebook"] = "use_columns"
        r = validate_config(notebook_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "columns")

    def test_fail_is_the_default_when_unset(self, notebook_config, schema_dir):
        del notebook_config["dataset"]["on_empty_notebook"]
        r = validate_config(notebook_config, schema_dir=schema_dir)
        assert r.is_valid, r.errors

    def test_invalid_on_empty_value_is_rejected(self, notebook_config, schema_dir):
        notebook_config["dataset"]["on_empty_notebook"] = "guess"
        r = validate_config(notebook_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "on_empty_notebook")

    def test_missing_notebook_path_is_an_error(self, notebook_config, schema_dir):
        notebook_config["dataset"]["notebook_path"] = ""
        r = validate_config(notebook_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "notebook_path")

    def test_a_notebook_that_does_not_exist_is_an_error(self, notebook_config, schema_dir, monkeypatch):
        """
        Catch a bad path at validation, not deep inside a scheduled job.
        """
        from idee_dbx import config_validator

        monkeypatch.setattr(config_validator, "NOTEBOOK_RESOLVER", lambda path: False)
        r = validate_config(notebook_config, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "no notebook found")

    def test_an_unverifiable_notebook_only_warns(self, notebook_config, schema_dir, monkeypatch):
        """
        Validating off-cluster cannot see workspace paths. Refusing would make
        the validator useless outside Databricks, so it warns instead.
        """
        from idee_dbx import config_validator

        monkeypatch.setattr(config_validator, "NOTEBOOK_RESOLVER", lambda path: None)
        r = validate_config(notebook_config, schema_dir=schema_dir)
        assert r.is_valid, r.errors
        assert any("could not verify" in w for w in r.warnings)

    def test_the_notebook_check_is_skipped_in_other_modes(self, star_config, schema_dir, monkeypatch):
        from idee_dbx import config_validator

        monkeypatch.setattr(config_validator, "NOTEBOOK_RESOLVER", lambda path: False)
        r = validate_config(star_config, schema_dir=schema_dir)
        assert r.is_valid, r.errors


# =============================================================================
# Unimplemented options — warn at validate time, do not block
# =============================================================================
class TestUnimplementedWarnings:
    """
    The schema accepts more than the engine can run, deliberately: a config can
    be written ahead of the engine. But the warning has to fire at validation,
    not halfway through a run.
    """

    @pytest.mark.parametrize("load_type", ["INCREMENTAL", "CDC", "SNAPSHOT"])
    def test_unbuilt_load_types_warn(self, star_config, schema_dir, load_type):
        star_config["dataset"]["load_type"] = load_type
        star_config["dataset"]["incremental_column"] = "updated_at"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert r.is_valid, r.errors
        assert any("NOT IMPLEMENTED" in w for w in r.warnings)

    def test_full_does_not_warn(self, star_config, schema_dir):
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not any("load_type" in w and "NOT IMPLEMENTED" in w for w in r.warnings)

    @pytest.mark.parametrize("source_type", ["jdbc", "kafka", "api"])
    def test_unbuilt_source_types_warn(self, star_config, schema_dir, source_type):
        star_config["source"]["source_type"] = source_type
        r = validate_config(star_config, schema_dir=schema_dir)
        assert any("source_type" in w and "NOT IMPLEMENTED" in w for w in r.warnings)

    @pytest.mark.parametrize("source_type", ["cloud_files", "delta_table"])
    def test_built_source_types_do_not_warn(self, star_config, schema_dir, source_type):
        star_config["source"]["source_type"] = source_type
        if source_type == "delta_table":
            star_config["source"]["source_table"] = "cat.sch.tbl"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert not any("source_type" in w and "NOT IMPLEMENTED" in w for w in r.warnings)

    def test_notebook_mode_is_no_longer_unimplemented(self, notebook_config, schema_dir):
        """All three column modes now execute."""
        r = validate_config(notebook_config, schema_dir=schema_dir)
        assert r.is_valid
        assert not any("column_mode" in w and "NOT IMPLEMENTED" in w for w in r.warnings)

    @pytest.mark.parametrize("engine", ["native", "great_expectations"])
    def test_unbuilt_dq_engines_warn(self, star_config, schema_dir, engine):
        star_config["quality"]["engine"] = engine
        star_config["quality"]["rules_path"] = "dq_rules/x.yaml"
        star_config["quality"]["suite_name"] = "x_suite"
        r = validate_config(star_config, schema_dir=schema_dir)
        assert any("quality.engine" in w and "NOT IMPLEMENTED" in w for w in r.warnings)

    def test_shipped_configs_have_no_unimplemented_warnings(self, app_config_paths, schema_dir):
        """The demo configs must use only what the engine can actually run."""
        for path in app_config_paths:
            r = validate_config_file(path, schema_dir=schema_dir)
            unbuilt = [w for w in r.warnings if "NOT IMPLEMENTED" in w]
            assert not unbuilt, f"{path.name} selects unbuilt options: {unbuilt}"


# =============================================================================
# File handling
# =============================================================================
class TestFileHandling:
    def test_missing_file_reports_cleanly(self, schema_dir, tmp_path):
        r = validate_config_file(tmp_path / "nope.yaml", schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "not found")

    def test_malformed_yaml_reports_parse_error(self, schema_dir, tmp_path):
        bad = tmp_path / "malformed.yaml"
        bad.write_text("source:\n  - this: [is\n    broken", encoding="utf-8")
        r = validate_config_file(bad, schema_dir=schema_dir)
        assert not r.is_valid
        assert errors_mentioning(r, "parse")

    def test_empty_file_reports_cleanly(self, schema_dir, tmp_path):
        empty = tmp_path / "empty.yaml"
        empty.write_text("", encoding="utf-8")
        assert not validate_config_file(empty, schema_dir=schema_dir).is_valid

    def test_blank_template_does_not_validate(self, template_path, schema_dir):
        """
        An unfilled template must never pass.

        Every placeholder in it is syntactically legal, so without the
        placeholder check someone could deploy the template as-is.
        """
        r = validate_config_file(template_path, schema_dir=schema_dir)
        assert not r.is_valid
        assert any("placeholder" in e.lower() for e in r.errors)
