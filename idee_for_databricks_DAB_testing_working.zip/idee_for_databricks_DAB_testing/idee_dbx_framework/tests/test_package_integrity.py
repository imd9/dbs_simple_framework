"""
Package integrity tests.

These do not test behaviour — they test that the pieces of the project still
agree with each other. Every one of them exists because the alignment it checks
was broken at least once, silently, and was found by reading rather than by a
failing test.

They are cheap, they run off-cluster, and they fail the moment something drifts.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest
import yaml

from idee_dbx.config_parser import ETL_AUDIT_COLUMNS, TABLE_ORDER, parse_config_file

PROJECT_ROOT = Path(__file__).resolve().parents[2]
FRAMEWORK = PROJECT_ROOT / "idee_dbx_framework"
APP = PROJECT_ROOT / "idee_dbx_app"


def ddl_columns(path: Path) -> list[str]:
    """Column names declared by a CREATE TABLE script, in order."""
    text = path.read_text()
    body = re.search(r"CREATE TABLE IF NOT EXISTS[^(]+\((.*?)\n\)", text, re.S)
    assert body, f"no CREATE TABLE found in {path.name}"
    columns = []
    for line in body.group(1).split("\n"):
        line = line.strip()
        if not line or line.startswith(("CONSTRAINT", "--")):
            continue
        match = re.match(r"(\w+)\s+(STRING|BOOLEAN|INT|BIGINT|DOUBLE|DECIMAL|TIMESTAMP|DATE)", line)
        if match:
            columns.append(match.group(1))
    return columns


# =============================================================================
# Parser output must fit the metadata DDL
# =============================================================================
class TestParserMatchesDDL:
    """
    Every column the parser writes has to exist in the table it writes to.

    A mismatch here is invisible until a live load fails on a real cluster,
    which is the most expensive place to find it.
    """

    @pytest.fixture(scope="class")
    def metadata_ddl(self) -> dict:
        result = {}
        for path in (FRAMEWORK / "ddl" / "metadata").glob("*.sql"):
            match = re.search(r"CREATE TABLE IF NOT EXISTS \$\{catalog\}\.\$\{\w+\}\.(\w+)", path.read_text())
            if match:
                result[match.group(1)] = set(ddl_columns(path))
        return result

    def test_all_six_config_tables_have_ddl(self, metadata_ddl):
        for table in TABLE_ORDER:
            assert table in metadata_ddl, f"{table} has no CREATE TABLE script"

    @pytest.mark.parametrize(
        "config_name",
        [
            "customers_landing_to_bronze_config.yaml",
            "customers_bronze_to_silver_config.yaml",
            "customers_combined_landing_to_bronze_config.yaml",
        ],
    )
    def test_every_emitted_column_exists_in_ddl(self, metadata_ddl, config_name):
        plan = parse_config_file(APP / "config" / config_name)
        for action in plan.actions:
            declared = metadata_ddl[action.table]
            unknown = set(action.values) - declared
            assert not unknown, f"{config_name} -> {action.table}: {sorted(unknown)} not in DDL"


# =============================================================================
# The audit writer must fit pipeline_audit
# =============================================================================
class TestAuditMatchesDDL:
    def test_audit_row_columns_match_the_table(self):
        from idee_dbx.config_parser import parse_config_file as parse
        from idee_dbx.runtime import resolve_from_plan
        from idee_dbx.runtime.audit_logger import build_final_row, build_started_row
        from idee_dbx.runtime.contracts import ExecutionSummary

        declared = set(ddl_columns(FRAMEWORK / "ddl" / "metadata" / "08_create_pipeline_audit.sql"))
        plan = parse(APP / "config" / "customers_landing_to_bronze_config.yaml")
        ctx = resolve_from_plan(plan, "cat", "meta")

        started = set(build_started_row(ctx))
        final = set(build_final_row(ctx, ExecutionSummary("r", "p", "n", "SUCCESS")))

        assert started - declared == set(), f"audit writer emits unknown columns: {started - declared}"
        assert declared - started == set(), f"audit table has columns nobody writes: {declared - started}"
        assert started == final, "the STARTED and final rows must have identical keys"

    def test_quarantine_writer_columns_match_the_table(self):
        declared = set(ddl_columns(FRAMEWORK / "ddl" / "runtime" / "01_create_quarantine_records.sql"))
        source = (FRAMEWORK / "src" / "idee_dbx" / "runtime" / "target_writers.py").read_text()
        emitted = set(re.findall(r'\.alias\("(\w+)"\)', source))
        assert emitted == declared, f"quarantine mismatch: writer={sorted(emitted)} ddl={sorted(declared)}"


# =============================================================================
# Application DDL must match what the engine actually writes
# =============================================================================
class TestAppDDLMatchesEngine:
    """
    The app tables must declare the framework's audit columns, exactly.

    This broke once: the DDL declared `_processed_at`, which is not a framework
    column at all, and omitted three that are. With overwriteSchema the write
    still succeeded, so nothing failed — the DDL was simply a lie about what
    the table would contain.
    """

    @pytest.mark.parametrize(
        "ddl_file", ["01_create_bronze_customer.sql", "02_create_silver_customer.sql"]
    )
    def test_app_ddl_declares_exactly_the_framework_audit_columns(self, ddl_file):
        columns = ddl_columns(APP / "ddl" / ddl_file)
        audit = [c for c in columns if c.startswith("_")]
        assert sorted(audit) == sorted(ETL_AUDIT_COLUMNS), (
            f"{ddl_file} audit columns {sorted(audit)} != framework {sorted(ETL_AUDIT_COLUMNS)}"
        )

    def test_bronze_ddl_matches_the_source_csv_header(self):
        """star mode passes source names through, so the DDL must use them."""
        header = (APP / "data" / "customer_sample.csv").read_text().splitlines()[0].split(",")
        columns = [c for c in ddl_columns(APP / "ddl" / "01_create_bronze_customer.sql")
                   if not c.startswith("_")]
        assert columns == header, f"bronze DDL {columns} != CSV header {header}"

    def test_silver_ddl_matches_the_explicit_config(self):
        """explicit mode names the target columns, so the DDL must agree."""
        config = yaml.safe_load((APP / "config" / "customers_bronze_to_silver_config.yaml").read_text())
        expected = [c["target_column"] for c in config["columns"]]
        columns = [c for c in ddl_columns(APP / "ddl" / "02_create_silver_customer.sql")
                   if not c.startswith("_")]
        assert columns == expected, f"silver DDL {columns} != config {expected}"


# =============================================================================
# Every referenced file has to exist
# =============================================================================
class TestFileReferences:
    """
    Broken paths were the single most common defect in this project's history:
    a config gets renamed and a notebook dropdown does not follow.
    """

    def test_notebook_config_references_resolve(self):
        configs = {p.name for p in (APP / "config").glob("*.yaml")}
        missing = []
        for notebook in list((APP / "notebooks").glob("*.py")) + list((FRAMEWORK / "notebooks").glob("*.py")):
            for ref in re.findall(r'["\']([\w-]+_config\.yaml)["\']', notebook.read_text()):
                if ref not in configs:
                    missing.append(f"{notebook.name} -> {ref}")
        assert not missing, f"notebooks reference configs that do not exist: {missing}"

    def test_notebook_mode_configs_point_at_a_real_notebook(self):
        notebooks = {p.stem for p in (APP / "notebooks").glob("*.py")}
        for path in (APP / "config").glob("*.yaml"):
            config = yaml.safe_load(path.read_text())
            if config["dataset"].get("column_mode") != "notebook":
                continue
            name = config["dataset"].get("notebook_name")
            assert name in notebooks, f"{path.name} points at notebook '{name}', which is not in notebooks/"

    def test_every_config_target_is_reachable(self):
        """A target either has DDL, or a mode that creates the table on write."""
        ddl = " ".join(p.read_text() for p in (APP / "ddl").glob("*.sql"))
        for path in (APP / "config").glob("*.yaml"):
            config = yaml.safe_load(path.read_text())
            table = config["target"]["target_table"].split(".")[-1]
            mode = config["dataset"]["column_mode"]
            assert table in ddl or mode in ("star", "notebook"), (
                f"{path.name}: target {table} has no DDL and mode '{mode}' will not create it"
            )


# =============================================================================
# Naming conventions we wrote down for ourselves
# =============================================================================
class TestNamingConventions:
    def test_no_yml_extensions(self):
        """The standard says .yaml. Mixing the two is how loaders lose files."""
        offenders = [p.name for p in PROJECT_ROOT.rglob("*.yml")]
        assert not offenders, f"use .yaml, not .yml: {offenders}"

    def test_no_spaces_or_parens_in_filenames(self):
        offenders = [
            str(p.relative_to(PROJECT_ROOT))
            for p in PROJECT_ROOT.rglob("*")
            if p.is_file() and "__pycache__" not in str(p) and re.search(r"[ ()*]", p.name)
        ]
        assert not offenders, f"filenames with spaces/parens/asterisks: {offenders}"

    def test_sql_files_are_numbered_and_snake_case(self):
        for folder in [FRAMEWORK / "ddl" / "metadata", FRAMEWORK / "ddl" / "runtime", APP / "ddl"]:
            for path in folder.glob("*.sql"):
                assert re.match(r"^\d{2}_[a-z0-9_]+\.sql$", path.name), f"bad SQL name: {path.name}"

    def test_folders_are_lowercase(self):
        offenders = [
            str(d.relative_to(PROJECT_ROOT))
            for d in PROJECT_ROOT.rglob("*")
            if d.is_dir() and "__pycache__" not in str(d) and d.name != d.name.lower()
        ]
        assert not offenders, f"non-lowercase folders: {offenders}"


# =============================================================================
# The DQ engine choice has to survive the round trip
# =============================================================================
class TestEngineChoiceSurvives:
    """
    This broke once: quality.engine was never persisted, so the runtime always
    ran the inline engine. A config asking for `native` silently ran with zero
    rules — skipping data quality entirely instead of failing.
    """

    @pytest.mark.parametrize("engine", ["inline", "native", "great_expectations"])
    def test_engine_choice_reaches_the_runtime(self, star_config, engine):
        from idee_dbx.config_parser import parse_config
        from idee_dbx.runtime import resolve_from_plan
        from idee_dbx.runtime.executor import _quality_engine

        star_config["quality"]["engine"] = engine
        star_config["quality"]["rules_path"] = "dq_rules/x.yaml"
        star_config["quality"]["suite_name"] = "x_suite"
        ctx = resolve_from_plan(parse_config(star_config, "/tmp/x.yaml"), "cat", "meta")
        assert _quality_engine(ctx) == engine

    def test_dq_aliases_survive_the_round_trip(self, star_config):
        from idee_dbx.config_parser import parse_alias_string, parse_config

        plan = parse_config(star_config, "/tmp/x.yaml")
        stored = plan.actions_for("dataset_config")[0].values["dq_aliases"]
        assert parse_alias_string(stored) == {
            k: list(v) for k, v in star_config["quality"]["aliases"].items()
        }
