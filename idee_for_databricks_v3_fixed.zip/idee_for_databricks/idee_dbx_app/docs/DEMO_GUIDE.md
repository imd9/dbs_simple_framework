# Demo Guide — Data Engineer (Application User)

**Your role:** you are onboarding a dataset. You fill out one YAML file and run
it. You do not write framework code, and you do not modify anything inside
`idee_dbx_framework/`.

**What you test:** that *your* config is correct and produces the metadata you
expect. This is an integration test, and it doubles as the demo.

> If you built the framework and need to run unit tests, you want
> `idee_dbx_framework/docs/TESTING_GUIDE.md` instead.

---

## What you own, and what you don't

| | Yours | Framework's |
|---|---|---|
| Blank template | copy it | owns it |
| **Your filled config** | **yours** | — |
| Validator / parser / loader | call them | owns them |
| Metadata DDL (`idee_metaschema`) | — | owns it |
| **Application DDL (`idee_app`)** | **yours** | — |
| **Sample data** | **yours** | — |

If you find yourself wanting to edit something in `idee_dbx_framework/`, stop.
Either you need a framework change (raise it with the framework team) or you are
solving it in the wrong place.

**There are no unit tests on your side.** That is intentional — PyTest covers
the framework code. Your side is proven by running the real flow, which is what
this guide walks through.

---

## Set your paths once

Every cell below assumes this block. Replace the email with yours.

```python
PROJECT_ROOT     = "/Workspace/Users/<your.email>@its.jnj.com/idee_for_databricks"
FRAMEWORK        = f"{PROJECT_ROOT}/idee_dbx_framework"
APP              = f"{PROJECT_ROOT}/idee_dbx_app"

CATALOG          = "medtech_md_scion_dev"
METADATA_SCHEMA  = "idee_metaschema"    # framework's tables
APP_SCHEMA       = "idee_app"           # your tables

CONFIG_PATH      = f"{APP}/config/customers_landing_to_bronze_config.yaml"
```

---

## Phase 1 — Make the framework importable

```python
%pip install pyyaml
```

```python
dbutils.library.restartPython()
```

Re-run the paths cell after the restart — it clears your variables.

```python
import sys
if f"{FRAMEWORK}/src" not in sys.path:
    sys.path.insert(0, f"{FRAMEWORK}/src")

import idee_dbx
print(f"Framework version: {idee_dbx.__version__}")
```

**Expect:** `Framework version: 0.1.0`.

If the import fails, your `FRAMEWORK` path is wrong. Check the spelling of the
folder and your workspace user directory.

---

## Phase 2 — Start from the template, never from another config

Two configs already exist for the demo, so
for this walkthrough you can use it as-is. When you add your **own** pipeline
later, copy the template:

```python
import shutil
shutil.copy(
    f"{FRAMEWORK}/templates/idee_pipeline_config_template.yaml",
    f"{APP}/config/<object>_<load_type>_config.yaml",
)
```

**Copy the template, not an existing filled config.** Copying a filled config
carries stale values — a leftover `object_name` or `target_table` pointing at
someone else's dataset is easy to miss and lands your data in the wrong table.

Naming: `<application>_<object>_<source_layer>_to_<target_layer>_config.yaml`,
e.g. `customers_bronze_to_silver_config.yaml`. Name the file after the pipeline.
A filled config is **not** a template and must never have `template` in its name.

---

## Phase 3 — Fill it out

Open the file. Every field is commented with its meaning, allowed values, and
whether it is required. The four sections:

| Section | Describes | Becomes |
|---|---|---|
| `source:` | where data comes from, how to connect | 1 row in `source_config` |
| `dataset:` | what to process and how | 1 row in `dataset_config` |
| `columns:` | what each column looks like after cleaning | 1 row per column |
| `quality:` | how the data is validated | rules (inline engine only) |

### Three rules that will save you time

**Do not rename keys.** Each YAML key is named exactly after its target table
column. The parser maps key to column with no translation. Rename one and the
parser cannot find it.

**Never put a credential in `connection_ref`.** It takes a Unity Catalog
connection name or a secret scope reference. The validator warns if it spots
something resembling a password, but do not rely on that catching everything.

**IDs are permanent.** `source_id` and `object_id` are never reused. Audit
history keys off them, so recycling an ID silently reassigns another dataset's
run history to yours.

### Required fields depend on your load type

| `load_type` | Also required |
|---|---|
| `FULL` | nothing extra |
| `INCREMENTAL` | `incremental_column` |
| `CDC` | `primary_key` |
| `SNAPSHOT` | `primary_key` |

Start with `FULL`. It is truncate-and-load — the simplest pattern, and the only
one with runtime behaviour in v0.1.

### Choosing a DQ engine

| `engine` | Rules live in | You set |
|---|---|---|
| `inline` | this file | `rules` |
| `native` | a YAML rule pack in a `dq_rules/` folder | `rules_path` |
| `great_expectations` | a GX suite (JSON) in Databricks | `suite_name` |

Use `inline` to start — it keeps everything in one file with no external
dependency. Note that in v0.1 all three validate and parse correctly, but
**nothing enforces the rules against data yet**; the ingestion engine comes
next.

---

## Phase 4 — Validate

This is your first real checkpoint. Nothing else should happen until it passes.

```python
from idee_dbx.config_validator import validate_config_file

result = validate_config_file(CONFIG_PATH, schema_dir=f"{FRAMEWORK}/schema")
print(result.report())
```

**Expect:**

```
Config      : .../customers_landing_to_bronze_config.yaml
Version     : 0.1
Schema      : v0.1
Result      : PASSED
```

The validator reports **every** problem at once rather than stopping at the
first, so one pass tells you everything to fix.

### Warnings are not failures

You may see advisory warnings — an inactive dataset, an empty `silver_table`,
a suspicious `connection_ref`. These do not block. Read them; they usually mean
you left something out by accident.

### See it catch a mistake

Worth doing once so you trust it and recognise the output later:

```python
import copy, yaml
from idee_dbx.config_validator import validate_config

cfg = yaml.safe_load(open(CONFIG_PATH))
cfg["dataset"]["load_type"] = "INCREMENTAL"   # but no incremental_column set
cfg["dataset"]["incremental_column"] = ""

print(validate_config(cfg, "broken-on-purpose", f"{FRAMEWORK}/schema").report())
```

**Expect:** `FAILED`, naming `dataset.incremental_column` and explaining that
INCREMENTAL requires a watermark column.

---

## Phase 5 — Create your application tables

Your DDL goes in the **application** schema (`idee_app`) — never the metadata
schema. Placeholders are `${catalog}` and `${app_schema}`:

```python
import glob, os

for path in sorted(glob.glob(f"{APP}/ddl/*.sql")):
    sql = open(path).read()
    sql = sql.replace("${catalog}", CATALOG).replace("${app_schema}", APP_SCHEMA)
    print(f"Running {os.path.basename(path)} ...", end=" ")
    spark.sql(sql)
    print("OK")
```

Creates three tables:

| Table | Holds |
|---|---|
| `bronze_customer` | raw ingest, source column names, everything STRING |
| `silver_customer` | renamed, cast, trimmed, quality-checked |
| `quarantine_customer` | rows that failed a rule with action `quarantine` |

Bronze keeps source names and STRING types deliberately — casting and renaming
happen on the way to Silver, driven by `column_config`.

Confirm:

```python
display(spark.sql(f"SHOW TABLES IN {CATALOG}.{APP_SCHEMA}"))
```

---

## Phase 6 — Upload the sample data

Upload `idee_dbx_app/data/customer_sample.csv` to your landing volume — the
path in your config's `base_path`, e.g.
`/Volumes/idee_app/landing/customer/incoming/`.

```python
display(spark.read.option("header", True).csv(f"{APP}/data/customer_sample.csv"))
```

### The sample data is broken on purpose

Five rows containing three planted defects:

| Row | Defect | Rule that catches it | Action |
|---|---|---|---|
| 1004 | `not-an-email` | Email address format check | `warn` |
| 1005 | `USA` — three chars, not two | Country code must be two characters | `quarantine` |
| 1002 | leading/trailing spaces in the name | `trim_indicator: true` | cleaned |

A demo where everything passes proves nothing. This one lets you show warn,
quarantine, and trim actually doing something — once the ingestion engine
exists to run them.

---

## Phase 7 — Dry run

Open `idee_dbx_app/notebooks/run_sample_pipeline.py`, set the widgets, leave
**Dry run = true**, and run all.

**Expect:**

```
STEP 1 — CONFIG VALIDATION      Result: PASSED
STEP 2 — CONFIG PARSING

Planned metadata actions (10 total):
  source_config          1 row(s)
  dataset_config         1 row(s)
  column_config          5 row(s)
  quality_rule_config    3 row(s)

Mode : DRY RUN (nothing written)
```

The counts should match your config: five `columns:` entries → 5 column rows;
three `rules:` entries → 3 rule rows. If they don't, your config is not saying
what you think it is.

**Read the generated MERGE statements** before continuing. This is the last
checkpoint before anything is written.

---

## Phase 8 — Load

Set **Dry run = false** and re-run.

**Expect:** `Mode: LIVE`, `Result: SUCCESS`.

Confirm your dataset landed:

```python
display(spark.sql(f"""
    SELECT p.pipeline_name, d.object_name, d.column_mode, t.target_table,
           COUNT(c.source_column) AS mapped_columns
    FROM {CATALOG}.{METADATA_SCHEMA}.pipeline_config p
    JOIN {CATALOG}.{METADATA_SCHEMA}.dataset_config  d ON d.pipeline_id = p.pipeline_id
    JOIN {CATALOG}.{METADATA_SCHEMA}.target_config   t ON t.target_id   = d.target_id
    LEFT JOIN {CATALOG}.{METADATA_SCHEMA}.column_config c ON c.dataset_id = d.dataset_id
    GROUP BY 1,2,3,4
"""))
```

**Expect:** one row, `column_count = 5`.

And your quality rules:

```python
display(spark.sql(f"""
    SELECT r.rule_name, r.action, r.severity, r.active
    FROM {CATALOG}.{METADATA_SCHEMA}.quality_rule_config r
    JOIN {CATALOG}.{METADATA_SCHEMA}.pipeline_config p ON p.pipeline_id = r.pipeline_id
    WHERE p.pipeline_name = 'scion_customer_landing_to_bronze'
    ORDER BY r.rule_name
"""))
```

**Expect:** one row per rule in your `rules:` block.

---

## Phase 9 — Run it twice

Run the live load again, unchanged, then re-check the counts.

**Expect: unchanged — 1 object, 5 columns, 3 rules.** Not doubled.

The framework uses `MERGE`, not `INSERT`, and derives deterministic rule IDs. So
re-running your config after a small edit updates the existing metadata instead
of duplicating it. Practically: you can safely re-run after fixing a typo,
which you will do often.

---

## Phase 10 — What to show in the demo

Your angle is the *user's* experience. Ten minutes:

1. **"I never touch framework code."** Show the two folders and the split.
2. **The template** — blank, framework-owned, fully commented.
3. **Your filled config** — the copy, populated for one small pipeline.
4. **Validate** — passes. Then break something live and show the error naming
   the exact field. This is what a user actually feels day to day.
5. **Dry run** — here is precisely what would be written, before anything is.
6. **Load** — your dataset appears in the metadata tables.
7. **Run twice** — nothing duplicates.

### The one-sentence pitch

> To onboard a dataset I fill out one YAML file. No new pipeline, no new
> notebook, no code change.

### Be straight about scope

> This registers metadata about my pipeline. The ingestion engine that moves
> Bronze and Silver data is the next increment — this proves the config path
> works first.

Say it yourself rather than letting someone discover it. Naming the boundary is
what makes the rest credible.

---

## Adding your next pipeline

1. Copy the **template** (not an existing config) into `config/`.
2. Name it `<object>_<load_type>_config.yaml`.
3. Fill it in. New `source_id` and `object_id` — never reuse.
4. Add Bronze/Silver DDL to `ddl/`.
5. Validate before anything else.
6. Dry run, then load.

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `ModuleNotFoundError: idee_dbx` | `src/` not on the path | Re-run the `sys.path.insert` cell; check `FRAMEWORK` |
| Variables vanished mid-notebook | `restartPython()` cleared them | Re-run the paths cell |
| `required but missing` | A field is blank or absent | The error names the exact field |
| `still contains template placeholder text` | You did not fill everything in | Replace every `enter ... here` and `catalog.schema.table` |
| `must be a three-part name` | Table name is not `catalog.schema.table` | Use all three parts |
| `must match source.source_id` | `dataset.source_id` differs from `source.source_id` | Make them identical |
| Column count wrong in the plan | Config does not say what you think | Count your `columns:` entries |
| `TABLE_OR_VIEW_NOT_FOUND` on metadata tables | Framework DDL not run yet | Ask the framework engineer to run Phase 6 of their guide |
| Rows doubled after a re-run | Should not happen — MERGE prevents it | Report it; that is a framework bug |
