-- =============================================================================
-- 03_create_target_config.sql
-- =============================================================================
-- Where a pipeline writes TO.
--
-- OWNER      : Framework
-- PARAMETERS : ${catalog}, ${metadata_schema}
--
-- Deliberately layer-agnostic. There is no bronze_table or silver_table
-- column: a target is just a target, and which layer it represents lives in
-- the table name and the pipeline name.
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${metadata_schema}.target_config (
    target_id         STRING  NOT NULL COMMENT 'Framework-generated. Hash of type + table/path.',
    pipeline_id       STRING  NOT NULL COMMENT 'FK to pipeline_config.',
    target_name       STRING  NOT NULL COMMENT 'Friendly label.',
    target_type       STRING  NOT NULL COMMENT 'delta_table | s3 | adls | jdbc',
    target_table      STRING           COMMENT 'Three-part name for table targets.',
    target_path       STRING           COMMENT 'Location for file targets.',
    config_file_path  STRING  NOT NULL COMMENT 'Lineage back to the YAML.',
    created_at        TIMESTAMP        COMMENT 'Row insert time.',
    updated_at        TIMESTAMP        COMMENT 'Row last update time.',
    CONSTRAINT pk_target_config PRIMARY KEY (target_id) RELY
)
USING DELTA
COMMENT 'iDEE metadata: targets. Where each pipeline writes to.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'idee.table_role'            = 'metadata',
    'idee.owner'                 = 'framework'
);
