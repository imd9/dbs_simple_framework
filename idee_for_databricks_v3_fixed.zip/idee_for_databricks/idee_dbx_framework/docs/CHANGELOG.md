# Changelog

All notable changes to the iDEE for Databricks framework.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Versioning follows [Semantic Versioning](https://semver.org/).

---

## Versioning policy

Two version numbers exist and they move independently:

| Version | Lives in | Covers |
|---|---|---|
| **Framework version** | `VERSION`, `src/idee_dbx/__init__.py` | The Python code: validator, parser, loader, CLI |
| **Config schema version** | `config_version:` in each config; `schema/pipeline_config_schema_v*.yaml` | The shape of a config file |

A framework release can ship without changing the config schema. When the
config schema *does* change:

- **Backward-compatible** (new optional field) → bump the schema minor version,
  add a new schema file, keep the old one. Existing configs continue to
  validate against the version they declare.
- **Breaking** (field removed, renamed, or newly required) → bump the schema
  major version and publish a migration note here. **Never edit a published
  schema file in place** — configs in the wild are validating against it.

Schema files are additive. `schema/` accumulates versions; it does not replace
them.

---

## [Unreleased] — v3.1 execution engine, Phase 1

Data now moves. The metadata side registers what a pipeline should do; this
increment does it.

### Added
- `runtime/config_resolver.py` — rebuilds a RunContext from the metadata
  tables, or from a ParsePlan with no Spark at all (which is what makes the
  engine testable off-cluster).
- `runtime/source_readers.py` — `cloud_files` and `delta_table`. The second is
  what makes bronze->silver and silver->gold possible.
- `runtime/transformer.py` — `star` and `explicit`. Owns the ETL audit columns,
  so they can never be added twice or forgotten. `notebook` raises a specific
  error rather than silently passing the frame through.
- `runtime/dq_engine.py` — inline rules with alias resolution and action
  routing. All rules evaluate in one pass; the strictest action a row trips
  decides its fate.
- `runtime/target_writers.py` — Delta writer at `FULL`, plus the shared
  quarantine writer.
- `runtime/audit_logger.py` — STARTED row before reading, outcome row after.
- `runtime/executor.py` — orchestrates the four stages, owns the audit trail,
  and looks every component up from a registry.
- `ddl/runtime/01_create_quarantine_records.sql` — one shared quarantine table.
- `dq_aliases` column on `dataset_config`.
- 62 further tests, covering the runtime decision logic. 174 total.

### Fixed
- **DQ aliases were never persisted.** Rule expressions were stored with
  `{alias}` placeholders, but the alias map went nowhere, so the runtime could
  not have resolved them. Now flattened onto `dataset_config`.

### Decided
- **`FULL` means overwrite, not truncate-then-insert.** Delta's overwrite is
  atomic: a concurrent reader sees the old version or the new one, never an
  empty table.
- **One shared quarantine table, not one per dataset.** Per-dataset tables keep
  typed columns but need hand-written DDL on every onboarding, which works
  against onboarding by filling out one file. The rejected row is stored as
  JSON; quarantined rows are for investigation, not analytics.
- **Auto Loader streaming is not used for `FULL`.** Checkpointing which files
  have been seen, combined with an overwrite, would replace the whole target
  using only the newest file. `FULL` does a plain batch read.

### Added — scale-up options left in place
- Every alternative for `source_type`, `target_type`, `load_type`,
  `column_mode`, `ingestion_method` and `quality.engine` is present in the
  template and both shipped configs, commented out and labelled IMPLEMENTED or
  NOT YET. Scaling up is an uncomment, not a rewrite.
- The validator now warns when a config selects something the engine cannot run
  yet. The config stays legal and still loads metadata — but you learn at
  validate time rather than halfway through a run.
- A capability matrix at the top of the template and both configs.

### Not built
`INCREMENTAL`, `CDC`, `SNAPSHOT`; `notebook` execution; `native` and
`great_expectations` DQ engines; `jdbc`, `kafka`, `api` sources; `s3`, `adls`
targets. Each raises a specific error naming what is missing.

## [Unreleased] — v3 metadata model

Consolidates the V2 config redesign into the framework package and fills the
gaps it left. Config schema stays at v0.1 (pre-release, edited in place).

### Added
- `pipeline_config` and `target_config` tables — pipeline identity and an
  explicit target, replacing the layer-named `bronze_table`/`silver_table`
  fields.
- `config_parse_audit` table — the second of two audit tables. Records which
  YAML was parsed, when, and whether it worked. Different grain from
  `pipeline_audit`, which records data movement.
- `column_mode: notebook` — reference an external notebook for complex SQL.
  The reference is recorded; the content stays in Bitbucket and the framework
  does not execute it yet.
- `src/idee_dbx/runtime/contracts.py` — the interface every execution component
  implements, plus component registries. No logic; fixed before components are
  built so parallel work fits together.
- ETL audit column handling: `_ingested_at`, `_run_id`, `_pipeline_id`,
  `_source_file`, with `exclude_etl_columns` to strip them on read.
- `delta_table` as a **source** type, so bronze→silver and silver→gold work.
- Third valid fixture and tests covering all three column modes.
- `docs/DESIGN_DECISIONS.md`.

### Changed
- `object_config` renamed `dataset_config`.
- `allow_select_star` / `allow_select_columns` / `allow_custom_notebook`
  replaced by a single `column_mode` enum — three booleans encoded eight states
  of which five were contradictions.
- `config_template_version` renamed back to `config_version`, matching the
  schema filename, tests and docs. The validator gives a specific error naming
  the old key rather than a generic "missing".
- `primary_key` is a list, supporting composite keys.
- `generate_id` uses SHA-256 rather than MD5 — the value is not a security
  control, but SonarQube flags MD5 on sight.
- Application notebook slimmed from 830 lines to 174. Validation, parsing and
  loading moved into the framework package where they belong.
- Config filenames normalised: spaces, parentheses and an asterisk removed.
- Test suite rebuilt for the V2 shape: 112 cases.

### Fixed
- V2 configs did not validate at all — the schema and validator still described
  the V1 shape while the YAML had moved on.
- `created_at` is no longer overwritten by the UPDATE branch of a MERGE.

## [Unreleased]

### Planned
- Bronze ingestion engine (Auto Loader) driven by `object_config`
- Silver transformation engine driven by `column_config`
- Runtime enforcement of the `native` and `great_expectations` DQ engines
- `pipeline_audit` writes at run time
- Databricks Asset Bundle deployment (deferred until repos and AD groups exist)
- Append and incremental load patterns (deferred until full refresh is proven)

---

## [0.1.0] — 2026-07-28

First working skeleton. Proves the `config → validate → parse → output` path
end to end for a single small full-refresh pipeline.

### Added

**Framework**
- `config_validator` — schema-driven validation. Rules live in
  `schema/pipeline_config_schema_v0_1.yaml`, not in Python, so new config
  formats mean a new schema file rather than a code change.
- `config_parser` — translates a valid config into metadata actions and renders
  them as idempotent `MERGE` statements.
- `metadata_loader` — applies a parse plan to Unity Catalog. The only module
  that touches Spark; supports `dry_run`.
- `main` — CLI with `validate`, `parse`, and `load` subcommands.
- Config schema v0.1 covering required fields, types, enums, conditional
  requirements, cross-field integrity, and unfilled-placeholder detection.
- Blank config template with the four-section model
  (`source` / `dataset` / `columns` / `quality`).
- Metadata DDL for five tables: `source_config`, `object_config`,
  `column_config`, `quality_rule_config`, `pipeline_audit`, plus a preflight
  script that verifies the catalog and schemas exist. The framework creates
  tables, never schemas — schemas are platform-provisioned.
- PyTest suite covering the validator and parser, with valid and invalid
  fixtures.
- `docs/NAMING_CONVENTIONS.md`.

**Application**
- Filled demo config: `customer_full_refresh_config.yaml` — one source, one
  target, five columns, full refresh.
- Bronze, Silver, and quarantine DDL for the demo.
- Sample CSV containing deliberate data quality defects, so the rules visibly
  fire during a demo.
- Demo notebook calling the framework.

### Design decisions
- **Validate and parse are separate stages.** Parsing produces a plan without
  executing it, which is what makes a meaningful dry run possible.
- **`MERGE`, not `INSERT`.** Re-running the same config must not duplicate rows.
- **Deterministic `rule_id`s** (`<object_id>__<slug>`) rather than UUIDs, for
  the same reason.
- **Inactive columns are recorded with `active = false`, not dropped.** Deleting
  them would lose the fact that exclusion was deliberate.
- **Nothing hardcoded.** Catalog and schema are parameters throughout.
- **The framework never creates schemas.** It verifies they exist and fails
  loudly if not. Creating a mistyped schema silently is worse than stopping.

### Known gaps
- No ingestion engine yet — the framework loads *metadata*, not data. Bronze and
  Silver movement is not implemented.
- `native` and `great_expectations` DQ engines validate and parse correctly, but
  no runtime enforces them; only `inline` produces metadata rows.
- Only `FULL` load type is exercised end to end. `INCREMENTAL`, `CDC`, and
  `SNAPSHOT` validate but have no runtime behaviour.
