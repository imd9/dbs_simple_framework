# Databricks notebook source
# MAGIC %md
# MAGIC # iDEE Framework — End to End Validation
# MAGIC
# MAGIC Proves the framework itself is healthy, before any dataset exists.
# MAGIC Run by a **framework engineer**, once per environment.
# MAGIC
# MAGIC What it does, in order: confirm the layout, install dependencies, run
# MAGIC the unit tests, prove the validator rejects bad input, verify the
# MAGIC schemas exist, create the metadata tables, dry run, live load, then
# MAGIC re-run to prove idempotency.
# MAGIC
# MAGIC **Scope.** This registers *metadata*. It does not move data — the
# MAGIC execution engine is the next increment. Its interface is defined in
# MAGIC `src/idee_dbx/runtime/contracts.py`.

# COMMAND ----------

# DBTITLE 1,Setup — paths (re-run after any Python restart)
PROJECT_ROOT    = "/Workspace/Users/<your.email>@its.jnj.com/idee_for_databricks"
FRAMEWORK       = f"{PROJECT_ROOT}/idee_dbx_framework"
APP             = f"{PROJECT_ROOT}/idee_dbx_app"

CATALOG         = "medtech_md_scion_dev"
METADATA_SCHEMA = "idee_metaschema"
APP_SCHEMA      = "idee_app"

DEMO_CONFIG     = f"{APP}/config/customers_landing_to_bronze_config.yaml"
CHAIN_CONFIG    = f"{APP}/config/customers_bronze_to_silver_config.yaml"

print(f"Framework : {FRAMEWORK}")
print(f"App       : {APP}")
print(f"Catalog   : {CATALOG}")

# COMMAND ----------

# DBTITLE 1,Phase 1 — Confirm folder layout
import os

for label, path in [("Framework", FRAMEWORK), ("App", APP)]:
    print(f"{label:10} {'FOUND' if os.path.isdir(path) else 'MISSING'}  {path}")

print("\nFramework contents:")
for entry in sorted(os.listdir(FRAMEWORK)):
    print("  ", entry)

# COMMAND ----------

# DBTITLE 1,Phase 2 — Install dependencies
# MAGIC %pip install pytest pyyaml

# COMMAND ----------

# DBTITLE 1,Phase 2b — Restart Python (required after pip install)
dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Phase 2c — Re-set paths after the restart
# restartPython() clears every variable, so this block must run again.
PROJECT_ROOT    = "/Workspace/Users/<your.email>@its.jnj.com/idee_for_databricks"
FRAMEWORK       = f"{PROJECT_ROOT}/idee_dbx_framework"
APP             = f"{PROJECT_ROOT}/idee_dbx_app"

CATALOG         = "medtech_md_scion_dev"
METADATA_SCHEMA = "idee_metaschema"
APP_SCHEMA      = "idee_app"

DEMO_CONFIG     = f"{APP}/config/customers_landing_to_bronze_config.yaml"
CHAIN_CONFIG    = f"{APP}/config/customers_bronze_to_silver_config.yaml"
SCHEMA_DIR      = f"{FRAMEWORK}/schema"

import sys
sys.dont_write_bytecode = True
if f"{FRAMEWORK}/src" not in sys.path:
    sys.path.insert(0, f"{FRAMEWORK}/src")

print("paths re-set")

# COMMAND ----------

# DBTITLE 1,Phase 3 — Run the unit tests
import os
import pytest

os.chdir(FRAMEWORK)

# -p no:cacheprovider: pytest tries to write .pytest_cache next to the tests,
# and workspace storage often refuses, which looks like a test failure but is
# not. -c points at the ini file, which lives under docs/.
exit_code = pytest.main([
    "tests/",
    "-v",
    "-c", "docs/pytest.ini",
    "-p", "no:cacheprovider",
    "--tb=short",
])

print(f"\nPyTest exit code: {exit_code}   (0 = all passed)")

# COMMAND ----------

# MAGIC %md
# MAGIC ### What the suite covers
# MAGIC
# MAGIC Happy path across all three column modes (`star`, `explicit`,
# MAGIC `notebook`); version handling; required fields; types; enums;
# MAGIC list-valued fields such as composite primary keys; mutually exclusive
# MAGIC fields; conditional requirements; cross-field integrity; deterministic
# MAGIC IDs; SQL rendering; and idempotency.

# COMMAND ----------

# DBTITLE 1,Phase 4 — Validate both shipped configs
from idee_dbx.config_validator import validate_config_file

for path in (DEMO_CONFIG, CHAIN_CONFIG):
    print("=" * 70)
    print(validate_config_file(path, schema_dir=SCHEMA_DIR).report())

# COMMAND ----------

# DBTITLE 1,Phase 5 — Prove the validator rejects bad input
import copy

import yaml

from idee_dbx.config_validator import validate_config

good = yaml.safe_load(open(DEMO_CONFIG))


def show(label, mutate):
    cfg = copy.deepcopy(good)
    mutate(cfg)
    result = validate_config(cfg, config_path=label, schema_dir=SCHEMA_DIR)
    print(f"\n--- {label} ---")
    print(result.report())


show("Illegal load_type",
     lambda c: c["dataset"].__setitem__("load_type", "UPSERT"))
show("Illegal column_mode",
     lambda c: c["dataset"].__setitem__("column_mode", "everything"))
show("INCREMENTAL with no watermark",
     lambda c: c["dataset"].update({"load_type": "INCREMENTAL", "incremental_column": ""}))
show("Two-part table name",
     lambda c: c["target"].__setitem__("target_table", "idee_app.bronze_customer"))
show("primary_key given as a string, not a list",
     lambda c: c["dataset"].__setitem__("primary_key", "CUSTOMER_ID"))
show("Both target_table and target_path supplied",
     lambda c: c["target"].__setitem__("target_path", "s3://bucket/x"))

# COMMAND ----------

# DBTITLE 1,Phase 5b — The blank template must be rejected
# Every placeholder in the template is syntactically legal, so without an
# explicit placeholder check an unfilled template would validate cleanly and
# someone could deploy it as-is.
print(validate_config_file(f"{FRAMEWORK}/templates/idee_pipeline_config_template.yaml",
                           schema_dir=SCHEMA_DIR).report())

# COMMAND ----------

# DBTITLE 1,Phase 6 — Preflight: confirm the schemas exist
# The framework CREATES NOTHING here. idee_metaschema and idee_app are
# provisioned by the platform team. A missing row below means the schema does
# not exist under this catalog — stop and check the name.
sql = open(f"{FRAMEWORK}/ddl/metadata/00_verify_prerequisites.sql").read()
for key, value in {
    "catalog": CATALOG,
    "metadata_schema": METADATA_SCHEMA,
    "app_schema": APP_SCHEMA,
}.items():
    sql = sql.replace("${" + key + "}", value)

display(spark.sql(sql))  # noqa: F821

# COMMAND ----------

# DBTITLE 1,Phase 6b — Create the metadata tables
import glob

# 00 and 99 return result sets rather than creating anything, so they are
# skipped here and run separately.
for path in sorted(glob.glob(f"{FRAMEWORK}/ddl/metadata/*.sql")):
    name = os.path.basename(path)
    if name.startswith(("00_", "99_")):
        continue
    statement = open(path).read()
    statement = statement.replace("${catalog}", CATALOG).replace("${metadata_schema}", METADATA_SCHEMA)
    print(f"Running {name} ...", end=" ")
    spark.sql(statement)  # noqa: F821
    print("OK")

# COMMAND ----------

# DBTITLE 1,Phase 6b2 — Create the shared quarantine table (application schema)
# One shared quarantine table for every dataset. A per-dataset table would need
# hand-written DDL on every onboarding, which works against "fill out one file".
for path in sorted(glob.glob(f"{FRAMEWORK}/ddl/runtime/*.sql")):
    statement = open(path).read()
    statement = statement.replace("${catalog}", CATALOG).replace("${app_schema}", APP_SCHEMA)
    print(f"Running {os.path.basename(path)} ...", end=" ")
    spark.sql(statement)  # noqa: F821
    print("OK")

# COMMAND ----------

# DBTITLE 1,Phase 6c — Verify the metadata tables (expect 8 tables, 0 rows each)
sql = open(f"{FRAMEWORK}/ddl/metadata/99_verify_metadata_tables.sql").read()
sql = sql.replace("${catalog}", CATALOG).replace("${metadata_schema}", METADATA_SCHEMA)
display(spark.sql(sql))  # noqa: F821

# COMMAND ----------

# DBTITLE 1,Phase 7 — Dry run (validate -> parse -> preview SQL, writes nothing)
from idee_dbx.config_parser import parse_config
from idee_dbx.metadata_loader import load_plan

validation = validate_config_file(DEMO_CONFIG, schema_dir=SCHEMA_DIR)
assert validation.is_valid, validation.errors

plan = parse_config(validation.config, config_path=DEMO_CONFIG)
print(plan.summary())

print("\n" + "=" * 70 + "\nGENERATED SQL\n" + "=" * 70)
for statement in plan.to_merge_statements(CATALOG, METADATA_SCHEMA):
    print(statement)
    print()

print(load_plan(plan, CATALOG, METADATA_SCHEMA, dry_run=True, spark=spark).report())  # noqa: F821

# COMMAND ----------

# DBTITLE 1,Phase 8 — Live load, both pipelines in the chain
for path in (DEMO_CONFIG, CHAIN_CONFIG):
    validation = validate_config_file(path, schema_dir=SCHEMA_DIR)
    assert validation.is_valid, validation.errors
    plan = parse_config(validation.config, config_path=path)
    result = load_plan(plan, CATALOG, METADATA_SCHEMA, dry_run=False, spark=spark)  # noqa: F821
    print(f"{plan.pipeline_name:40} {result.statements_run} statement(s)  "
          f"{'SUCCESS' if result.succeeded else 'FAILED'}")

# COMMAND ----------

# DBTITLE 1,Phase 8b — Confirm what landed
display(spark.sql(f"""   # noqa: F821
    SELECT p.pipeline_name,
           s.source_type,
           COALESCE(s.source_table, s.root_path) AS reads_from,
           t.target_table                        AS writes_to,
           d.column_mode,
           d.load_type,
           COUNT(c.source_column)                AS mapped_columns
    FROM {CATALOG}.{METADATA_SCHEMA}.pipeline_config p
    JOIN {CATALOG}.{METADATA_SCHEMA}.dataset_config  d ON d.pipeline_id = p.pipeline_id
    JOIN {CATALOG}.{METADATA_SCHEMA}.source_config   s ON s.source_id   = d.source_id
    JOIN {CATALOG}.{METADATA_SCHEMA}.target_config   t ON t.target_id   = d.target_id
    LEFT JOIN {CATALOG}.{METADATA_SCHEMA}.column_config c ON c.dataset_id = d.dataset_id
    GROUP BY 1,2,3,4,5,6
    ORDER BY 1
"""))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Read the two rows above carefully
# MAGIC
# MAGIC The chain reads: landing files → `bronze_customer` → `silver_customer`.
# MAGIC The second pipeline's `source_type` is `delta_table` — it reads from the
# MAGIC table the first one wrote.
# MAGIC
# MAGIC **Same framework, same schema, same engine. Only the config differs.**
# MAGIC That is what makes one engine able to run every hop, silver → gold
# MAGIC included.

# COMMAND ----------

# DBTITLE 1,Phase 9 — Idempotency check (re-run; counts must NOT double)
before = {t: spark.table(f"{CATALOG}.{METADATA_SCHEMA}.{t}").count()  # noqa: F821
          for t in ["pipeline_config", "source_config", "target_config",
                    "dataset_config", "column_config", "quality_rule_config"]}

for path in (DEMO_CONFIG, CHAIN_CONFIG):
    validation = validate_config_file(path, schema_dir=SCHEMA_DIR)
    plan = parse_config(validation.config, config_path=path)
    load_plan(plan, CATALOG, METADATA_SCHEMA, dry_run=False, spark=spark)  # noqa: F821

print(f"{'table':<24}{'before':>8}{'after':>8}   result")
ok = True
for table, count_before in before.items():
    count_after = spark.table(f"{CATALOG}.{METADATA_SCHEMA}.{table}").count()  # noqa: F821
    same = count_before == count_after
    ok = ok and same
    print(f"{table:<24}{count_before:>8}{count_after:>8}   {'OK' if same else 'DUPLICATED'}")

print("\nIdempotent." if ok else "\nFAILED: re-running duplicated rows.")

# COMMAND ----------

# DBTITLE 1,Phase 10 — Run the pipeline (dry run: reads and transforms, writes nothing)
from idee_dbx.runtime import execute_pipeline

summary = execute_pipeline(
    spark,  # noqa: F821
    catalog=CATALOG,
    pipeline_name="scion_customer_landing_to_bronze",
    metadata_schema=METADATA_SCHEMA,
    app_schema=APP_SCHEMA,
    dry_run=True,
)
print(summary.report())
print("\nNotes:")
for note in summary.notes:
    print("  -", note)

# COMMAND ----------

# DBTITLE 1,Phase 11 — Run it for real (landing -> bronze)
summary = execute_pipeline(
    spark,  # noqa: F821
    catalog=CATALOG,
    pipeline_name="scion_customer_landing_to_bronze",
    metadata_schema=METADATA_SCHEMA,
    app_schema=APP_SCHEMA,
    dry_run=False,
)
print(summary.report())

if not summary.succeeded:
    raise RuntimeError(summary.error_message)

display(spark.table(f"{CATALOG}.{APP_SCHEMA}.bronze_customer"))  # noqa: F821

# COMMAND ----------

# MAGIC %md
# MAGIC ### Look for the ETL audit columns
# MAGIC
# MAGIC `_ingested_at`, `_run_id`, `_pipeline_id` and `_source_file` were added
# MAGIC by the framework. `_run_id` matches the run in `pipeline_audit`, so any
# MAGIC row can be traced to the execution that produced it.

# COMMAND ----------

# DBTITLE 1,Phase 12 — Run the second hop (bronze -> silver)
# Same engine, same code path. Only the config differs: this one's source_type
# is delta_table and its column_mode is explicit.
summary = execute_pipeline(
    spark,  # noqa: F821
    catalog=CATALOG,
    pipeline_name="scion_customer_bronze_to_silver",
    metadata_schema=METADATA_SCHEMA,
    app_schema=APP_SCHEMA,
    dry_run=False,
)
print(summary.report())

display(spark.table(f"{CATALOG}.{APP_SCHEMA}.silver_customer"))  # noqa: F821

# COMMAND ----------

# DBTITLE 1,Phase 13 — Inspect quarantine and the run audit
print("Quarantined rows:")
display(spark.sql(f"""   # noqa: F821
    SELECT pipeline_name, failed_rules, record_json, quarantined_at
    FROM {CATALOG}.{APP_SCHEMA}.quarantine_records
    ORDER BY quarantined_at DESC
"""))

print("Run audit:")
display(spark.sql(f"""   # noqa: F821
    SELECT pipeline_name, status, rows_read, rows_written,
           rows_dropped, rows_quarantined, duration_seconds
    FROM {CATALOG}.{METADATA_SCHEMA}.pipeline_audit
    ORDER BY start_time DESC
"""))

# COMMAND ----------

# DBTITLE 1,Phase 14 — Re-run the data load; FULL must not duplicate rows
before = spark.table(f"{CATALOG}.{APP_SCHEMA}.bronze_customer").count()  # noqa: F821

execute_pipeline(
    spark,  # noqa: F821
    catalog=CATALOG,
    pipeline_name="scion_customer_landing_to_bronze",
    metadata_schema=METADATA_SCHEMA,
    app_schema=APP_SCHEMA,
)

after = spark.table(f"{CATALOG}.{APP_SCHEMA}.bronze_customer").count()  # noqa: F821
print(f"bronze_customer  before={before}  after={after}  "
      f"{'OK — FULL overwrite is idempotent' if before == after else 'DUPLICATED'}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## What was proven
# MAGIC
# MAGIC - The framework's own unit tests pass.
# MAGIC - The validator rejects malformed configs with specific, readable errors.
# MAGIC - An unfilled template cannot be deployed.
# MAGIC - Both schemas exist; the framework verified rather than created them.
# MAGIC - The eight metadata tables install cleanly.
# MAGIC - A dry run shows exactly what would be written, and writes nothing.
# MAGIC - Two pipelines forming a real chain load successfully.
# MAGIC - Re-running changes nothing — MERGE plus deterministic IDs.
# MAGIC
# MAGIC - Data moves: landing files reach Bronze, and Bronze reaches Silver.
# MAGIC - The second hop uses the same engine, with `delta_table` as its source.
# MAGIC - Quality rules route rows to warn, drop or quarantine.
# MAGIC - Every run is recorded in `pipeline_audit`.
# MAGIC - Re-running a FULL load does not duplicate rows.
# MAGIC
# MAGIC ## Scope — what is built, and what is not
# MAGIC
# MAGIC | Area | Built in v0.1 | Not yet |
# MAGIC |---|---|---|
# MAGIC | Sources | `cloud_files`, `delta_table` | `jdbc`, `kafka`, `api`, `lakeflow_connect` |
# MAGIC | Column modes | `star`, `explicit` | `notebook` (reference recorded, not run) |
# MAGIC | Load types | `FULL` | `INCREMENTAL`, `CDC`, `SNAPSHOT` |
# MAGIC | DQ engines | `inline` | `native`, `great_expectations` |
# MAGIC | Targets | `delta_table` | `s3`, `adls`, `jdbc` |
# MAGIC
# MAGIC Anything unbuilt raises a specific error naming what is missing, rather
# MAGIC than guessing at semantics.
# MAGIC
# MAGIC ## Next increment
# MAGIC
# MAGIC Silver to Gold, via `notebook` mode — plus `INCREMENTAL` and the merge
# MAGIC writer. Both are new components against the existing contract in
# MAGIC `src/idee_dbx/runtime/contracts.py`, not changes to the executor.
