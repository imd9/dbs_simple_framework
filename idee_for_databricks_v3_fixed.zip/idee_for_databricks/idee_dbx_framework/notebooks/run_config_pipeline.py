# Databricks notebook source
# MAGIC %md
# MAGIC # iDEE — Config Pipeline Runner
# MAGIC
# MAGIC Runs the three framework stages against one filled config file:
# MAGIC
# MAGIC | Stage | Module | Question it answers |
# MAGIC |---|---|---|
# MAGIC | Validate | `config_validator` | Is this config legal? |
# MAGIC | Parse | `config_parser` | What metadata actions does it produce? |
# MAGIC | Load | `metadata_loader` | Apply those actions to the metadata tables |
# MAGIC
# MAGIC **Scope.** This registers *metadata*. It does not move data — the
# MAGIC execution engine is the next increment. Its interface is defined in
# MAGIC `src/idee_dbx/runtime/contracts.py`.
# MAGIC
# MAGIC Nothing is hardcoded: catalog, schema and config path are all widgets.
# MAGIC Run with `dry_run = true` first.

# COMMAND ----------

dbutils.widgets.text("catalog", "medtech_md_scion_dev", "1. Catalog")
dbutils.widgets.text("metadata_schema", "idee_metaschema", "2. Metadata schema")
dbutils.widgets.text(
    "config_path",
    "../../idee_dbx_app/config/customers_landing_to_bronze_config.yaml",
    "3. Filled config file",
)
dbutils.widgets.dropdown("dry_run", "true", ["true", "false"], "4. Dry run")

CATALOG = dbutils.widgets.get("catalog")
METADATA_SCHEMA = dbutils.widgets.get("metadata_schema")
CONFIG_PATH = dbutils.widgets.get("config_path")
DRY_RUN = dbutils.widgets.get("dry_run") == "true"

print(f"Catalog         : {CATALOG}")
print(f"Metadata schema : {METADATA_SCHEMA}")
print(f"Config          : {CONFIG_PATH}")
print(f"Dry run         : {DRY_RUN}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import the framework
# MAGIC Adds `src/` to the path so `idee_dbx` imports without being pip-installed.

# COMMAND ----------

import sys
from pathlib import Path

FRAMEWORK_ROOT = (Path.cwd() / "..").resolve()
FRAMEWORK_SRC = FRAMEWORK_ROOT / "src"
SCHEMA_DIR = FRAMEWORK_ROOT / "schema"

if str(FRAMEWORK_SRC) not in sys.path:
    sys.path.insert(0, str(FRAMEWORK_SRC))

import idee_dbx
from idee_dbx.config_parser import parse_config
from idee_dbx.config_validator import validate_config_file
from idee_dbx.metadata_loader import load_plan

print(f"Framework version: {idee_dbx.__version__}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stage 1 — Validate

# COMMAND ----------

print("Loading started...")
validation = validate_config_file(CONFIG_PATH, schema_dir=SCHEMA_DIR)
print(validation.report())

if not validation.is_valid:
    raise ValueError(
        f"Config validation failed with {len(validation.errors)} error(s). "
        "Nothing was parsed or loaded."
    )

print("\nConfig schema validation passed.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stage 2 — Parse

# COMMAND ----------

plan = parse_config(validation.config, config_path=CONFIG_PATH)
print(plan.summary())
print("\nParser completed. Metadata action list generated.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stage 2b — Review the generated SQL
# MAGIC The last checkpoint before anything is written.

# COMMAND ----------

for statement in plan.to_merge_statements(CATALOG, METADATA_SCHEMA):
    print(statement)
    print()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stage 3 — Load

# COMMAND ----------

result = load_plan(
    plan,
    catalog=CATALOG,
    metadata_schema=METADATA_SCHEMA,
    dry_run=DRY_RUN,
    spark=spark,  # noqa: F821
)
print(result.report())

if not result.succeeded:
    raise RuntimeError("Metadata load failed. See the errors above.")

print("\nLoad complete." if not DRY_RUN else "\nDry run complete — nothing was written.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

METADATA_TABLES = [
    "pipeline_config",
    "source_config",
    "target_config",
    "dataset_config",
    "column_config",
    "quality_rule_config",
    "config_parse_audit",
    "pipeline_audit",
]

if not DRY_RUN:
    for table in METADATA_TABLES:
        count = spark.table(f"{CATALOG}.{METADATA_SCHEMA}.{table}").count()  # noqa: F821
        print(f"{table:<22} {count} row(s)")
else:
    print("Dry run — skipping verification.")
