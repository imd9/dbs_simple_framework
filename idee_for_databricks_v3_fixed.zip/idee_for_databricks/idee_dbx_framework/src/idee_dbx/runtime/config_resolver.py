"""
Config resolver — turns stored metadata back into a RunContext.

The parser writes metadata; this reads it back. Two entry points:

`resolve_from_metadata` queries the metadata tables. That is the real path — a
scheduled job knows a pipeline name, not a YAML file.

`resolve_from_plan` builds the same RunContext straight from a ParsePlan, with
no Spark involved. That is what makes the whole engine testable off-cluster and
what makes a dry run possible before any metadata has been written.

Both produce an identical RunContext, so every downstream component behaves the
same either way.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from ..config_parser import (
    TABLE_COLUMN_CONFIG,
    TABLE_DATASET_CONFIG,
    TABLE_PIPELINE_CONFIG,
    TABLE_QUALITY_RULE_CONFIG,
    TABLE_SOURCE_CONFIG,
    TABLE_TARGET_CONFIG,
    ParsePlan,
)
from .contracts import RunContext


class PipelineNotFound(Exception):
    """The requested pipeline has no metadata. Load its config first."""


def new_run_id() -> str:
    """
    A fresh identifier for one execution.

    Deliberately random, unlike every ID the parser generates. Those are
    deterministic so re-parsing updates rows in place; a run ID is the opposite
    — every execution is a distinct event and must never collide with another.
    """
    return f"run_{uuid.uuid4().hex[:16]}"


# =============================================================================
# From a parse plan — no Spark
# =============================================================================
def resolve_from_plan(
    plan: ParsePlan,
    catalog: str,
    metadata_schema: str,
    run_id: Optional[str] = None,
    dry_run: bool = False,
) -> RunContext:
    """Build a RunContext directly from a parsed config."""

    def one(table: str) -> Dict[str, Any]:
        actions = plan.actions_for(table)
        return dict(actions[0].values) if actions else {}

    def many(table: str) -> List[Dict[str, Any]]:
        return [dict(a.values) for a in plan.actions_for(table)]

    metadata = {
        TABLE_PIPELINE_CONFIG: one(TABLE_PIPELINE_CONFIG),
        TABLE_SOURCE_CONFIG: one(TABLE_SOURCE_CONFIG),
        TABLE_TARGET_CONFIG: one(TABLE_TARGET_CONFIG),
        TABLE_DATASET_CONFIG: one(TABLE_DATASET_CONFIG),
        TABLE_COLUMN_CONFIG: sorted(
            many(TABLE_COLUMN_CONFIG), key=lambda r: r.get("column_position", 0)
        ),
        TABLE_QUALITY_RULE_CONFIG: many(TABLE_QUALITY_RULE_CONFIG),
    }

    return RunContext(
        run_id=run_id or new_run_id(),
        pipeline_id=plan.pipeline_id,
        pipeline_name=plan.pipeline_name,
        dataset_id=plan.dataset_id,
        metadata=metadata,
        catalog=catalog,
        metadata_schema=metadata_schema,
        dry_run=dry_run,
        started_at=datetime.now(timezone.utc),
    )


# =============================================================================
# From the metadata tables — the real path
# =============================================================================
def resolve_from_metadata(
    spark: Any,
    catalog: str,
    metadata_schema: str,
    pipeline_name: Optional[str] = None,
    pipeline_id: Optional[str] = None,
    run_id: Optional[str] = None,
    dry_run: bool = False,
) -> RunContext:
    """
    Load one pipeline's metadata and build a RunContext.

    Identify the pipeline by name or by id. Name is what a person knows; id is
    what a scheduler carries.
    """
    if not pipeline_name and not pipeline_id:
        raise ValueError("give either pipeline_name or pipeline_id")

    prefix = f"{catalog}.{metadata_schema}"
    where = (
        f"pipeline_id = '{_esc(pipeline_id)}'"
        if pipeline_id
        else f"pipeline_name = '{_esc(pipeline_name)}'"
    )

    pipelines = _rows(spark, f"SELECT * FROM {prefix}.{TABLE_PIPELINE_CONFIG} WHERE {where}")
    if not pipelines:
        raise PipelineNotFound(
            f"No metadata for {where} in {prefix}.{TABLE_PIPELINE_CONFIG}. "
            f"Load the config first: main.py load --config <file>"
        )
    if len(pipelines) > 1:
        names = [p.get("config_file_name") for p in pipelines]
        raise PipelineNotFound(
            f"{len(pipelines)} pipelines match {where}: {names}. Identify by pipeline_id."
        )

    pipeline = pipelines[0]
    resolved_id = pipeline["pipeline_id"]

    datasets = _rows(
        spark, f"SELECT * FROM {prefix}.{TABLE_DATASET_CONFIG} WHERE pipeline_id = '{resolved_id}'"
    )
    if not datasets:
        raise PipelineNotFound(f"Pipeline '{resolved_id}' has no dataset_config row.")
    dataset = datasets[0]

    sources = _rows(
        spark, f"SELECT * FROM {prefix}.{TABLE_SOURCE_CONFIG} WHERE source_id = '{dataset['source_id']}'"
    )
    targets = _rows(
        spark, f"SELECT * FROM {prefix}.{TABLE_TARGET_CONFIG} WHERE target_id = '{dataset['target_id']}'"
    )
    columns = _rows(
        spark,
        f"SELECT * FROM {prefix}.{TABLE_COLUMN_CONFIG} "
        f"WHERE dataset_id = '{dataset['dataset_id']}' ORDER BY column_position",
    )
    rules = _rows(
        spark,
        f"SELECT * FROM {prefix}.{TABLE_QUALITY_RULE_CONFIG} "
        f"WHERE dataset_id = '{dataset['dataset_id']}' AND active = true",
    )

    metadata = {
        TABLE_PIPELINE_CONFIG: pipeline,
        TABLE_SOURCE_CONFIG: sources[0] if sources else {},
        TABLE_TARGET_CONFIG: targets[0] if targets else {},
        TABLE_DATASET_CONFIG: dataset,
        TABLE_COLUMN_CONFIG: columns,
        TABLE_QUALITY_RULE_CONFIG: rules,
    }

    return RunContext(
        run_id=run_id or new_run_id(),
        pipeline_id=resolved_id,
        pipeline_name=pipeline.get("pipeline_name", ""),
        dataset_id=dataset["dataset_id"],
        metadata=metadata,
        catalog=catalog,
        metadata_schema=metadata_schema,
        dry_run=dry_run,
        started_at=datetime.now(timezone.utc),
    )


def _rows(spark: Any, sql: str) -> List[Dict[str, Any]]:
    """Run a query and return plain dicts, so nothing downstream needs Spark."""
    return [row.asDict() for row in spark.sql(sql).collect()]


def _esc(value: Any) -> str:
    return str(value).replace("'", "''")
