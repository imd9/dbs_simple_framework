"""
Runtime contracts — the interface every execution component implements.

WHY THIS FILE EXISTS
--------------------
The execution engine is being built by more than one person in parallel. One
person writes the cloud-files reader, another writes the table reader; one
writes the select-star transformer, another writes explicit-column and notebook
transformers. Those pieces only fit together if everyone agrees, in advance,
what each stage hands to the next.

This file is that agreement. It contains no logic — only the shapes. Read it
before writing a component, and change it only by agreement, because every
component depends on it.

THE PIPELINE, IN ORDER
----------------------
    read  ->  transform  ->  apply_dq  ->  write
              (+ audit around the whole thing)

Every stage takes the RunContext plus the previous stage's result, and returns
its own result. Nothing reaches into global state.

LAYER NEUTRALITY
----------------
None of these contracts mention bronze, silver or gold. The same executor runs
landing->bronze and silver->gold; only the resolved metadata differs. If a
component ever needs to know which layer it is running, something has gone
wrong in the design.

DECISIONS ALREADY MADE — do not re-litigate without the team
------------------------------------------------------------
1. `transform` adds the ETL audit columns, not `write`. One owner, so they can
   never be added twice or forgotten.
2. DQ runs BEFORE the write. You cannot quarantine a row you have already
   written.
3. The EXECUTOR writes audit rows, not the individual components. One place,
   one truth, and it still works when a component raises.
4. A `fail`-action rule sets `failed_hard=True` and returns normally. It does
   not raise. Raising makes writing the FAILED audit row awkward.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Protocol

# `DataFrame` is a pyspark.sql.DataFrame at run time. It is typed loosely here
# so this module imports cleanly off-cluster, where pyspark is absent and the
# unit tests still need to read these shapes.
DataFrame = Any


# =============================================================================
# Shared context
# =============================================================================
@dataclass
class RunContext:
    """
    Everything a component needs to know about the current run.

    Built once by the executor from the metadata tables and passed down
    unchanged. Components read from it; they never mutate it.
    """

    run_id: str                     # unique per execution
    pipeline_id: str                # from pipeline_config
    pipeline_name: str
    dataset_id: str

    # Resolved metadata rows, keyed by table name: pipeline_config,
    # source_config, target_config, dataset_config, column_config (list),
    # quality_rule_config (list).
    metadata: Dict[str, Any]

    catalog: str
    metadata_schema: str

    dry_run: bool = False
    started_at: Optional[datetime] = None

    # --- convenience accessors, so components do not dig through dicts ------
    @property
    def source(self) -> Dict[str, Any]:
        return self.metadata.get("source_config", {}) or {}

    @property
    def target(self) -> Dict[str, Any]:
        return self.metadata.get("target_config", {}) or {}

    @property
    def dataset(self) -> Dict[str, Any]:
        return self.metadata.get("dataset_config", {}) or {}

    @property
    def columns(self) -> List[Dict[str, Any]]:
        return self.metadata.get("column_config", []) or []

    @property
    def rules(self) -> List[Dict[str, Any]]:
        return self.metadata.get("quality_rule_config", []) or []

    @property
    def column_mode(self) -> str:
        return self.dataset.get("column_mode", "star")

    @property
    def load_type(self) -> str:
        return self.dataset.get("load_type", "FULL")


# =============================================================================
# Stage results
# =============================================================================
@dataclass
class ReadResult:
    """What a source reader returns."""

    df: DataFrame
    rows_read: int
    source_description: str = ""     # e.g. the resolved path or table name


@dataclass
class TransformResult:
    """
    What a transformer returns.

    By this point the ETL audit columns have been added (decision 1 above) and
    the frame is in target shape: renamed, cast, trimmed as configured.
    """

    df: DataFrame
    columns_out: List[str]
    notes: List[str] = field(default_factory=list)


@dataclass
class DQResult:
    """
    What the DQ engine returns.

    `passing_df` is what gets written. `quarantined_df` is written separately
    to the quarantine target when it is not None.
    """

    passing_df: DataFrame
    quarantined_df: Optional[DataFrame] = None
    rows_passed: int = 0
    rows_dropped: int = 0
    rows_quarantined: int = 0
    rows_warned: int = 0

    # True when a rule with action=fail matched at least one row. The executor
    # decides what to do; the DQ engine does not raise. See decision 4.
    failed_hard: bool = False
    failed_rule_names: List[str] = field(default_factory=list)


@dataclass
class WriteResult:
    """What a target writer returns."""

    rows_written: int
    target: str                      # resolved table name or path
    write_mode: str = ""             # e.g. overwrite, append, merge


@dataclass
class ExecutionSummary:
    """
    The executor's return value — one object describing the whole run.

    This is what gets printed in a notebook and what the audit row is built
    from, so it needs to be complete enough to explain a failure without
    reading logs.
    """

    run_id: str
    pipeline_id: str
    pipeline_name: str
    status: str                      # STARTED | SUCCESS | FAILED | SKIPPED
    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None

    rows_read: int = 0
    rows_written: int = 0
    rows_dropped: int = 0
    rows_quarantined: int = 0
    rows_warned: int = 0

    target: str = ""
    error_message: Optional[str] = None
    notes: List[str] = field(default_factory=list)

    @property
    def succeeded(self) -> bool:
        return self.status == "SUCCESS"

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.started_at and self.ended_at:
            return (self.ended_at - self.started_at).total_seconds()
        return None

    def report(self) -> str:
        lines = [
            f"Pipeline   : {self.pipeline_name}",
            f"Run ID     : {self.run_id}",
            f"Status     : {self.status}",
            f"Target     : {self.target}",
            f"Rows read  : {self.rows_read}",
            f"Rows written: {self.rows_written}",
        ]
        if self.rows_dropped:
            lines.append(f"Rows dropped     : {self.rows_dropped}")
        if self.rows_quarantined:
            lines.append(f"Rows quarantined : {self.rows_quarantined}")
        if self.rows_warned:
            lines.append(f"Rows warned      : {self.rows_warned}")
        if self.duration_seconds is not None:
            lines.append(f"Duration   : {self.duration_seconds:.1f}s")
        if self.error_message:
            lines.append(f"\nError: {self.error_message}")
        if self.notes:
            lines.append("\nNotes:")
            lines.extend(f"  - {n}" for n in self.notes)
        return "\n".join(lines)


# =============================================================================
# Component protocols
# =============================================================================
# These describe the callable shape each component must have. A component can
# be a plain function or a class with __call__ — the executor only cares about
# the signature.


class SourceReader(Protocol):
    """Reads from one kind of source. Registered by `source_type`."""

    def __call__(self, ctx: RunContext, spark: Any) -> ReadResult: ...


class Transformer(Protocol):
    """Shapes the frame for the target. Registered by `column_mode`."""

    def __call__(self, ctx: RunContext, read: ReadResult, spark: Any) -> TransformResult: ...


class DQEngine(Protocol):
    """Applies quality rules and routes rows. Registered by `quality.engine`."""

    def __call__(self, ctx: RunContext, transformed: TransformResult, spark: Any) -> DQResult: ...


class TargetWriter(Protocol):
    """Writes to one kind of target. Registered by `target_type`."""

    def __call__(self, ctx: RunContext, dq: DQResult, spark: Any) -> WriteResult: ...


# =============================================================================
# Component registries
# =============================================================================
# Components register themselves here, and the executor looks up the right one
# from the resolved metadata. Adding a new source type means adding an entry —
# not editing the executor.
#
#     from idee_dbx.runtime.contracts import SOURCE_READERS
#
#     def read_cloud_files(ctx, spark): ...
#     SOURCE_READERS["cloud_files"] = read_cloud_files

SOURCE_READERS: Dict[str, SourceReader] = {}
TRANSFORMERS: Dict[str, Transformer] = {}
DQ_ENGINES: Dict[str, DQEngine] = {}
TARGET_WRITERS: Dict[str, TargetWriter] = {}


class ComponentNotRegistered(Exception):
    """Raised when the metadata asks for a component nobody has built yet."""


def get_source_reader(source_type: str) -> SourceReader:
    if source_type not in SOURCE_READERS:
        raise ComponentNotRegistered(
            f"No source reader registered for source_type '{source_type}'. "
            f"Available: {sorted(SOURCE_READERS)}"
        )
    return SOURCE_READERS[source_type]


def get_transformer(column_mode: str) -> Transformer:
    if column_mode not in TRANSFORMERS:
        raise ComponentNotRegistered(
            f"No transformer registered for column_mode '{column_mode}'. "
            f"Available: {sorted(TRANSFORMERS)}"
        )
    return TRANSFORMERS[column_mode]


def get_dq_engine(engine: str) -> DQEngine:
    if engine not in DQ_ENGINES:
        raise ComponentNotRegistered(
            f"No DQ engine registered for '{engine}'. Available: {sorted(DQ_ENGINES)}"
        )
    return DQ_ENGINES[engine]


def get_target_writer(target_type: str) -> TargetWriter:
    if target_type not in TARGET_WRITERS:
        raise ComponentNotRegistered(
            f"No target writer registered for target_type '{target_type}'. "
            f"Available: {sorted(TARGET_WRITERS)}"
        )
    return TARGET_WRITERS[target_type]
