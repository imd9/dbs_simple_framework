"""
Transformers — the second stage. One per column_mode.

A transformer takes the raw source frame and returns it in target shape. By the
time it returns, the ETL audit columns are attached; the transformer owns that,
not the writer, so they can never be added twice or forgotten.

The column-selection logic is pure and unit-tested. The Spark calls around it
are deliberately thin, because the part that goes wrong is deciding *which*
columns, not calling `.select()`.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from ..config_parser import ETL_AUDIT_COLUMNS
from .contracts import ReadResult, RunContext, TransformResult, TRANSFORMERS


class TransformFailed(Exception):
    """The frame could not be shaped for the target. The message says why."""


# =============================================================================
# Pure planning
# =============================================================================
def plan_star_columns(available: List[str], exclude_etl: bool = True) -> List[str]:
    """
    Which source columns survive in star mode.

    Not literally every column: the framework's own audit columns are dropped
    when exclude_etl is true, because they are regenerated on write. Copying
    them forward would make the target claim it was loaded when the SOURCE was,
    and the failure is silent until someone audits it.
    """
    if not exclude_etl:
        return list(available)
    return [c for c in available if c not in ETL_AUDIT_COLUMNS]


def plan_explicit_columns(
    column_config: List[Dict[str, Any]],
    available: List[str],
) -> List[Tuple[str, str, str]]:
    """
    Resolve the configured mapping to (source_column, target_column, target_type).

    Fails loudly when a configured column is absent from the source. Silently
    producing a null column instead would hide a schema change until someone
    noticed the data was wrong.
    """
    missing = [
        c["source_column"] for c in column_config if c.get("source_column") not in available
    ]
    if missing:
        raise TransformFailed(
            f"column_config references columns that are not in the source: {missing}. "
            f"Source has: {sorted(available)}"
        )
    return [
        (c["source_column"], c["target_column"], c["target_type"])
        for c in sorted(column_config, key=lambda r: r.get("column_position", 0))
    ]


def plan_trim_columns(
    schema_types: Dict[str, str],
    selected: List[str],
    trim_all: bool,
) -> List[str]:
    """Which columns get trimmed: string columns only, and only when asked."""
    if not trim_all:
        return []
    return [c for c in selected if schema_types.get(c, "").lower() == "string"]


# =============================================================================
# ETL audit columns
# =============================================================================
def add_etl_columns(df: Any, ctx: RunContext, source_description: str) -> Any:
    """
    Attach the framework's audit columns.

    Owned by the transformer so there is exactly one place they are added.
    `_ingested_at` is the processing time of THIS run, never inherited.
    """
    from pyspark.sql import functions as F  # imported lazily: absent off-cluster

    return (
        df.withColumn("_ingested_at", F.current_timestamp())
        .withColumn("_run_id", F.lit(ctx.run_id))
        .withColumn("_pipeline_id", F.lit(ctx.pipeline_id))
        .withColumn("_source_file", F.lit(source_description))
    )


def _schema_types(df: Any) -> Dict[str, str]:
    return {field.name: field.dataType.simpleString() for field in df.schema.fields}


# =============================================================================
# Transformers
# =============================================================================
def transform_star(ctx: RunContext, read: ReadResult, spark: Any) -> TransformResult:
    """Pass every source column through, minus the framework's own."""
    from pyspark.sql import functions as F

    exclude_etl = bool(ctx.dataset.get("exclude_etl_columns", True))
    available = read.df.columns
    selected = plan_star_columns(available, exclude_etl)

    if not selected:
        raise TransformFailed("no columns left after excluding ETL audit columns")

    df = read.df.select(*selected)

    for column in plan_trim_columns(_schema_types(read.df), selected, bool(ctx.dataset.get("trim_all"))):
        df = df.withColumn(column, F.trim(F.col(column)))

    df = add_etl_columns(df, ctx, read.source_description)

    notes = [f"star mode: {len(selected)} source column(s) passed through"]
    dropped = [c for c in available if c not in selected]
    if dropped:
        notes.append(f"excluded upstream ETL columns: {dropped}")

    return TransformResult(df=df, columns_out=df.columns, notes=notes)


def transform_explicit(ctx: RunContext, read: ReadResult, spark: Any) -> TransformResult:
    """Rename and cast per column_config. Unlisted source columns are dropped."""
    from pyspark.sql import functions as F

    mapping = plan_explicit_columns(ctx.columns, read.df.columns)
    if not mapping:
        raise TransformFailed("column_mode is 'explicit' but column_config is empty")

    trim_all = bool(ctx.dataset.get("trim_all"))
    source_types = _schema_types(read.df)

    projections = []
    for source_column, target_column, target_type in mapping:
        expression = F.col(source_column)
        # Trim before casting: " 42 " casts to null, "42" does not.
        if trim_all and source_types.get(source_column, "").lower() == "string":
            expression = F.trim(expression)
        projections.append(expression.cast(target_type).alias(target_column))

    df = read.df.select(*projections)
    df = add_etl_columns(df, ctx, read.source_description)

    return TransformResult(
        df=df,
        columns_out=df.columns,
        notes=[f"explicit mode: {len(mapping)} column(s) mapped, renamed and cast"],
    )


def transform_notebook(ctx: RunContext, read: ReadResult, spark: Any) -> TransformResult:
    """
    Not implemented in v0.1.

    The metadata records the notebook name and path; executing it is a later
    increment. Raising a specific, actionable error beats silently passing the
    frame through unchanged, which would look like it worked.
    """
    raise TransformFailed(
        f"column_mode 'notebook' is not executed in v0.1. The reference is recorded "
        f"(name='{ctx.dataset.get('notebook_name')}', path='{ctx.dataset.get('notebook_path')}') "
        f"but the framework does not run it yet. Use 'star' or 'explicit', or run the "
        f"notebook by hand."
    )


# =============================================================================
# Registration
# =============================================================================
TRANSFORMERS["star"] = transform_star
TRANSFORMERS["explicit"] = transform_explicit
TRANSFORMERS["notebook"] = transform_notebook
