"""
Shared PyTest fixtures.

Puts src/ on the import path so tests import the framework the same way a
Databricks notebook does, without requiring an installed package.
"""

from __future__ import annotations

import copy
import sys
from pathlib import Path

import pytest
import yaml

FRAMEWORK_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = FRAMEWORK_ROOT / "src"
SCHEMA_DIR = FRAMEWORK_ROOT / "schema"
FIXTURE_DIR = Path(__file__).resolve().parent / "fixtures"
TEMPLATE_DIR = FRAMEWORK_ROOT / "templates"
APP_CONFIG_DIR = FRAMEWORK_ROOT.parent / "idee_dbx_app" / "config"

if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))


@pytest.fixture(scope="session")
def schema_dir() -> Path:
    return SCHEMA_DIR


@pytest.fixture(scope="session")
def fixture_dir() -> Path:
    return FIXTURE_DIR


@pytest.fixture(scope="session")
def template_path() -> Path:
    return TEMPLATE_DIR / "idee_pipeline_config_template.yaml"


@pytest.fixture(scope="session")
def app_config_paths() -> list[Path]:
    """Every filled config shipped in the application folder."""
    return sorted(APP_CONFIG_DIR.glob("*.yaml"))


def _load(name: str) -> dict:
    with open(FIXTURE_DIR / name, encoding="utf-8") as handle:
        return yaml.safe_load(handle)


@pytest.fixture(scope="session")
def _star_raw() -> dict:
    return _load("valid_star_config.yaml")


@pytest.fixture(scope="session")
def _explicit_raw() -> dict:
    return _load("valid_explicit_config.yaml")


@pytest.fixture(scope="session")
def _notebook_raw() -> dict:
    return _load("valid_notebook_config.yaml")


# Deep copies: tests mutate these to build invalid cases, and a shared dict
# would leak those mutations between tests.
@pytest.fixture
def star_config(_star_raw: dict) -> dict:
    return copy.deepcopy(_star_raw)


@pytest.fixture
def explicit_config(_explicit_raw: dict) -> dict:
    return copy.deepcopy(_explicit_raw)


@pytest.fixture
def notebook_config(_notebook_raw: dict) -> dict:
    return copy.deepcopy(_notebook_raw)
