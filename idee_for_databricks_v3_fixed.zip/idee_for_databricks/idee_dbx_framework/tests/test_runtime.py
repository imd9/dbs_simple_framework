"""
Unit tests for the runtime execution engine.

These cover the DECISION logic — path resolution, column planning, alias
resolution, action precedence, write-mode selection, audit row construction —
all of which are pure functions with no Spark dependency.

That split is deliberate. Choosing which columns survive or which action wins
is where the bugs live; calling `.select()` is not. Keeping the decisions pure
means they can be tested in a second, off-cluster, instead of needing a running
cluster to find out that a trailing slash broke a path.

The Spark-touching parts are exercised by the end-to-end notebook.
"""

from __future__ import annotations

import pytest

from idee_dbx.config_parser import ETL_AUDIT_COLUMNS, parse_alias_string
from idee_dbx.runtime.audit_logger import build_audit_merge, build_final_row, build_started_row
from idee_dbx.runtime.config_resolver import new_run_id, resolve_from_plan
from idee_dbx.runtime.contracts import (
    ComponentNotRegistered,
    ExecutionSummary,
    get_source_reader,
    get_transformer,
)
from idee_dbx.runtime.dq_engine import (
    ACTION_SEVERITY,
    DQFailed,
    prepare_rules,
    resolve_expression,
    strictest_action,
)
from idee_dbx.runtime.source_readers import (
    SourceNotReadable,
    build_read_options,
    resolve_source_path,
)
from idee_dbx.runtime.target_writers import (
    WriteFailed,
    decide_write_mode,
    quarantine_table_name,
    split_table_name,
)
from idee_dbx.runtime.transformer import (
    TransformFailed,
    plan_explicit_columns,
    plan_star_columns,
    plan_trim_columns,
)


# =============================================================================
# Source path resolution
# =============================================================================
class TestSourcePath:
    @pytest.mark.parametrize(
        "root,relative,expected",
        [
            ("/Volumes/x/landing/", "incoming/*.csv", "/Volumes/x/landing/incoming/*.csv"),
            ("/Volumes/x/landing", "incoming/*.csv", "/Volumes/x/landing/incoming/*.csv"),
            ("/Volumes/x/landing/", "/incoming/a.csv", "/Volumes/x/landing/incoming/a.csv"),
            ("/Volumes/x/landing", None, "/Volumes/x/landing"),
            ("/Volumes/x/landing/", "", "/Volumes/x/landing"),
        ],
    )
    def test_trailing_and_leading_slashes(self, root, relative, expected):
        assert resolve_source_path(root, relative) == expected

    def test_empty_root_is_an_error(self):
        with pytest.raises(SourceNotReadable):
            resolve_source_path("", "incoming/*.csv")

    def test_csv_does_not_infer_schema(self):
        """
        Bronze must preserve the source as text.

        Inferring types means the same file can land with different types on
        different days, depending on which rows Spark sampled.
        """
        assert build_read_options("csv")["inferSchema"] == "false"

    def test_csv_expects_a_header(self):
        assert build_read_options("csv")["header"] == "true"


# =============================================================================
# Column planning
# =============================================================================
class TestStarColumns:
    def test_etl_columns_are_excluded_by_default(self):
        available = ["id", "name"] + ETL_AUDIT_COLUMNS
        assert plan_star_columns(available) == ["id", "name"]

    def test_exclusion_can_be_turned_off(self):
        available = ["id", "_ingested_at"]
        assert plan_star_columns(available, exclude_etl=False) == available

    def test_source_without_etl_columns_is_unaffected(self):
        assert plan_star_columns(["a", "b", "c"]) == ["a", "b", "c"]

    def test_order_is_preserved(self):
        assert plan_star_columns(["z", "a", "m"]) == ["z", "a", "m"]


class TestExplicitColumns:
    def _config(self):
        return [
            {"source_column": "B", "target_column": "b", "target_type": "STRING", "column_position": 2},
            {"source_column": "A", "target_column": "a", "target_type": "BIGINT", "column_position": 1},
        ]

    def test_mapping_follows_column_position(self):
        mapping = plan_explicit_columns(self._config(), ["A", "B"])
        assert [m[0] for m in mapping] == ["A", "B"]

    def test_rename_and_type_are_carried(self):
        mapping = plan_explicit_columns(self._config(), ["A", "B"])
        assert mapping[0] == ("A", "a", "BIGINT")

    def test_missing_source_column_fails_loudly(self):
        """
        A configured column absent from the source is an error, not a null.

        Producing a null column instead would hide a schema change until
        someone noticed the data was wrong.
        """
        with pytest.raises(TransformFailed) as exc:
            plan_explicit_columns(self._config(), ["A"])
        assert "B" in str(exc.value)


class TestTrimPlanning:
    def test_only_string_columns_are_trimmed(self):
        types = {"a": "string", "b": "bigint", "c": "string"}
        assert plan_trim_columns(types, ["a", "b", "c"], trim_all=True) == ["a", "c"]

    def test_nothing_is_trimmed_when_disabled(self):
        types = {"a": "string"}
        assert plan_trim_columns(types, ["a"], trim_all=False) == []


# =============================================================================
# DQ alias resolution
# =============================================================================
class TestAliasResolution:
    def test_first_matching_candidate_wins(self):
        aliases = {"email": ["EMAIL_ADDRESS", "email_address", "email"]}
        resolved = resolve_expression("{email} IS NOT NULL", aliases, ["email_address", "id"])
        assert resolved == "email_address IS NOT NULL"

    def test_matching_is_case_insensitive(self):
        aliases = {"cid": ["customer_id"]}
        resolved = resolve_expression("{cid} > 0", aliases, ["CUSTOMER_ID"])
        assert resolved == "CUSTOMER_ID > 0"

    def test_several_placeholders_in_one_expression(self):
        aliases = {"a": ["col_a"], "b": ["col_b"]}
        resolved = resolve_expression("{a} IS NOT NULL AND {b} > 0", aliases, ["col_a", "col_b"])
        assert resolved == "col_a IS NOT NULL AND col_b > 0"

    def test_unaliased_placeholder_falls_back_to_its_own_name(self):
        resolved = resolve_expression("{customer_id} IS NOT NULL", {}, ["customer_id"])
        assert resolved == "customer_id IS NOT NULL"

    def test_unresolvable_alias_raises(self):
        """
        Better to fail than to substitute a column that is not there.

        A rule evaluating against a missing column looks like it passed, which
        is worse than having no rule at all.
        """
        with pytest.raises(DQFailed) as exc:
            resolve_expression("{email} IS NOT NULL", {"email": ["EMAIL"]}, ["id"])
        assert "email" in str(exc.value).lower()

    def test_expression_without_placeholders_is_untouched(self):
        assert resolve_expression("id IS NOT NULL", {}, ["id"]) == "id IS NOT NULL"

    def test_alias_string_round_trips(self):
        text = "customer_id=CUST_ID,customer_id;email=EMAIL,email"
        parsed = parse_alias_string(text)
        assert parsed["customer_id"] == ["CUST_ID", "customer_id"]
        assert parsed["email"] == ["EMAIL", "email"]

    def test_empty_alias_string_is_empty_map(self):
        assert parse_alias_string(None) == {}
        assert parse_alias_string("") == {}


class TestRulePreparation:
    def test_inactive_rules_are_skipped(self):
        rules = [
            {"rule_name": "on", "rule_expression": "id IS NOT NULL", "action": "warn", "active": True},
            {"rule_name": "off", "rule_expression": "id > 0", "action": "warn", "active": False},
        ]
        prepared = prepare_rules(rules, None, ["id"])
        assert [r[0]["rule_name"] for r in prepared] == ["on"]

    def test_aliases_are_applied_during_preparation(self):
        rules = [{"rule_name": "r", "rule_expression": "{cid} IS NOT NULL", "action": "warn", "active": True}]
        prepared = prepare_rules(rules, "cid=CUSTOMER_ID", ["CUSTOMER_ID"])
        assert prepared[0][1] == "CUSTOMER_ID IS NOT NULL"


# =============================================================================
# Action precedence
# =============================================================================
class TestActionPrecedence:
    def test_severity_order_is_warn_drop_quarantine_fail(self):
        assert (
            ACTION_SEVERITY["warn"]
            < ACTION_SEVERITY["drop"]
            < ACTION_SEVERITY["quarantine"]
            < ACTION_SEVERITY["fail"]
        )

    def test_strictest_action_wins(self):
        """A row failing both a warn and a fail rule must be treated as fail."""
        assert strictest_action(["warn", "fail"]) == "fail"
        assert strictest_action(["warn", "drop"]) == "drop"
        assert strictest_action(["quarantine", "drop"]) == "quarantine"

    def test_no_actions_means_the_row_passed(self):
        assert strictest_action([]) is None


# =============================================================================
# Write modes
# =============================================================================
class TestWriteModes:
    def test_full_is_overwrite(self):
        """
        Overwrite, not truncate-then-insert.

        Delta's overwrite is atomic: a concurrent reader sees the old version
        or the new one, never an empty table.
        """
        assert decide_write_mode("FULL") == "overwrite"

    def test_lowercase_load_type_is_accepted(self):
        assert decide_write_mode("full") == "overwrite"

    @pytest.mark.parametrize("load_type", ["INCREMENTAL", "CDC", "SNAPSHOT"])
    def test_unimplemented_load_types_refuse_clearly(self, load_type):
        """Refusing beats guessing at semantics that were never built."""
        with pytest.raises(WriteFailed) as exc:
            decide_write_mode(load_type)
        assert "not implemented" in str(exc.value).lower()

    def test_unknown_load_type_refuses(self):
        with pytest.raises(WriteFailed):
            decide_write_mode("UPSERT")

    def test_three_part_name_is_split(self):
        parts = split_table_name("cat.sch.tbl")
        assert parts == {"catalog": "cat", "schema": "sch", "table": "tbl"}

    @pytest.mark.parametrize("bad", ["tbl", "sch.tbl", "a.b.c.d"])
    def test_bad_table_name_refuses(self, bad):
        with pytest.raises(WriteFailed):
            split_table_name(bad)

    def test_quarantine_is_one_shared_table(self):
        assert quarantine_table_name("cat", "idee_app") == "cat.idee_app.quarantine_records"


# =============================================================================
# Component registry
# =============================================================================
class TestRegistry:
    @pytest.mark.parametrize("source_type", ["cloud_files", "delta_table"])
    def test_implemented_readers_resolve(self, source_type):
        assert get_source_reader(source_type) is not None

    @pytest.mark.parametrize("source_type", ["jdbc", "kafka", "api"])
    def test_unbuilt_readers_name_themselves(self, source_type):
        with pytest.raises(ComponentNotRegistered) as exc:
            get_source_reader(source_type)
        assert source_type in str(exc.value)

    @pytest.mark.parametrize("mode", ["star", "explicit", "notebook"])
    def test_all_column_modes_resolve(self, mode):
        assert get_transformer(mode) is not None


# =============================================================================
# Run context
# =============================================================================
class TestRunContext:
    def test_run_ids_are_unique(self):
        """
        Unlike every parser-generated ID, a run ID must NOT be deterministic —
        each execution is a distinct event.
        """
        assert new_run_id() != new_run_id()

    def test_context_from_plan_needs_no_spark(self, star_config):
        from idee_dbx.config_parser import parse_config

        plan = parse_config(star_config, config_path="/tmp/x.yaml")
        ctx = resolve_from_plan(plan, "cat", "idee_metaschema")
        assert ctx.pipeline_id == plan.pipeline_id
        assert ctx.column_mode == "star"
        assert ctx.load_type == "FULL"
        assert ctx.source["source_type"] == "cloud_files"
        assert ctx.target["target_table"].endswith("bronze_test")

    def test_columns_arrive_in_position_order(self, explicit_config):
        from idee_dbx.config_parser import parse_config

        plan = parse_config(explicit_config, config_path="/tmp/x.yaml")
        ctx = resolve_from_plan(plan, "cat", "idee_metaschema")
        positions = [c["column_position"] for c in ctx.columns]
        assert positions == sorted(positions)

    def test_dry_run_flag_is_carried(self, star_config):
        from idee_dbx.config_parser import parse_config

        plan = parse_config(star_config, config_path="/tmp/x.yaml")
        assert resolve_from_plan(plan, "cat", "s", dry_run=True).dry_run is True


# =============================================================================
# Audit rows
# =============================================================================
class TestAuditRows:
    def _ctx(self, star_config):
        from idee_dbx.config_parser import parse_config

        plan = parse_config(star_config, config_path="/tmp/x.yaml")
        return resolve_from_plan(plan, "cat", "idee_metaschema")

    def test_started_row_has_no_outcome_yet(self, star_config):
        row = build_started_row(self._ctx(star_config))
        assert row["status"] == "STARTED"
        assert row["end_time"] is None
        assert row["rows_written"] is None

    def test_started_row_carries_identity(self, star_config):
        ctx = self._ctx(star_config)
        row = build_started_row(ctx)
        assert row["run_id"] == ctx.run_id
        assert row["pipeline_id"] == ctx.pipeline_id
        assert row["dataset_id"] == ctx.dataset_id

    def test_final_row_carries_counts(self, star_config):
        ctx = self._ctx(star_config)
        summary = ExecutionSummary(
            run_id=ctx.run_id,
            pipeline_id=ctx.pipeline_id,
            pipeline_name=ctx.pipeline_name,
            status="SUCCESS",
            rows_read=100,
            rows_written=95,
            rows_quarantined=5,
        )
        row = build_final_row(ctx, summary)
        assert row["status"] == "SUCCESS"
        assert row["rows_read"] == 100
        assert row["rows_written"] == 95
        assert row["rows_quarantined"] == 5

    def test_audit_write_is_a_merge_on_run_and_dataset(self, star_config):
        """
        The STARTED row and the final row are the same run, so the second write
        must update the first rather than leave two rows to reconcile.
        """
        ctx = self._ctx(star_config)
        sql = build_audit_merge(build_started_row(ctx), "cat", "meta")
        assert sql.startswith("MERGE INTO cat.meta.pipeline_audit")
        assert "tgt.run_id = src.run_id AND tgt.dataset_id = src.dataset_id" in sql

    def test_audit_merge_does_not_reset_created_at(self, star_config):
        ctx = self._ctx(star_config)
        sql = build_audit_merge(build_started_row(ctx), "cat", "meta")
        update_block = sql.split("WHEN MATCHED THEN UPDATE SET")[1].split("WHEN NOT MATCHED")[0]
        assert "created_at" not in update_block

    def test_quotes_in_an_error_message_are_escaped(self, star_config):
        ctx = self._ctx(star_config)
        summary = ExecutionSummary(
            run_id=ctx.run_id,
            pipeline_id=ctx.pipeline_id,
            pipeline_name=ctx.pipeline_name,
            status="FAILED",
            error_message="column 'id' doesn't exist",
        )
        sql = build_audit_merge(build_final_row(ctx, summary), "cat", "meta")
        assert "doesn''t" in sql


# =============================================================================
# Execution summary
# =============================================================================
class TestExecutionSummary:
    def test_only_success_counts_as_succeeded(self):
        for status in ("STARTED", "FAILED", "SKIPPED"):
            assert not ExecutionSummary("r", "p", "n", status).succeeded
        assert ExecutionSummary("r", "p", "n", "SUCCESS").succeeded

    def test_duration_is_none_until_finished(self):
        assert ExecutionSummary("r", "p", "n", "STARTED").duration_seconds is None

    def test_report_is_printable(self):
        summary = ExecutionSummary("r", "p", "my_pipeline", "SUCCESS", rows_read=10, rows_written=10)
        report = summary.report()
        assert "my_pipeline" in report
        assert "SUCCESS" in report
