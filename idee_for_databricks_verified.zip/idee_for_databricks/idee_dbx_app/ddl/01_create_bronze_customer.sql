-- =============================================================================
-- 01_create_bronze_customer.sql
-- =============================================================================
-- Bronze target for scion_customer_landing_to_bronze.
--
-- OWNER      : Application team. App-specific, not framework code.
-- SCHEMA     : ${catalog}.${app_schema}   (business data, NOT idee_metaschema)
-- PARAMETERS : ${catalog}, ${app_schema}
--
-- COLUMN NAMES MATCH THE SOURCE FILE EXACTLY
--   That pipeline uses column_mode: star, which passes every source column
--   through unchanged. The CSV header is:
--       CUSTOMER_ID,CUSTOMER_NAME,EMAIL_ADDRESS,COUNTRY_CODE,CREATED_DATE
--   so those are the column names here, uppercase and all. Renaming belongs on
--   the way to Silver, driven by column_config — not here.
--
-- EVERYTHING IS STRING
--   Bronze preserves the source as text. The reader runs with inferSchema off
--   on purpose: inferring types means the same file can land with different
--   types on different days depending on which rows Spark sampled. Casting
--   happens in Silver, where the target type is declared in config.
--
-- THE _ COLUMNS ARE WRITTEN BY THE FRAMEWORK
--   Do not populate them by hand and do not add more. The transformer owns them
--   so they can never be duplicated or forgotten. They must match
--   ETL_AUDIT_COLUMNS in config_parser.py exactly.
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.${app_schema}.bronze_customer (
    CUSTOMER_ID    STRING COMMENT 'Raw source value, uncast.',
    CUSTOMER_NAME  STRING COMMENT 'Raw source value, uncast.',
    EMAIL_ADDRESS  STRING COMMENT 'Raw source value, uncast.',
    COUNTRY_CODE   STRING COMMENT 'Raw source value, uncast.',
    CREATED_DATE   STRING COMMENT 'Raw source value, uncast.',

    -- Framework-managed. Regenerated on every run, never copied forward.
    _ingested_at   TIMESTAMP COMMENT 'When this row was written by this pipeline.',
    _run_id        STRING    COMMENT 'The run that produced it. Joins to pipeline_audit.run_id.',
    _pipeline_id   STRING    COMMENT 'Which pipeline produced it. Joins to pipeline_config.pipeline_id.',
    _source_file   STRING    COMMENT 'Resolved source path this row was read from.'
)
USING DELTA
COMMENT 'Bronze: raw customer extracts, source fidelity preserved.'
TBLPROPERTIES (
    'idee.table_role' = 'bronze',
    'idee.pipeline'   = 'scion_customer_landing_to_bronze',
    'idee.owner'      = 'application'
);
