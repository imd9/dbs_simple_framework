# Databricks notebook source
# MAGIC %md
# MAGIC # Sample Pipeline — application view
# MAGIC
# MAGIC How a downstream team uses the framework.
# MAGIC
# MAGIC **This notebook contains no framework logic.** It imports `idee_dbx`
# MAGIC from the framework folder and calls it against this team's config.
# MAGIC Validation, parsing and loading all live in the framework — if you find
# MAGIC yourself pasting framework code in here, it belongs on the other side.

# COMMAND ----------

dbutils.widgets.text("catalog", "medtech_md_scion_dev", "1. Catalog")
dbutils.widgets.text("metadata_schema", "idee_metaschema", "2. Metadata schema")
dbutils.widgets.text("app_schema", "idee_app", "3. Application schema")
dbutils.widgets.dropdown(
    "config_file",
    "customers_landing_to_bronze_config.yaml",
    [
        "customers_landing_to_bronze_config.yaml",           # star     · files  -> bronze
        "customers_bronze_to_silver_config.yaml",            # explicit · bronze -> silver
        "customers_combined_landing_to_bronze_config.yaml",  # notebook · 2 files -> bronze
    ],
    "4. Config file",
)
dbutils.widgets.dropdown("dry_run", "true", ["true", "false"], "5. Dry run")

CATALOG = dbutils.widgets.get("catalog")
METADATA_SCHEMA = dbutils.widgets.get("metadata_schema")
APP_SCHEMA = dbutils.widgets.get("app_schema")
DRY_RUN = dbutils.widgets.get("dry_run") == "true"
CONFIG_PATH = f"../config/{dbutils.widgets.get('config_file')}"

print(f"Catalog          : {CATALOG}")
print(f"Metadata schema  : {METADATA_SCHEMA}")
print(f"Application      : {APP_SCHEMA}")
print(f"Config           : {CONFIG_PATH}")
print(f"Dry run          : {DRY_RUN}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import the framework
# MAGIC Adds the framework `src/` to the path. No framework code is copied here.

# COMMAND ----------

import sys
from pathlib import Path

FRAMEWORK_SRC = (Path.cwd() / ".." / ".." / "idee_dbx_framework" / "src").resolve()
if str(FRAMEWORK_SRC) not in sys.path:
    sys.path.insert(0, str(FRAMEWORK_SRC))

import idee_dbx
from idee_dbx.config_parser import parse_config
from idee_dbx.config_validator import validate_config_file
from idee_dbx.metadata_loader import load_plan

SCHEMA_DIR = (Path.cwd() / ".." / ".." / "idee_dbx_framework" / "schema").resolve()
print(f"Framework version: {idee_dbx.__version__}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 1 — Create this team's tables
# MAGIC Application DDL, in the application schema. Not the metadata schema.

# COMMAND ----------

import glob
import os

for path in sorted(glob.glob("../ddl/*.sql")):
    sql = open(path).read()
    sql = sql.replace("${catalog}", CATALOG).replace("${app_schema}", APP_SCHEMA)
    print(f"Running {os.path.basename(path)} ...", end=" ")
    spark.sql(sql)  # noqa: F821
    print("OK")

display(spark.sql(f"SHOW TABLES IN {CATALOG}.{APP_SCHEMA}"))  # noqa: F821

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 2 — Validate this team's config

# COMMAND ----------

validation = validate_config_file(CONFIG_PATH, schema_dir=SCHEMA_DIR)
print(validation.report())

if not validation.is_valid:
    raise ValueError(
        f"Config validation failed with {len(validation.errors)} error(s). "
        "Nothing was parsed or loaded."
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 3 — Parse into metadata actions

# COMMAND ----------

plan = parse_config(validation.config, config_path=CONFIG_PATH)
print(plan.summary())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 3b — Review the generated SQL before writing anything

# COMMAND ----------

for statement in plan.to_merge_statements(CATALOG, METADATA_SCHEMA):
    print(statement)
    print()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 4 — Load into the metadata schema

# COMMAND ----------

result = load_plan(
    plan,
    catalog=CATALOG,
    metadata_schema=METADATA_SCHEMA,
    dry_run=DRY_RUN,
    spark=spark,  # noqa: F821
)
print(result.report())

if not result.succeeded:
    raise RuntimeError("Metadata load failed. See the errors above.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 5 — Confirm what landed

# COMMAND ----------

if not DRY_RUN:
    display(  # noqa: F821
        spark.sql(  # noqa: F821
            f"""
            SELECT p.pipeline_name,
                   d.object_name,
                   d.column_mode,
                   d.load_type,
                   s.source_type,
                   t.target_table,
                   COUNT(c.source_column) AS mapped_columns
            FROM {CATALOG}.{METADATA_SCHEMA}.pipeline_config p
            JOIN {CATALOG}.{METADATA_SCHEMA}.dataset_config  d ON d.pipeline_id = p.pipeline_id
            JOIN {CATALOG}.{METADATA_SCHEMA}.source_config   s ON s.source_id   = d.source_id
            JOIN {CATALOG}.{METADATA_SCHEMA}.target_config   t ON t.target_id   = d.target_id
            LEFT JOIN {CATALOG}.{METADATA_SCHEMA}.column_config c ON c.dataset_id = d.dataset_id
            WHERE p.pipeline_id = '{plan.pipeline_id}'
            GROUP BY 1,2,3,4,5,6
            """
        )
    )
else:
    print("Dry run — nothing was written.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 6 — Run the pipeline
# MAGIC
# MAGIC **Note on notebook mode.** A config using `column_mode: notebook` cannot
# MAGIC be dry-run: the notebook has to execute before there is anything to
# MAGIC inspect. Set `dry_run = false` for that config.
# MAGIC
# MAGIC Everything above registered *metadata*. This moves *data*.
# MAGIC
# MAGIC The engine is told a pipeline **name** — not a file path. It reads the
# MAGIC metadata that was just loaded and works out the rest. That is what makes
# MAGIC a scheduled job possible later: a scheduler knows a name, not a YAML.

# COMMAND ----------

from idee_dbx.runtime import execute_pipeline

summary = execute_pipeline(
    spark,  # noqa: F821
    catalog=CATALOG,
    pipeline_name=plan.pipeline_name,
    metadata_schema=METADATA_SCHEMA,
    app_schema=APP_SCHEMA,
    dry_run=DRY_RUN,
    dbutils=dbutils,  # noqa: F821 — notebook mode needs it to run the transform notebook
)
print(summary.report())

print("\nWhat happened:")
for note in summary.notes:
    print("  -", note)

if not summary.succeeded and summary.status != "SKIPPED":
    raise RuntimeError(summary.error_message)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 7 — Look at the data

# COMMAND ----------

if not DRY_RUN and summary.succeeded:
    display(spark.table(summary.target))  # noqa: F821
else:
    print("Dry run — nothing was written.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### The four columns you did not configure
# MAGIC
# MAGIC `_ingested_at`, `_run_id`, `_pipeline_id` and `_source_file` are added by
# MAGIC the framework. `_run_id` matches the run in `pipeline_audit`, so any row
# MAGIC can be traced back to the execution that produced it.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 8 — Check quarantine and the run audit

# COMMAND ----------

if not DRY_RUN:
    print("Rows this run rejected:")
    display(spark.sql(f"""   # noqa: F821
        SELECT failed_rules, record_json, quarantined_at
        FROM {CATALOG}.{APP_SCHEMA}.quarantine_records
        WHERE run_id = '{summary.run_id}'
    """))

    print("This run in the audit log:")
    display(spark.sql(f"""   # noqa: F821
        SELECT pipeline_name, status, rows_read, rows_written,
               rows_dropped, rows_quarantined, duration_seconds
        FROM {CATALOG}.{METADATA_SCHEMA}.pipeline_audit
        WHERE run_id = '{summary.run_id}'
    """))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Re-running is safe
# MAGIC
# MAGIC `load_type: FULL` replaces the target each run, so running this notebook
# MAGIC twice leaves the same row count. Fix a typo in the config and re-run —
# MAGIC nothing duplicates.
# MAGIC
# MAGIC ## What is not built yet
# MAGIC
# MAGIC `INCREMENTAL`, `CDC` and `SNAPSHOT` loads; `notebook` column mode; the
# MAGIC `native` and `great_expectations` DQ engines. Every one of them is left
# MAGIC commented out in the config with a NOT YET label. Selecting one still
# MAGIC validates — you get a warning — but the run stops with a clear error.
