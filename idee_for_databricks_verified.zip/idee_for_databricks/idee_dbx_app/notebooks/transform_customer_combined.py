# Databricks notebook source
# DBTITLE 1,Custom Transform: Combine Customer CSVs
# =============================================================================
# transform_customer_combined
# =============================================================================
# A custom transform notebook for the iDEE framework, used when a config sets
#   column_mode: notebook
#
# THE CONTRACT — three rules
#   1. The framework passes a `staging_table` parameter. Write your result there.
#   2. Do not add _ingested_at, _run_id, _pipeline_id or _source_file. The
#      framework owns those and adds them after this notebook finishes. Adding
#      them here would produce duplicates.
#   3. Do not write to the target table. The framework does that, after applying
#      the quality rules. Writing it yourself would bypass them.
#
#   The framework then: adds the ETL audit columns, trims if trim_all is set,
#   applies the quality rules, routes quarantined rows, writes the target,
#   records the run, and drops the staging table.
#
# WHY A TABLE AND NOT A TEMP VIEW
#   dbutils.notebook.run executes in a SEPARATE Spark session on serverless
#   compute, so a temp view created here is invisible to the caller. A real
#   table is the only thing that crosses the session boundary. This cost real
#   debugging time to find — please do not "simplify" it back to a temp view.
#
# WHAT THIS NOTEBOOK DOES
#   Two source files describe customers with different column names:
#     customer_sample.csv            CUSTOMER_ID, CUSTOMER_NAME, EMAIL_ADDRESS
#     test_customers_sharepoint.csv  CUST_ID,     CUST_NAME,     CUST_EMAIL
#   Both are standardised to customer_id / customer_name / email and unioned.
#
#   This is exactly the kind of work that does not belong in a YAML file, which
#   is the whole reason notebook mode exists.
# =============================================================================

from pyspark.sql.functions import col, lit

# -----------------------------------------------------------------------------
# Parameters
# -----------------------------------------------------------------------------
# The framework supplies staging_table. The default lets this notebook be run
# by hand for debugging without the framework driving it.
dbutils.widgets.text(
    "staging_table",
    "medtech_md_scion_dev.idee_app._staging_manual_run",
    "Staging table (supplied by the framework)",
)
dbutils.widgets.text("run_id", "manual", "Run ID (supplied by the framework)")

STAGING_TABLE = dbutils.widgets.get("staging_table")
RUN_ID = dbutils.widgets.get("run_id")

VOLUME_PATH = "/Volumes/medtech_md_scion_dev/idee_app/landing/customer/incoming"
FILE_1 = f"{VOLUME_PATH}/customer_sample.csv"
FILE_2 = f"{VOLUME_PATH}/test_customers_sharepoint.csv"

print(f"Run ID        : {RUN_ID}")
print(f"Staging table : {STAGING_TABLE}")

# COMMAND ----------

# DBTITLE 1,Read and standardise source 1
# inferSchema is off deliberately: Bronze should preserve the source as text.
# Inferring types means the same file can land with different types on different
# days depending on which rows Spark happened to sample. The framework casts
# later, driven by config.
df1 = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "false")
    .load(FILE_1)
)

df1_std = df1.select(
    col("CUSTOMER_ID").alias("customer_id"),
    col("CUSTOMER_NAME").alias("customer_name"),
    col("EMAIL_ADDRESS").alias("email"),
    lit("customer_sample.csv").alias("source_system_file"),
)

print(f"Source 1: {FILE_1} -> {df1_std.count()} rows")

# COMMAND ----------

# DBTITLE 1,Read and standardise source 2
df2 = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "false")
    .load(FILE_2)
)

df2_std = df2.select(
    col("CUST_ID").alias("customer_id"),
    col("CUST_NAME").alias("customer_name"),
    col("CUST_EMAIL").alias("email"),
    lit("test_customers_sharepoint.csv").alias("source_system_file"),
)

print(f"Source 2: {FILE_2} -> {df2_std.count()} rows")

# COMMAND ----------

# DBTITLE 1,Union and hand back to the framework
# unionByName rather than union: it matches on column name instead of position,
# so a reordered select above cannot silently misalign the data.
combined_df = df1_std.unionByName(df2_std)

row_count = combined_df.count()
print(f"Combined : {row_count} rows")
print(f"Columns  : {combined_df.columns}")

if row_count == 0:
    # Fail here rather than leaving an empty table for the framework to find.
    # The error is clearer at the point the data went missing.
    raise ValueError(
        f"Both sources produced 0 rows. Check that {FILE_1} and {FILE_2} exist "
        f"and are not empty."
    )

(
    combined_df.write.mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(STAGING_TABLE)
)

print(f"\nWrote {row_count} rows to {STAGING_TABLE}.")
print("The framework takes it from here: audit columns, quality rules, target write.")
