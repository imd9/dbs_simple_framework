"""
Config validator.

Answers one question: **is this filled config legal?**

It does NOT do anything with the config beyond checking it. Translating a valid
config into metadata actions is the parser's job (config_parser.py).

The validation rules are not hardcoded here. They are read from a versioned
schema file in framework/schema/. The config declares `config_version`, the
validator loads the matching schema, and checks the config against it. Adding a
new config format means adding a new schema file, not editing this module.

Usage
-----
    from idee_dbx.config_validator import validate_config_file

    result = validate_config_file("path/to/customer_full_refresh_config.yaml")
    if result.is_valid:
        ...
    else:
        for error in result.errors:
            print(error)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

# Directory holding the versioned schema files, resolved relative to this file:
#   src/idee_dbx/config_validator.py  ->  ../../schema/
DEFAULT_SCHEMA_DIR = Path(__file__).resolve().parents[2] / "schema"

# Python types accepted for each schema `type:` keyword.
# bool is checked before int because in Python, bool is a subclass of int.
_TYPE_MAP = {
    "string": str,
    "integer": int,
    "boolean": bool,
    "number": (int, float),
}


# =============================================================================
# Result object
# =============================================================================
@dataclass
class ValidationResult:
    """Outcome of validating one config file."""

    config_path: str
    is_valid: bool = True
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    config_version: Optional[str] = None
    schema_version: Optional[str] = None
    config: Optional[Dict[str, Any]] = None

    def add_error(self, message: str) -> None:
        self.errors.append(message)
        self.is_valid = False

    def add_warning(self, message: str) -> None:
        self.warnings.append(message)

    def report(self) -> str:
        """Human-readable summary, suitable for printing in a notebook cell."""
        lines = [f"Config      : {self.config_path}"]
        if self.config_version:
            lines.append(f"Version     : {self.config_version}")
        if self.schema_version:
            lines.append(f"Schema      : v{self.schema_version}")
        lines.append(f"Result      : {'PASSED' if self.is_valid else 'FAILED'}")

        if self.errors:
            lines.append(f"\nErrors ({len(self.errors)}):")
            lines.extend(f"  [ERROR] {e}" for e in self.errors)
        if self.warnings:
            lines.append(f"\nWarnings ({len(self.warnings)}):")
            lines.extend(f"  [WARN ] {w}" for w in self.warnings)
        return "\n".join(lines)


# =============================================================================
# Helpers
# =============================================================================
def _load_yaml(path: Path) -> Dict[str, Any]:
    """Read a YAML file into a dict. Raises on parse failure."""
    with open(path, "r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle)
    if data is None:
        raise ValueError("file is empty")
    if not isinstance(data, dict):
        raise ValueError("top level of the file must be a mapping, not a list or scalar")
    return data


def _dotted_get(config: Dict[str, Any], dotted_path: str) -> Any:
    """Fetch 'dataset.load_type' style paths. Returns None when absent."""
    node: Any = config
    for part in dotted_path.split("."):
        if not isinstance(node, dict) or part not in node:
            return None
        node = node[part]
    return node


def _is_blank(value: Any) -> bool:
    """A field counts as 'not provided' when it is None or an empty string."""
    return value is None or (isinstance(value, str) and value.strip() == "")


def default_notebook_resolver(path: str) -> Optional[bool]:
    """
    Does this notebook exist?

    Returns True, False, or None when it cannot be determined — for example
    validating a config on a laptop for a path that only exists in the
    Databricks workspace. None means "no opinion", and produces a warning
    rather than an error, because refusing to validate off-cluster would make
    the validator useless outside Databricks.

    Databricks notebooks have no extension on the workspace path, so several
    forms are tried.
    """
    import os

    candidates = [path, f"{path}.py", f"/Workspace{path}", f"/Workspace{path}.py"]
    for candidate in candidates:
        if os.path.exists(candidate):
            return True

    # Only claim absence when the parent directory is visible. Otherwise we are
    # simply not on the machine that holds it.
    parent = os.path.dirname(path)
    for base in (parent, f"/Workspace{parent}"):
        if base and os.path.isdir(base):
            return False
    return None


# Swappable so tests do not depend on the filesystem.
NOTEBOOK_RESOLVER = default_notebook_resolver


def _walk_strings(node: Any, path: str = "") -> List[tuple]:
    """
    Yield every (dotted_path, string_value) pair in a nested config.

    Used to scan the whole document for leftover template placeholder text,
    wherever it happens to sit.
    """
    found: List[tuple] = []
    if isinstance(node, dict):
        for key, value in node.items():
            found.extend(_walk_strings(value, f"{path}.{key}" if path else str(key)))
    elif isinstance(node, list):
        for index, value in enumerate(node):
            found.extend(_walk_strings(value, f"{path}[{index}]"))
    elif isinstance(node, str):
        found.append((path, node))
    return found


def _check_type(value: Any, expected: str) -> bool:
    """True when `value` matches the schema type keyword `expected`."""
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "integer":
        # Reject bools here: `True` is an int in Python but not a valid integer field.
        return isinstance(value, int) and not isinstance(value, bool)
    python_type = _TYPE_MAP.get(expected)
    return isinstance(value, python_type) if python_type else True


def _validate_field(
    result: ValidationResult,
    location: str,
    field_name: str,
    spec: Dict[str, Any],
    container: Dict[str, Any],
) -> None:
    """Validate one field against its schema spec (presence, type, enum)."""
    label = f"{location}.{field_name}"
    present = field_name in container
    value = container.get(field_name)

    if spec.get("required", False) and (not present or _is_blank(value)):
        result.add_error(f"{label}: required but missing or empty")
        return

    if not present or _is_blank(value):
        return  # optional and not supplied — nothing further to check

    expected_type = spec.get("type")
    if expected_type and not _check_type(value, expected_type):
        actual = type(value).__name__
        result.add_error(f"{label}: expected {expected_type}, got {actual} ({value!r})")
        return

    allowed = spec.get("enum")
    if allowed and value not in allowed:
        shown = [a for a in allowed if a != ""]
        result.add_error(f"{label}: '{value}' is not allowed. Use one of: {shown}")


# =============================================================================
# Schema loading
# =============================================================================
def load_schema(config_version: str, schema_dir: Path | str = DEFAULT_SCHEMA_DIR) -> Dict[str, Any]:
    """
    Load the schema file matching `config_version`.

    Version "0.1" maps to file "pipeline_config_schema_v0_1.yaml".
    """
    schema_dir = Path(schema_dir)
    filename = f"pipeline_config_schema_v{config_version.replace('.', '_')}.yaml"
    schema_path = schema_dir / filename
    if not schema_path.exists():
        available = sorted(p.name for p in schema_dir.glob("pipeline_config_schema_v*.yaml"))
        raise FileNotFoundError(
            f"No schema for config_version '{config_version}'. "
            f"Expected {filename} in {schema_dir}. Available: {available or 'none'}"
        )
    return _load_yaml(schema_path)


# =============================================================================
# Validation stages
# =============================================================================
def _validate_sections(result: ValidationResult, config: Dict, schema: Dict) -> None:
    """Field-level checks for every declared section."""
    for section_name, section_spec in (schema.get("sections") or {}).items():
        if section_name not in config:
            continue  # absence already reported by the required-sections check

        section = config[section_name]
        kind = section_spec.get("kind", "mapping")

        if kind == "mapping":
            if not isinstance(section, dict):
                result.add_error(f"{section_name}: expected a block of fields")
                continue
            for field_name, spec in (section_spec.get("fields") or {}).items():
                _validate_field(result, section_name, field_name, spec, section)

        elif kind == "list":
            if not isinstance(section, list):
                result.add_error(f"{section_name}: expected a list")
                continue
            minimum = section_spec.get("min_items", 0)
            if len(section) < minimum:
                result.add_error(f"{section_name}: needs at least {minimum} entry/entries, found {len(section)}")
            for index, item in enumerate(section):
                if not isinstance(item, dict):
                    result.add_error(f"{section_name}[{index}]: expected a block of fields")
                    continue
                for field_name, spec in (section_spec.get("item_fields") or {}).items():
                    _validate_field(result, f"{section_name}[{index}]", field_name, spec, item)


def _validate_nested_lists(result: ValidationResult, config: Dict, schema: Dict) -> None:
    """Field-level checks for lists nested inside a mapping (e.g. quality.rules)."""
    for dotted_path, spec in (schema.get("nested_lists") or {}).items():
        items = _dotted_get(config, dotted_path)
        if items is None:
            if spec.get("required", False):
                result.add_error(f"{dotted_path}: required but missing")
            continue
        if not isinstance(items, list):
            result.add_error(f"{dotted_path}: expected a list")
            continue
        for index, item in enumerate(items):
            if not isinstance(item, dict):
                result.add_error(f"{dotted_path}[{index}]: expected a block of fields")
                continue
            for field_name, field_spec in (spec.get("item_fields") or {}).items():
                _validate_field(result, f"{dotted_path}[{index}]", field_name, field_spec, item)


def _validate_list_fields(result: ValidationResult, config: Dict, schema: Dict) -> None:
    """Fields that must be a YAML list rather than a scalar (e.g. primary_key)."""
    for dotted_path, spec in (schema.get("list_fields") or {}).items():
        value = _dotted_get(config, dotted_path)
        if value is None:
            if spec.get("required", False):
                result.add_error(f"{dotted_path}: required but missing")
            continue
        if not isinstance(value, list):
            result.add_error(
                f"{dotted_path}: must be a list. Write it as a YAML list "
                f"(- item) even when there is only one entry."
            )
            continue
        expected = spec.get("item_type")
        if expected:
            for index, item in enumerate(value):
                if not _check_type(item, expected):
                    result.add_error(
                        f"{dotted_path}[{index}]: expected {expected}, got {type(item).__name__}"
                    )


def _validate_free_form_mappings(result: ValidationResult, config: Dict, schema: Dict) -> None:
    """Blocks whose keys are user-defined: check the shape, not the key names."""
    for dotted_path in schema.get("free_form_mappings") or []:
        value = _dotted_get(config, dotted_path)
        if value is None:
            continue
        if not isinstance(value, dict):
            result.add_error(f"{dotted_path}: expected a block of key/value pairs")


def _validate_exactly_one_of(result: ValidationResult, config: Dict, schema: Dict) -> None:
    """Exactly one field in each group must be supplied."""
    for group in schema.get("exactly_one_of") or []:
        fields = group.get("fields", [])
        supplied = [f for f in fields if not _is_blank(_dotted_get(config, f))]
        name = group.get("name", " / ".join(fields))
        if len(supplied) == 0:
            result.add_error(f"{name}: supply one of {fields}")
        elif len(supplied) > 1:
            result.add_error(f"{name}: supply only one of {fields}, found {supplied}")


def _validate_conditionals(result: ValidationResult, config: Dict, schema: Dict) -> None:
    """Apply 'if X equals Y then Z is required' rules."""
    for rule in schema.get("conditional_rules") or []:
        when = rule.get("when", {})
        actual = _dotted_get(config, when.get("field", ""))
        if actual != when.get("equals"):
            continue

        reason = rule.get("name", "conditional rule")

        for required_path in rule.get("require", []):
            if _is_blank(_dotted_get(config, required_path)):
                result.add_error(f"{required_path}: required because {reason.lower()}")

        list_path = rule.get("require_list")
        if list_path:
            items = _dotted_get(config, list_path)
            if not items:
                result.add_error(f"{list_path}: required because {reason.lower()}")


def _validate_integrity(result: ValidationResult, config: Dict, schema: Dict) -> None:
    """Cross-field consistency checks."""
    for check in schema.get("integrity_checks") or []:
        kind = check.get("type")
        name = check.get("name", kind)

        if kind == "fields_must_match":
            left = _dotted_get(config, check["left"])
            right = _dotted_get(config, check["right"])
            if left is not None and right is not None and left != right:
                result.add_error(f"{check['left']} ('{left}') must match {check['right']} ('{right}')")

        elif kind == "list_has_active_item":
            items = _dotted_get(config, check["list"]) or []
            if isinstance(items, list) and not any(i.get("active") for i in items if isinstance(i, dict)):
                result.add_error(f"{check['list']}: {name}")

        elif kind == "list_has_flag":
            items = _dotted_get(config, check["list"]) or []
            flag = check["flag"]
            if isinstance(items, list) and not any(
                i.get(flag) for i in items if isinstance(i, dict) and i.get("active")
            ):
                result.add_error(f"{check['list']}: {name}")

        elif kind == "list_field_unique":
            items = _dotted_get(config, check["list"]) or []
            field_name = check["field"]
            seen, duplicates = set(), set()
            for item in items:
                if not isinstance(item, dict):
                    continue
                value = item.get(field_name)
                if value is None:
                    continue
                if value in seen:
                    duplicates.add(value)
                seen.add(value)
            if duplicates:
                result.add_error(
                    f"{check['list']}.{field_name}: duplicate value(s) {sorted(duplicates)} — must be unique"
                )

        elif kind == "three_part_name":
            value = _dotted_get(config, check["field"])
            if value and not _is_blank(value):
                parts = str(value).split(".")
                if len(parts) != 3 or not all(p.strip() for p in parts):
                    result.add_error(
                        f"{check['field']}: '{value}' must be a three-part name (catalog.schema.table)"
                    )

        elif kind == "forbidden_together":
            when = check.get("when", {})
            unless = check.get("unless") or {}
            applies = _dotted_get(config, when.get("field", "")) == when.get("equals")
            excused = (
                bool(unless)
                and _dotted_get(config, unless.get("field", "")) == unless.get("equals")
            )
            present = _dotted_get(config, check["forbid"])
            if applies and not excused and present:
                result.add_error(
                    f"{check['forbid']}: {name}. Either remove the {check['forbid']} section, "
                    f"or set dataset.on_empty_notebook: use_columns to declare that the "
                    f"columns are a deliberate fallback."
                )

        elif kind == "notebook_exists":
            when = check.get("when", {})
            if _dotted_get(config, when.get("field", "")) != when.get("equals"):
                continue
            path = _dotted_get(config, check["field"])
            if _is_blank(path):
                continue  # a conditional rule already reports the missing path
            verdict = NOTEBOOK_RESOLVER(str(path))
            if verdict is False:
                result.add_error(
                    f"{check['field']}: no notebook found at '{path}'. "
                    f"A path that points at nothing fails at run time, deep inside a job. "
                    f"Check the path, including whether it needs a /Workspace prefix."
                )
            elif verdict is None:
                result.add_warning(
                    f"{check['field']}: could not verify that '{path}' exists from here. "
                    f"It will be checked again at run time."
                )

        elif kind == "no_placeholder_values":
            markers = [m.lower() for m in check.get("markers", [])]
            for path, value in _walk_strings(config):
                lowered = value.lower()
                hit = next((m for m in markers if m in lowered), None)
                if hit:
                    result.add_error(
                        f"{path}: still contains template placeholder text ({value!r}). "
                        f"Fill this field in before deploying."
                    )


# What the runtime engine can actually execute today. The schema deliberately
# accepts more than this, so a config can be written ahead of the engine — but
# validation says so up front rather than letting the run fail halfway.
IMPLEMENTED = {
    "source.source_type": {"cloud_files", "delta_table"},
    "target.target_type": {"delta_table"},
    "dataset.load_type": {"FULL"},
    "dataset.column_mode": {"star", "explicit", "notebook"},
    "dataset.ingestion_method": {"autoloader", "delta_read"},
    "quality.engine": {"inline"},
}


def _warn_unimplemented(result: ValidationResult, config: Dict) -> None:
    """
    Flag choices the engine cannot run yet.

    A warning, not an error: the config is legal, and writing it ahead of the
    engine is reasonable. But finding out at validate time beats finding out
    when the writer raises partway through a run.
    """
    for dotted_path, supported in IMPLEMENTED.items():
        value = _dotted_get(config, dotted_path)
        if _is_blank(value):
            continue
        if value not in supported:
            result.add_warning(
                f"{dotted_path} = '{value}' is valid config but NOT IMPLEMENTED in v0.1. "
                f"The engine supports {sorted(supported)}. This config will validate and "
                f"load metadata, but the run will stop with a clear error."
            )


def _add_advisory_warnings(result: ValidationResult, config: Dict) -> None:
    """Non-blocking advice. These do not fail validation."""
    pipeline = config.get("pipeline") or {}
    source = config.get("source") or {}
    dataset = config.get("dataset") or {}
    quality = config.get("quality") or {}

    if pipeline.get("active") is False:
        result.add_warning("pipeline.active is false — this pipeline will be skipped at run time")
    if dataset.get("active") is False:
        result.add_warning("dataset.active is false — this dataset will be skipped at run time")

    mode = dataset.get("column_mode")

    if mode == "star" and dataset.get("exclude_etl_columns") is not True:
        result.add_warning(
            "dataset.column_mode is 'star' but exclude_etl_columns is not true — a "
            "table-to-table copy will inherit the upstream ETL audit columns and lose "
            "traceability. Set exclude_etl_columns: true unless you know otherwise."
        )

    if mode == "explicit" and not config.get("columns"):
        result.add_warning("column_mode is 'explicit' but no columns are listed")

    if mode != "explicit" and config.get("columns"):
        result.add_warning(
            f"a columns section is present but column_mode is '{mode}' — it will be ignored"
        )

    if mode == "notebook":
        result.add_warning(
            "column_mode is 'notebook' — v0.1 records the notebook reference only. "
            "The framework does not execute it yet."
        )

    if dataset.get("load_type") in ("CDC", "SNAPSHOT") and not dataset.get("primary_key"):
        result.add_warning(f"load_type {dataset.get('load_type')} normally needs a primary key")

    if quality.get("engine") == "inline":
        rules = quality.get("rules") or []
        inactive = [r for r in rules if isinstance(r, dict) and r.get("active") is False]
        if rules and len(inactive) == len(rules):
            result.add_warning("every inline quality rule is inactive — no checks will run")

    ref = str(source.get("connection_ref") or "")
    if any(token in ref.lower() for token in ("password=", "pwd=", "secret=", "apikey=")):
        result.add_warning(
            "source.connection_ref looks like it may contain a literal credential — "
            "use a Unity Catalog connection name or secret scope reference instead"
        )


# =============================================================================
# Public entry points
# =============================================================================
def validate_config(
    config: Dict[str, Any],
    config_path: str = "<in-memory>",
    schema_dir: Path | str = DEFAULT_SCHEMA_DIR,
) -> ValidationResult:
    """Validate an already-loaded config dict."""
    result = ValidationResult(config_path=config_path, config=config)

    # --- version gate -------------------------------------------------------
    config_version = config.get("config_version")
    if _is_blank(config_version):
        if "config_template_version" in config:
            result.add_error(
                "config_version: required but missing. This config uses "
                "'config_template_version' — rename that key to 'config_version'."
            )
        else:
            result.add_error("config_version: required but missing — copy a current template")
        return result

    config_version = str(config_version)
    result.config_version = config_version

    try:
        schema = load_schema(config_version, schema_dir)
    except FileNotFoundError as exc:
        result.add_error(str(exc))
        return result

    result.schema_version = schema.get("schema_version")

    supported = schema.get("supported_config_versions") or []
    if supported and config_version not in supported:
        result.add_error(
            f"config_version '{config_version}' is not supported by schema "
            f"v{result.schema_version}. Supported: {supported}"
        )
        return result

    # --- structure ----------------------------------------------------------
    for section in schema.get("required_sections") or []:
        if section not in config:
            result.add_error(f"missing required section: {section}")

    # --- fields, conditionals, integrity ------------------------------------
    _validate_sections(result, config, schema)
    _validate_list_fields(result, config, schema)
    _validate_free_form_mappings(result, config, schema)
    _validate_nested_lists(result, config, schema)
    _validate_exactly_one_of(result, config, schema)
    _validate_conditionals(result, config, schema)
    _validate_integrity(result, config, schema)
    _warn_unimplemented(result, config)
    _add_advisory_warnings(result, config)

    return result


def validate_config_file(
    config_path: Path | str,
    schema_dir: Path | str = DEFAULT_SCHEMA_DIR,
) -> ValidationResult:
    """Read a config file from disk and validate it."""
    config_path = Path(config_path)
    result = ValidationResult(config_path=str(config_path))

    if not config_path.exists():
        result.add_error(f"file not found: {config_path}")
        return result

    try:
        config = _load_yaml(config_path)
    except yaml.YAMLError as exc:
        result.add_error(f"YAML parse error: {exc}")
        return result
    except ValueError as exc:
        result.add_error(f"invalid config file: {exc}")
        return result

    return validate_config(config, config_path=str(config_path), schema_dir=schema_dir)
