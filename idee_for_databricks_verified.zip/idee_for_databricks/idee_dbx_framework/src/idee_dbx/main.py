"""
Command-line entry point for the iDEE Databricks framework.

This is the single command an application user runs. It wires the three stages
together and prints what happened at each step.

    validate  config -> is it legal?
    parse     config -> what metadata actions would it produce?
    load      config -> validate, parse, then apply to the metadata tables

Examples
--------
    python -m idee_dbx.main validate --config ../idee_dbx_app/config/customers_landing_to_bronze_config.yaml

    python -m idee_dbx.main parse    --config <config> --show-sql \\
        --catalog my_catalog --metadata-schema idee_metaschema

    python -m idee_dbx.main load     --config <config> \\
        --catalog my_catalog --metadata-schema idee_metaschema --dry-run

Exit codes: 0 = success, 1 = validation or load failure, 2 = bad invocation.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .config_parser import parse_config
from .config_validator import DEFAULT_SCHEMA_DIR, validate_config_file

_BAR = "=" * 78


def _banner(title: str) -> None:
    print(f"\n{_BAR}\n{title}\n{_BAR}")


def _run_validate(args: argparse.Namespace) -> int:
    _banner("STEP 1 — CONFIG VALIDATION")
    print(f"Framework version : {__version__}")
    print(f"Schema directory  : {args.schema_dir}\n")

    result = validate_config_file(args.config, schema_dir=args.schema_dir)
    print(result.report())

    if not result.is_valid:
        print("\nValidation failed. Fix the errors above and re-run.")
        return 1

    print("\nConfig schema validation passed.")
    return 0


def _run_parse(args: argparse.Namespace) -> int:
    exit_code = _run_validate(args)
    if exit_code != 0:
        return exit_code

    result = validate_config_file(args.config, schema_dir=args.schema_dir)

    _banner("STEP 2 — CONFIG PARSING")
    plan = parse_config(result.config, config_path=str(args.config))
    print(plan.summary())

    if args.show_sql:
        _banner("GENERATED MERGE STATEMENTS")
        for statement in plan.to_merge_statements(args.catalog, args.metadata_schema):
            print(statement)
            print()

    print("\nParser completed. Metadata action list generated.")
    return 0


def _run_load(args: argparse.Namespace) -> int:
    exit_code = _run_validate(args)
    if exit_code != 0:
        return exit_code

    result = validate_config_file(args.config, schema_dir=args.schema_dir)

    _banner("STEP 2 — CONFIG PARSING")
    plan = parse_config(result.config, config_path=str(args.config))
    print(plan.summary())

    _banner("STEP 3 — METADATA LOAD")
    from .metadata_loader import load_plan  # imported here so parse works without pyspark

    load_result = load_plan(
        plan,
        catalog=args.catalog,
        metadata_schema=args.metadata_schema,
        dry_run=args.dry_run,
    )
    print(load_result.report())

    if not load_result.succeeded:
        return 1

    print("\nLoad complete." if not args.dry_run else "\nDry run complete — nothing was written.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="idee_dbx",
        description="iDEE for Databricks — validate, parse, and load pipeline configs.",
    )
    parser.add_argument("--version", action="version", version=f"idee_dbx {__version__}")

    subparsers = parser.add_subparsers(dest="command", required=True)

    def add_common(sub: argparse.ArgumentParser) -> None:
        sub.add_argument("--config", required=True, type=Path, help="Path to the filled config YAML file")
        sub.add_argument(
            "--schema-dir",
            default=DEFAULT_SCHEMA_DIR,
            type=Path,
            help="Directory holding the versioned schema files",
        )

    validate_cmd = subparsers.add_parser("validate", help="Validate a config against its schema version")
    add_common(validate_cmd)
    validate_cmd.set_defaults(func=_run_validate)

    parse_cmd = subparsers.add_parser("parse", help="Validate then show the metadata actions produced")
    add_common(parse_cmd)
    parse_cmd.add_argument("--show-sql", action="store_true", help="Print the generated MERGE statements")
    parse_cmd.add_argument("--catalog", default="<catalog>", help="Catalog name used when rendering SQL")
    parse_cmd.add_argument("--metadata-schema", default="idee_metaschema", help="Metadata schema name")
    parse_cmd.set_defaults(func=_run_parse)

    load_cmd = subparsers.add_parser("load", help="Validate, parse, then write to the metadata tables")
    add_common(load_cmd)
    load_cmd.add_argument("--catalog", required=True, help="Unity Catalog name to load into")
    load_cmd.add_argument("--metadata-schema", default="idee_metaschema", help="Metadata schema name")
    load_cmd.add_argument("--dry-run", action="store_true", help="Show statements without executing them")
    load_cmd.set_defaults(func=_run_load)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
