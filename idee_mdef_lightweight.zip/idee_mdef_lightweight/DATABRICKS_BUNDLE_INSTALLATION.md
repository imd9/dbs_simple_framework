# Databricks Bundle Installation Guide

Deploy the iDEE MDEF framework using Databricks Asset Bundle (DAB) and VS Code.

---

## What Just Happened to Your `databricks.yml`

Your bundle now contains:

```
Bundle: scion-mdef-lightweight
  ├─ Variables (catalog, schema names)
  ├─ Targets (dev, qa, prod)
  ├─ Resources:
  │  ├─ Schemas (idee_metaschema, idee_app)
  │  ├─ Tables (5 metadata tables with full DDL)
  │  └─ Job (ELT pipeline with 3 tasks)
  └─ Deployment settings
```

**Key features:**

- ✅ Defaults to `medtech_md_scion_dev` catalog
- ✅ Creates metadata tables in `idee_metaschema`
- ✅ Expects data to live in `idee_app`
- ✅ Parameterized for dev/qa/prod
- ✅ Defines a 3-stage pipeline job

---

## Setup in 5 Steps

### Step 1: Install Databricks CLI

```bash
# Install Databricks CLI v0.20+
pip install databricks-cli

# Verify
databricks --version
# Output: databricks-cli 0.20.1
```

If you see an error, upgrade:
```bash
pip install --upgrade databricks-cli
```

---

### Step 2: Install VS Code Extension

1. Open VS Code
2. Go to **Extensions** (Ctrl+Shift+X)
3. Search for **Databricks**
4. Click **Install** on the official Databricks extension (by Databricks)

**Expected:** Blue icon appears in left sidebar

---

### Step 3: Authenticate VS Code to Your Workspace

1. In VS Code, click the **Databricks** icon (left sidebar)
2. Click **Configure Workspace**
3. Select **Add workspace configuration**
4. Enter:
   - **Workspace URL:** `https://adb-6956808850021109.9.azuredatabricks.net`
   - **Token:** [Get from Databricks](https://docs.databricks.com/dev-tools/auth#personal-access-tokens)
5. Click **Save**

**Expected:** Green checkmark appears next to workspace name

---

### Step 4: Validate Your Bundle

```bash
cd C:\Users\IDuran3\OneDrive - JNJ\Documents\JJT_2025\Scion

# Validate the bundle configuration
databricks bundle validate

# Expected output:
# Validating /path/to/Scion...
# ✓ Config: ok
# ✓ Resources: ok
# ✓ Variables: ok
# Bundle validation succeeded
```

If you see errors, fix them (see Troubleshooting below).

---

### Step 5: Deploy the Bundle

```bash
# Deploy to dev (default target)
databricks bundle deploy

# Expected output:
# Deploying /path/to/Scion...
# ✓ [dev] Schemas created
# ✓ [dev] Tables created (source_config, object_config, column_config, quality_rule_config, pipeline_audit)
# ✓ [dev] Job created: scion_mdef_pipeline_job
# Deploy succeeded
```

This creates:
- ✅ Schemas in your Databricks workspace
- ✅ 5 metadata tables with full DDL
- ✅ Job definition for the ELT pipeline

**No manual SQL needed — all automatic.**

---

## Verify Deployment

### In Databricks UI

1. Go to **Data** → **Catalogs**
2. Navigate to `medtech_md_scion_dev` → `idee_metaschema`
3. You should see 5 tables:
   - `source_config` (empty)
   - `object_config` (empty)
   - `column_config` (empty)
   - `quality_rule_config` (empty)
   - `pipeline_audit` (empty)

4. Go to **Workflows** → **Jobs**
5. You should see job: `SCION MDEF - ELT Pipeline`

### In Terminal

```bash
# List what was deployed
databricks bundle list

# Show summary
databricks bundle summary
```

---

## Update Your Config After Deployment

### To change environments (dev → qa → prod)

```bash
# Deploy to QA
databricks bundle deploy --target qa

# Deploy to production
databricks bundle deploy --target prod
```

### To update variable values

Edit `databricks.yml` and update the `variables` section:

```yaml
variables:
  catalog_name:
    default: medtech_md_scion_qa  # Changed from dev
  schema_metadata:
    default: idee_metaschema
```

Then redeploy:
```bash
databricks bundle deploy --target qa
```

### To add a new table

Add to the `tables` section in `databricks.yml`, then redeploy:

```yaml
resources:
  tables:
    your_new_table:
      schema_name: ${var.schema_metadata}
      catalog_name: ${var.catalog_name}
      name: your_new_table
      columns:
        - name: col1
          type: STRING
```

Redeploy:
```bash
databricks bundle deploy
```

---

## Using the Job

### Run manually from Databricks UI

1. Go to **Workflows** → **Jobs**
2. Click **SCION MDEF - ELT Pipeline**
3. Click **Run Now**
4. Watch the 3 tasks execute in order:
   - load_metadata
   - run_bronze_layer
   - run_silver_layer

### Run from terminal

```bash
# Run the job
databricks bundle run scion_mdef_pipeline_job

# Expected output:
# Running scion_mdef_pipeline_job...
# Task: load_metadata STARTED
# Task: load_metadata SUCCESS
# Task: run_bronze_layer STARTED
# Task: run_bronze_layer SUCCESS
# Task: run_silver_layer STARTED
# Task: run_silver_layer SUCCESS
```

### Run on schedule (already configured)

The job runs daily at 2 AM EST. To change:

Edit `databricks.yml`:

```yaml
schedule:
  quartz_cron_expression: "0 6 * * ?"  # Change to 6 AM
  timezone_id: America/New_York
```

Redeploy:
```bash
databricks bundle deploy
```

---

## Next: Load Your First Dataset

Once deployment succeeds, you're ready to onboard datasets.

### Option A: Load via Python Notebook (Quick Test)

1. Create Python notebook in Databricks
2. Copy code from `DATABRICKS_TESTING_GUIDE.md` STEP 4
3. Run the notebook
4. Your dataset config is now in the metadata tables

### Option B: Load via YAML + Loader (Production Ready)

1. Create `your_dataset.yaml` (copy template from `idee_config_template.yaml`)
2. Validate locally: `python dry_run_test.py your_dataset.yaml`
3. Deploy YAML to workspace (via Git + bundle)
4. Job loads it automatically

---

## File Structure Expected by Bundle

Your repo should have:

```
Scion/
├── databricks.yml                      ← Bundle config (just updated)
├── idee_mdef_lightweight/              ← Framework code
│   ├── README.md
│   ├── QUICKSTART.md
│   ├── DATABRICKS_TESTING_GUIDE.md
│   ├── idee_config_template.yaml
│   ├── dry_run_test.py
│   ├── validate_config.py
│   └── dq_rules/
│       └── example_object_id.yml
├── src/
│   ├── notebooks/                      ← Job task notebooks (to be created)
│   │   ├── load_metadata.py
│   │   ├── bronze_layer.py
│   │   └── silver_layer.py
│   └── sql/                            ← SQL scripts (optional)
│       ├── verify_metadata_tables.sql
│       └── list_active_datasets.sql
└── .databricks/                        ← Bundle state (auto-created)
    └── .bundle.lock.json
```

The job expects notebooks at `./src/notebooks/load_metadata`, etc. (Currently referenced but not created yet — we'll do that in Phase 6.)

---

## Troubleshooting

### Error: "Config: config not found"

**Cause:** You're not in the right directory

**Fix:**
```bash
cd C:\Users\IDuran3\OneDrive - JNJ\Documents\JJT_2025\Scion
databricks bundle validate
```

### Error: "Workspace not found"

**Cause:** Databricks CLI can't reach your workspace

**Fix:**
```bash
# Check if token is valid
databricks fs ls /

# If this fails, redo Step 3 (authenticate)
```

### Error: "Cannot create table: table_name already exists"

**Cause:** You ran deploy twice and tables already exist

**Fix:**
```bash
# Update to skip if exists (already in bundle config)
# Just redeploy — the bundle is idempotent
databricks bundle deploy
```

### Error: "Compute not available"

**Cause:** The node type `Standard_DS4_v2` doesn't exist in your region

**Fix:** Edit `databricks.yml` and change `node_type_id`:

```yaml
clusters:
  - cluster_name: scion_main_cluster
    spark_version: 14.3.x-scala2.12
    node_type_id: i3.xlarge  # Try this instead
```

Then redeploy.

### Error: "Schema idee_metaschema already exists"

**Cause:** Schema was created earlier

**Fix:** The bundle is designed to be idempotent — it's safe to run `bundle deploy` again. You can also delete and recreate:

```bash
# In Databricks UI
DROP SCHEMA medtech_md_scion_dev.idee_metaschema CASCADE;

# Then redeploy
databricks bundle deploy
```

---

## What's in Your Bundle vs What You Need to Build

### Already Deployed ✅

- Metadata table structure (5 tables with full DDL)
- Job definition (3-task pipeline)
- Variable substitution (dev/qa/prod)
- Deployment lock file (prevents conflicts)

### You Still Need to Create (Phase 6)

- Python/SQL notebooks at `./src/notebooks/`:
  - `load_metadata.py` — reads YAML configs, inserts to metadata tables
  - `bronze_layer.py` — Landing → Bronze with Auto Loader
  - `silver_layer.py` — Bronze → Silver with DQ, dedup, type casting
- SQL scripts at `./src/sql/`:
  - `verify_metadata_tables.sql`
  - `list_active_datasets.sql`

These are referenced in `databricks.yml` but don't exist yet. The job won't run until you create them.

---

## Development Workflow (Best Practice)

1. **Edit locally** in VS Code
2. **Validate** with `databricks bundle validate`
3. **Deploy** with `databricks bundle deploy`
4. **Test** in Databricks UI
5. **Iterate** by editing and redeploying

Example:

```bash
# Edit databricks.yml in VS Code
# → Add a new variable or change a table definition

# Validate
databricks bundle validate

# Deploy
databricks bundle deploy

# Check in Databricks UI
# → New table should appear
```

---

## Summary

| Step | Tool | Command | Result |
|---|---|---|---|
| 1 | pip | `pip install databricks-cli` | CLI installed |
| 2 | VS Code | Install Databricks ext | Extension ready |
| 3 | VS Code | Add workspace config | Authenticated |
| 4 | CLI | `databricks bundle validate` | Bundle valid |
| 5 | CLI | `databricks bundle deploy` | Metadata tables + Job created |

**Time to complete:** ~15 minutes

**Result:** Your framework is deployed. Metadata tables are ready. Job is ready to run (once you create the notebooks).

---

## Next Steps

1. ✅ Deploy bundle (you just did this)
2. Create the 3 notebooks (Phase 6)
3. Load a test dataset (DATABRICKS_TESTING_GUIDE.md)
4. Run the job
5. Verify results

For now, the metadata tables are empty and waiting. You're ready to load dataset configs!
