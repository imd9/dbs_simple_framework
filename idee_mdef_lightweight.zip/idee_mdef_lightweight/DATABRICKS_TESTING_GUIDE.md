# Databricks Testing Guide — Step by Step

This guide walks you through testing the iDEE MDEF framework in your Databricks workspace.

**Time to complete:** ~30 minutes

---

## Prerequisites

- Databricks workspace access (any workspace)
- A catalog (e.g., `main` or `uc_catalog`)
- A schema to create tables in (e.g., `metadata`)
- Python 3.8+ installed locally

---

## STEP 1: Create Test Dataset Config (Local)

Copy the template and fill in with test values:

```bash
# Copy template
cp idee_config_template.yaml test_sales_orders.yaml

# Edit in your favorite editor (VS Code, Notepad, etc.)
```

Fill in **test_sales_orders.yaml** with these values:

```yaml
source:
  source_id: "test_cloud_storage"
  source_name: "Test Cloud Storage - Sales"
  source_type: cloud_files
  ingestion_method: autoloader
  landing_required: true
  connection_ref: "abfss://data@yourstorageaccount.dfs.core.windows.net/landing"
  base_path: "/sales"
  active: true

dataset:
  object_id: "test_sales_orders"
  source_id: "test_cloud_storage"
  object_name: "Test Sales Orders"
  source_path: "/sales/orders"
  file_format: csv
  load_type: INCREMENTAL
  primary_key: "order_id"
  incremental_column: "updated_at"
  bronze_table: "main.metadata.test_sales_orders_bronze"
  active: true
  execution_order: 1
  parallel_group: ""

columns:
  - source_column: "ORDER_ID"
    target_column: "order_id"
    target_type: BIGINT
    primary_key_indicator: true
    trim_indicator: false
    pii_classification: PUBLIC
    nullable: false
    sequence: 1
    active: true

  - source_column: "CUSTOMER_ID"
    target_column: "customer_id"
    target_type: BIGINT
    primary_key_indicator: false
    trim_indicator: false
    pii_classification: PUBLIC
    nullable: false
    sequence: 2
    active: true

  - source_column: "ORDER_AMOUNT"
    target_column: "order_amount"
    target_type: DOUBLE
    primary_key_indicator: false
    trim_indicator: false
    pii_classification: PUBLIC
    nullable: false
    sequence: 3
    active: true

  - source_column: "UPDATED_AT"
    target_column: "updated_at"
    target_type: TIMESTAMP
    primary_key_indicator: false
    trim_indicator: false
    pii_classification: PUBLIC
    nullable: false
    sequence: 4
    active: true

quality:
  engine: native
  rules_path: "dq_rules/test_sales_orders.yml"
```

---

## STEP 2: Validate Locally (Dry Run)

```bash
cd "C:\Users\IDuran3\OneDrive - JNJ\Documents\JJT_2025\Scion\idee_mdef_lightweight"

python dry_run_test.py test_sales_orders.yaml
```

**Expected output:**
```
STEP 1: Schema validation...
  ✅ Schema valid

STEP 2: Parse YAML to metadata rows...
  ✅ 5 rows parsed:
    source_config: [...]
    object_config: [...]
    column_config: [...]
    column_config: [...]
    column_config: [...]

STEP 3: Referential integrity check...
  ✅ All foreign keys valid

STEP 4: Summary
  Ready to load? YES ✅
```

**If you see ✅ everywhere, proceed to STEP 3. If you see ❌, fix the YAML and retry.**

---

## STEP 3: Create Metadata Tables in Databricks (One Time)

### 3.1 Open a new SQL notebook in Databricks

1. Go to your Databricks workspace
2. Click **+ New** → **SQL Notebook**
3. Name it: `SETUP_Metadata_Tables`
4. Connect to any cluster

### 3.2 Run DDL to create tables

Paste this SQL into your notebook and run all cells:

```sql
-- Change this to your catalog and schema
-- Example: main.metadata or uc_catalog.framework
USE CATALOG main;
CREATE SCHEMA IF NOT EXISTS metadata;

-- ============================================================================
-- 1. SOURCE_CONFIG — where data comes from
-- ============================================================================
CREATE TABLE IF NOT EXISTS metadata.source_config (
  source_id STRING NOT NULL,
  source_name STRING NOT NULL,
  source_type STRING NOT NULL,
  ingestion_method STRING NOT NULL,
  landing_required BOOLEAN NOT NULL,
  connection_ref STRING NOT NULL,
  base_path STRING,
  active BOOLEAN NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- 2. OBJECT_CONFIG — the dataset
-- ============================================================================
CREATE TABLE IF NOT EXISTS metadata.object_config (
  object_id STRING NOT NULL,
  source_id STRING NOT NULL,
  object_name STRING NOT NULL,
  source_path STRING NOT NULL,
  file_format STRING,
  load_type STRING NOT NULL,
  primary_key STRING,
  incremental_column STRING,
  bronze_table STRING NOT NULL,
  active BOOLEAN NOT NULL,
  execution_order INT DEFAULT 0,
  parallel_group STRING,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- 3. COLUMN_CONFIG — column definitions
-- ============================================================================
CREATE TABLE IF NOT EXISTS metadata.column_config (
  object_id STRING NOT NULL,
  source_column STRING NOT NULL,
  target_column STRING NOT NULL,
  target_type STRING NOT NULL,
  primary_key_indicator BOOLEAN NOT NULL,
  trim_indicator BOOLEAN NOT NULL,
  pii_classification STRING NOT NULL,
  nullable BOOLEAN NOT NULL,
  sequence INT NOT NULL,
  active BOOLEAN NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- 4. QUALITY_RULE_CONFIG — DQ rules
-- ============================================================================
CREATE TABLE IF NOT EXISTS metadata.quality_rule_config (
  rule_id STRING NOT NULL,
  object_id STRING NOT NULL,
  rule_name STRING NOT NULL,
  rule_expression STRING NOT NULL,
  action STRING NOT NULL,
  severity STRING NOT NULL,
  active BOOLEAN NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- 5. PIPELINE_AUDIT — runtime log (created by framework)
-- ============================================================================
CREATE TABLE IF NOT EXISTS metadata.pipeline_audit (
  run_id STRING NOT NULL,
  object_id STRING NOT NULL,
  layer STRING NOT NULL,
  start_time TIMESTAMP NOT NULL,
  end_time TIMESTAMP,
  rows_read BIGINT,
  rows_written BIGINT,
  rows_rejected BIGINT,
  status STRING NOT NULL,
  error_message STRING,
  source_watermark STRING,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- Verify tables were created
-- ============================================================================
SELECT 'source_config' as table_name, COUNT(*) as row_count FROM metadata.source_config
UNION ALL
SELECT 'object_config' as table_name, COUNT(*) as row_count FROM metadata.object_config
UNION ALL
SELECT 'column_config' as table_name, COUNT(*) as row_count FROM metadata.column_config
UNION ALL
SELECT 'quality_rule_config' as table_name, COUNT(*) as row_count FROM metadata.quality_rule_config;
```

**Expected output:**
```
table_name          | row_count
--------------------|----------
source_config       | 0
object_config       | 0
column_config       | 0
quality_rule_config | 0
```

(All zeros = correct, tables are empty and ready)

---

## STEP 4: Insert Test Data into Databricks (Your Dataset)

### 4.1 Create Python notebook in Databricks

1. Click **+ New** → **Python Notebook**
2. Name it: `LOAD_Test_Dataset`
3. Connect to same cluster

### 4.2 Copy-paste this Python code into the notebook

```python
import yaml
from datetime import datetime

# ============================================================================
# PARSE YOUR YAML CONFIG
# ============================================================================

yaml_content = """
source:
  source_id: "test_cloud_storage"
  source_name: "Test Cloud Storage - Sales"
  source_type: cloud_files
  ingestion_method: autoloader
  landing_required: true
  connection_ref: "abfss://data@yourstorageaccount.dfs.core.windows.net/landing"
  base_path: "/sales"
  active: true

dataset:
  object_id: "test_sales_orders"
  source_id: "test_cloud_storage"
  object_name: "Test Sales Orders"
  source_path: "/sales/orders"
  file_format: csv
  load_type: INCREMENTAL
  primary_key: "order_id"
  incremental_column: "updated_at"
  bronze_table: "main.metadata.test_sales_orders_bronze"
  active: true
  execution_order: 1
  parallel_group: ""

columns:
  - source_column: "ORDER_ID"
    target_column: "order_id"
    target_type: BIGINT
    primary_key_indicator: true
    trim_indicator: false
    pii_classification: PUBLIC
    nullable: false
    sequence: 1
    active: true

  - source_column: "CUSTOMER_ID"
    target_column: "customer_id"
    target_type: BIGINT
    primary_key_indicator: false
    trim_indicator: false
    pii_classification: PUBLIC
    nullable: false
    sequence: 2
    active: true

  - source_column: "ORDER_AMOUNT"
    target_column: "order_amount"
    target_type: DOUBLE
    primary_key_indicator: false
    trim_indicator: false
    pii_classification: PUBLIC
    nullable: false
    sequence: 3
    active: true

  - source_column: "UPDATED_AT"
    target_column: "updated_at"
    target_type: TIMESTAMP
    primary_key_indicator: false
    trim_indicator: false
    pii_classification: PUBLIC
    nullable: false
    sequence: 4
    active: true

quality:
  engine: native
  rules_path: "dq_rules/test_sales_orders.yml"
"""

config = yaml.safe_load(yaml_content)

# ============================================================================
# INSERT INTO source_config
# ============================================================================

source_data = config['source']
spark.sql(f"""
INSERT INTO metadata.source_config 
  (source_id, source_name, source_type, ingestion_method, landing_required, connection_ref, base_path, active)
VALUES 
  ('{source_data['source_id']}', 
   '{source_data['source_name']}', 
   '{source_data['source_type']}', 
   '{source_data['ingestion_method']}', 
   {source_data['landing_required']}, 
   '{source_data['connection_ref']}', 
   '{source_data['base_path']}', 
   {source_data['active']})
""")
print("✅ Inserted into source_config")

# ============================================================================
# INSERT INTO object_config
# ============================================================================

dataset_data = config['dataset']
spark.sql(f"""
INSERT INTO metadata.object_config 
  (object_id, source_id, object_name, source_path, file_format, load_type, primary_key, incremental_column, bronze_table, active, execution_order, parallel_group)
VALUES 
  ('{dataset_data['object_id']}', 
   '{dataset_data['source_id']}', 
   '{dataset_data['object_name']}', 
   '{dataset_data['source_path']}', 
   '{dataset_data['file_format']}', 
   '{dataset_data['load_type']}', 
   '{dataset_data['primary_key']}', 
   '{dataset_data['incremental_column']}', 
   '{dataset_data['bronze_table']}', 
   {dataset_data['active']}, 
   {dataset_data['execution_order']}, 
   '{dataset_data['parallel_group']}')
""")
print("✅ Inserted into object_config")

# ============================================================================
# INSERT INTO column_config
# ============================================================================

for col in config['columns']:
    if col.get('active', True):
        spark.sql(f"""
INSERT INTO metadata.column_config 
  (object_id, source_column, target_column, target_type, primary_key_indicator, trim_indicator, pii_classification, nullable, sequence, active)
VALUES 
  ('{dataset_data['object_id']}', 
   '{col['source_column']}', 
   '{col['target_column']}', 
   '{col['target_type']}', 
   {col['primary_key_indicator']}, 
   {col['trim_indicator']}, 
   '{col['pii_classification']}', 
   {col['nullable']}, 
   {col['sequence']}, 
   {col['active']})
""")
print(f"✅ Inserted column: {col['target_column']}")

print("\n✅ All data loaded successfully!")
```

### 4.3 Run the notebook

1. Click **Run** (or Ctrl+Enter)
2. Watch the output

**Expected output:**
```
✅ Inserted into source_config
✅ Inserted into object_config
✅ Inserted column: order_id
✅ Inserted column: customer_id
✅ Inserted column: order_amount
✅ Inserted column: updated_at

✅ All data loaded successfully!
```

---

## STEP 5: Verify Data in Databricks

### 5.1 Create verification SQL notebook

Click **+ New** → **SQL Notebook**, name it `VERIFY_Data`, then run:

```sql
-- ============================================================================
-- Verify 1: Check source_config row
-- ============================================================================
SELECT * FROM metadata.source_config;

-- Expected: 1 row
-- source_id: test_cloud_storage
-- source_name: Test Cloud Storage - Sales
-- source_type: cloud_files

-- ============================================================================
-- Verify 2: Check object_config row
-- ============================================================================
SELECT * FROM metadata.object_config;

-- Expected: 1 row
-- object_id: test_sales_orders
-- source_id: test_cloud_storage
-- object_name: Test Sales Orders
-- load_type: INCREMENTAL

-- ============================================================================
-- Verify 3: Check column_config rows
-- ============================================================================
SELECT object_id, target_column, target_type, sequence 
FROM metadata.column_config 
ORDER BY sequence;

-- Expected: 4 rows
-- order_id          | BIGINT | 1
-- customer_id       | BIGINT | 2
-- order_amount      | DOUBLE | 3
-- updated_at        | TIMESTAMP | 4

-- ============================================================================
-- Verify 4: Check counts across all tables
-- ============================================================================
SELECT 'source_config' as table_name, COUNT(*) as row_count FROM metadata.source_config
UNION ALL
SELECT 'object_config' as table_name, COUNT(*) as row_count FROM metadata.object_config
UNION ALL
SELECT 'column_config' as table_name, COUNT(*) as row_count FROM metadata.column_config
UNION ALL
SELECT 'quality_rule_config' as table_name, COUNT(*) as row_count FROM metadata.quality_rule_config
ORDER BY table_name;

-- Expected:
-- column_config | 4
-- object_config | 1
-- quality_rule_config | 0
-- source_config | 1
```

**Expected output:** All queries should return data matching the comments above.

---

## STEP 6: Test with Another Dataset (Onboard Second Dataset)

Now test that the framework can handle multiple datasets:

### 6.1 Create second YAML (customer data)

Create **test_customers.yaml**:

```yaml
source:
  source_id: "test_cloud_storage"  # Same source as sales orders!
  source_name: "Test Cloud Storage - Sales"
  source_type: cloud_files
  ingestion_method: autoloader
  landing_required: true
  connection_ref: "abfss://data@yourstorageaccount.dfs.core.windows.net/landing"
  base_path: "/sales"
  active: true

dataset:
  object_id: "test_customers"
  source_id: "test_cloud_storage"
  object_name: "Test Customers"
  source_path: "/sales/customers"
  file_format: csv
  load_type: FULL
  primary_key: ""
  incremental_column: ""
  bronze_table: "main.metadata.test_customers_bronze"
  active: true
  execution_order: 0
  parallel_group: ""

columns:
  - source_column: "CUSTOMER_ID"
    target_column: "customer_id"
    target_type: BIGINT
    primary_key_indicator: true
    trim_indicator: false
    pii_classification: PUBLIC
    nullable: false
    sequence: 1
    active: true

  - source_column: "CUSTOMER_NAME"
    target_column: "customer_name"
    target_type: STRING
    primary_key_indicator: false
    trim_indicator: true
    pii_classification: SENSITIVE
    nullable: false
    sequence: 2
    active: true

quality:
  engine: inline
  rules:
    - rule_name: "Customer ID not null"
      rule_expression: "customer_id IS NOT NULL"
      action: fail
      severity: critical
      active: true
```

### 6.2 Dry test locally

```bash
python dry_run_test.py test_customers.yaml
```

### 6.3 Load into Databricks

Create new Python notebook, copy same code but swap the YAML config (replace `yaml_content` string with test_customers YAML above), and run.

### 6.4 Verify in SQL

```sql
SELECT COUNT(*) as total_datasets FROM metadata.object_config;
-- Expected: 2 (sales_orders and customers)

SELECT object_id, load_type FROM metadata.object_config ORDER BY object_id;
-- Expected:
-- test_customers | FULL
-- test_sales_orders | INCREMENTAL

SELECT COUNT(*) as total_columns FROM metadata.column_config;
-- Expected: 6 (4 from sales_orders + 2 from customers)
```

---

## Summary Checklist

- [ ] Created test_sales_orders.yaml with real values
- [ ] Ran dry_run_test.py locally and saw ✅ everywhere
- [ ] Opened Databricks workspace
- [ ] Created SQL notebook and ran DDL (5 tables created)
- [ ] Created Python notebook and ran INSERT code
- [ ] Verified data in SQL notebook (all queries returned correct rows)
- [ ] Created second dataset (test_customers.yaml)
- [ ] Loaded second dataset and verified 2 datasets in metadata tables

---

## Troubleshooting

**Error: "Table not found: metadata.source_config"**
→ Run the DDL from STEP 3 first

**Error: "Invalid table/column name"**
→ Check if you're using correct catalog.schema.table path (e.g., main.metadata.*)

**Error in Python notebook: "syntax error" or "invalid yaml"**
→ Paste the YAML carefully (whitespace matters); use triple quotes `"""`

**Query returns 0 rows when you expected data**
→ Check that Python notebook ran without errors; look for ✅ messages

---

## What Just Happened

You:
1. ✅ Created metadata table schema (DDL — one time)
2. ✅ Defined a dataset config as YAML
3. ✅ Validated locally with dry_run_test.py
4. ✅ Inserted that config into Databricks metadata tables (DML)
5. ✅ Queried the tables to verify

Your metadata tables now contain the **config** needed to run Bronze → Silver pipelines. The actual pipeline execution is Phase 6 (not covered here yet).

Next: Build and test the actual pipeline stages (landing → bronze, bronze → silver).
