# Design Notes — Lightweight iDEE MDEF Config Model

This document records **what** we built, **why**, and **how** — specifically the
decision to narrow the full iDEE reference model down to a compact, lightweight
configuration model, and the reconciliation of inconsistencies found across the
original documents.

Treat this as the decision log. It exists so these choices are not
re-litigated later.

---

## 1. Context: what we started with

The source material described the same platform at three levels of detail, and
they did not fully agree with one another:

- **The iDEE ERD** (conceptual / logical / physical) — a rich, normalized
  reference model of roughly 13 entities (Data Set, Data Element, Data Source,
  Connector Type, Connector Definition, Operator Connector Usage, Pipeline
  Definition, Pipeline Operator, Operator Type, Operator Dependency,
  Application, Compute, Data Definition).
- **The MDEF presentation** — a pragmatic six-table config model
  (`source_config`, `object_config`, `column_config`, `quality_rule_config`,
  `gold_model_config`, `pipeline_audit`).
- **The onboarding YAML** — a per-dataset config file whose field names did not
  match the table model, and whose data-quality section contradicted itself
  (it said rules live in a separate managed file, then listed rules inline).

The goal for this build: produce **one compact, internally consistent
lightweight model**, serialize it faithfully as a YAML template, and document
it.

---

## 2. What we built (the lightweight model)

Four configuration tables, plus one runtime audit table:

| Table | Grain | Origin in iDEE |
|---|---|---|
| `source_config` | one row per source system | Data Source, with Connector Type/Definition folded in as fields |
| `object_config` | one row per dataset | Data Set Definition |
| `column_config` | one row per column | Data Element Definition |
| `quality_rule_config` | one row per rule (inline engine) | iDEE Data Quality LOB concept |
| `pipeline_audit` | one row per (run, object, layer) | runtime-generated (not user config) |

The onboarding YAML serializes the four config tables: `source:` → one
`source_config` row, `dataset:` → one `object_config` row, `columns:` → many
`column_config` rows, `quality:` → the engine selector and (for the inline
engine) `quality_rule_config` rows.

---

## 3. Why we dropped what we dropped

The lightweight model is deliberately smaller than both the iDEE ERD and the
six-table MDEF model. Rationale, entity by entity:

### Dropped: the entire Operator subsystem
*(Operator, Operator Type, Pipeline Operator Definition, Operator Dependency
Definition, Operator Connector Usage Definition)*

In the iDEE model these entities encode the **pipeline task graph as data** —
which operators run, in what order, with what dependencies. In a
metadata-driven Databricks framework, **Lakeflow Jobs already provide
orchestration, sequencing, retries, and dependency handling**. Re-encoding that
as config rows duplicates the orchestrator and adds tables users would have to
populate for no functional gain. Execution order, where it matters, is captured
by two simple fields on `object_config` (`execution_order`, `parallel_group`)
rather than a normalized operator graph.

### Collapsed: Connector Type / Connector Definition
Folded into fields on `source_config` (`source_type`, `ingestion_method`,
`connection_ref`). At this scale, connectivity is a property of the source, not
a separate entity worth its own table and join.

### Dropped: Application, Compute, Data Definition
- **Application** (business/organizational boundary) is governance/ownership
  metadata — valuable, but not required to move data. Noted as a future
  first-class object rather than core config.
- **Compute** is an infrastructure concern handled by the Lakeflow Job /
  bundle configuration, not by dataset onboarding config.
- **Data Definition** (metadata catalog of tables/files/columns/JSON schema) is
  a catalog concern; Unity Catalog covers it in the Databricks runtime.

### Set aside: `gold_model_config`
Excluded from the core lightweight set by explicit decision. Gold business
logic lives in version-controlled SQL/Python files; the metadata only pointed
at them. Keeping the core to four config tables makes the "fill out one file to
onboard" story cleaner. Gold is listed as a future extension.

**Net result:** ~13 entities → 4 config tables. Compact, lightweight, and still
sufficient to drive a full Bronze → Silver pipeline with quality and audit.

---

## 4. How we reconciled the inconsistencies

### 4.1 Field naming: YAML keys now equal table columns
The original YAML and the table spec used different names for the same field.
Resolved by making **the YAML key identical to the target table column** so the
loader needs no translation layer.

| Old YAML key | Now (matches table column) |
|---|---|
| `root_path` | `base_path` |
| `primary_key` *(in a column)* | `primary_key_indicator` |
| `trim` | `trim_indicator` |
| `pii` | `pii_classification` |

We also added the config fields the table model had but the YAML omitted:
`active` (on source, dataset, and column), `nullable` and `sequence` (on
column), and `execution_order` / `parallel_group` (on dataset).

### 4.2 Data quality: made pluggable, user chooses the engine
The original file both claimed rules live in a separate managed file **and**
listed rules inline. Rather than pick one and lose a capability, we made data
quality an explicit choice via `quality.engine`:

- **`native`** *(default)* — rules read from a separate, engineering-managed
  rules folder, referenced by `rules_path` (default convention:
  `dq_rules/{object_id}.yml`). Users point at rules; they do not author them
  inline. This preserves the "simple user configs, no accidental breakage"
  intent.
- **`great_expectations`** — the framework builds and runs a GX expectation
  suite inside Databricks, named by `suite_name`. This satisfies the
  requirement to optionally use Great Expectations within Databricks.
- **`inline`** — a few rules defined directly in the file (`rules`), mapping to
  `quality_rule_config` rows. Kept for quick starts and small datasets.

The contradiction is resolved because both behaviors are now legitimate,
explicitly selected options rather than an accident.

---

## 5. What this is used for

A data engineer onboarding a new source does not build a pipeline. They:

1. Copy the YAML template.
2. Describe the source, the dataset, and the columns.
3. Choose a data quality engine.
4. Submit.

The framework's single reusable engine reads the resulting metadata and runs
the dataset through Bronze, Silver, quality checks, quarantine, and audit —
identically to every other dataset. Adding datasets scales by adding config,
not by adding code.

---

## 6. Deliberately out of scope (future work)

- `gold_model_config` and the Gold layer.
- Governance/ownership as a first-class object (the dropped **Application**
  concept).
- Loader, metadata validation, and generator implementation code.
- A schema-drift handling policy (currently only surfaced as an alert signal in
  the source material).

These are recorded here so their absence is understood as a choice, not an
oversight.
