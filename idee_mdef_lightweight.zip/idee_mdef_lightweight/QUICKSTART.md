# iDEE MDEF Lightweight Framework — Quick Start

**Welcome!** This is a metadata-driven ELT framework for Databricks.
You fill out one YAML file per dataset. The pipeline does the rest.

---

## How It Works

```
You fill out:   dataset_configs/my_dataset.yaml
                    ↓
Pipeline reads it automatically on next run
                    ↓
Inserts rows into metadata tables
                    ↓
Runs Bronze → Silver for that dataset
```

**You never write pipeline code. You never touch databricks.yml.**
One file per dataset. That's it.

---

## The Pipeline (3 tasks, runs in order)

```
load_configs  →  run_bronze  →  run_silver
```

| Task | What it does |
|---|---|
| `load_configs` | Reads all `.yaml` files in `dataset_configs/`, validates them, upserts rows into metadata tables |
| `run_bronze` | Ingests raw data into Bronze for every active dataset (Auto Loader) |
| `run_silver` | Cleans, type-casts, deduplicates, applies DQ rules, writes to Silver |

---

## Who Does What

| Role | File(s) they touch | How often |
|---|---|---|
| **Framework engineer** | `databricks.yml` | Once per environment |
| **Data engineer** | `dataset_configs/my_dataset.yaml` | Once per dataset |

Framework engineers set up the infrastructure and never touch it again.
Data engineers only ever interact with YAML config files.

---

## Path A: Framework Engineer — First Time Setup (~20 min)

```
1. Install Databricks CLI:  pip install databricks-cli
   ↓
2. Authenticate VS Code to your workspace (Databricks extension)
   ↓
3. Validate bundle:  databricks bundle validate
   ↓
4. Deploy:          databricks bundle deploy
   ↓
5. Run install job: databricks bundle run install_once
   ↓
✅ Done — schemas and 5 metadata tables now exist in Databricks
```

After this, the framework is ready. Data engineers can start onboarding datasets.

---

## Path B: Data Engineer — Onboard a Dataset (~10 min)

```
1. Copy template:  cp dataset_configs/template.yaml dataset_configs/my_dataset.yaml
   ↓
2. Fill it out     (every [REQUIRED] field must have a real value)
   ↓
3. Validate:       python idee_mdef_lightweight/dry_run_test.py dataset_configs/my_dataset.yaml
   → Expect: ✅ "Ready to load? YES"
   ↓
4. Save the file   — the pipeline picks it up on next run automatically
   ↓
✅ Done — no code change, no deploy, no manual SQL
```

---

## Path C: Run the Pipeline Manually

```bash
# Run full pipeline (load configs + bronze + silver)
databricks bundle run scion_pipeline

# Or trigger from Databricks UI:
# Workflows → [SCION] ELT Pipeline - Bronze to Silver → Run Now
```

---

## File Map

```
Scion/
├── databricks.yml                    ← Infrastructure (framework engineer, set once)
├── dataset_configs/
│   ├── template.yaml                 ← THE template to copy for each dataset
│   ├── sales_orders.yaml             ← (example: filled-out dataset config)
│   └── customers.yaml                ← (example: another dataset)
└── idee_mdef_lightweight/
    ├── QUICKSTART.md                 ← You are here
    ├── README.md                     ← Framework overview
    ├── DESIGN_NOTES.md               ← Architecture decisions
    ├── DATABRICKS_BUNDLE_INSTALLATION.md  ← Full deploy guide (framework engineer)
    ├── dry_run_test.py               ← Local validation (data engineer)
    ├── validate_config.py            ← YAML schema checker
    └── dq_rules/
        └── example_object_id.yml    ← DQ rules template (native engine)
```

---

## Checklists

### Framework Engineer — First Time Setup
- [ ] Databricks CLI installed (`pip install databricks-cli`)
- [ ] VS Code Databricks extension installed and authenticated
- [ ] `databricks bundle validate` passes
- [ ] `databricks bundle deploy` succeeds
- [ ] `databricks bundle run install_once` succeeds
- [ ] Verified 5 tables exist in `medtech_md_scion_dev.idee_metaschema`

### Data Engineer — Onboarding a Dataset
- [ ] Copied `dataset_configs/template.yaml` to a new file
- [ ] Filled in all `[REQUIRED]` fields
- [ ] Ran `dry_run_test.py` locally and saw ✅
- [ ] Saved file to `dataset_configs/`
- [ ] Triggered pipeline run (or waited for schedule)
- [ ] Verified rows appeared in metadata tables

---

## Common Questions

**Q: What does the pipeline read?**
→ Every `.yaml` file in the `dataset_configs/` folder.

**Q: How do I add a new dataset?**
→ Copy `dataset_configs/template.yaml`, fill it out, save it. Done.

**Q: Do I need to redeploy the bundle when I add a new dataset?**
→ No. The pipeline reads the YAML files at runtime. No deploy needed.

**Q: How do I deactivate a dataset temporarily?**
→ Set `dataset.active: false` in the YAML file. The pipeline skips it on next run.

**Q: Can two datasets share the same source?**
→ Yes. Use the same `source_id` in both files. Connection is defined once.

**Q: What if my YAML validation fails locally?**
→ The error message tells you exactly what's wrong. Fix the YAML and re-run `dry_run_test.py`.

**Q: Where do Bronze and Silver tables get created?**
→ In `medtech_md_scion_dev.idee_app`. The `bronze_table` field in your YAML config defines the exact table name.

---

## Need More Detail?

| I want to... | Read... |
|---|---|
| Deploy the framework infrastructure | `DATABRICKS_BUNDLE_INSTALLATION.md` |
| Understand the metadata model | `README.md` |
| Understand why it was designed this way | `DESIGN_NOTES.md` |
| Test my YAML file locally before saving | Run `dry_run_test.py` |
| Write native DQ rules | `dq_rules/example_object_id.yml` |
