# iDEE Lightweight Metadata-Driven ELT Framework (MDEF)

A reusable, configuration-driven ELT framework for Databricks. One engine
processes any number of datasets from any source. Behavior is controlled by
metadata, not by custom code. **Onboarding a new dataset means filling out one
YAML file — not writing a new pipeline.**

This is the *lightweight* build: a simplified, compact subset of the full iDEE
data model, narrowed down to the minimum needed to drive a real
Bronze → Silver → Gold pipeline. See `DESIGN_NOTES.md` for what was simplified
and why.

---

## What it does

```
Source system  ->  Bronze (raw)  ->  Silver (clean/typed/validated)  ->  Gold
```

- **Bronze** — raw ingested data, near-source fidelity, append-only.
- **Silver** — renamed, type-cast, trimmed, deduplicated, and quality-checked.
- **Quarantine** — rows that fail quality rules, tagged with the reason.
- **Gold** — business models (handled by version-controlled SQL/Python, not by
  this config; out of scope for the lightweight core).

---

## The metadata model

The lightweight model is **four configuration tables** plus **one runtime audit
table**. Everything a dataset needs is described by config; the audit table is
written by the framework at run time.

| Table | Grain | Answers |
|---|---|---|
| `source_config` | one row per source system | Where does data come from, and how do we connect? |
| `object_config` | one row per dataset | Which dataset, and how is it loaded? |
| `column_config` | one row per column | What should each column look like after cleaning? |
| `quality_rule_config` | one row per rule (inline engine) | What makes a record valid? |
| `pipeline_audit` | one row per (run, object, layer) | What happened, when, how many rows? |

A single onboarding YAML file maps directly onto the first four:

```
source:   ->  source_config          (1 row)
dataset:  ->  object_config          (1 row)
columns:  ->  column_config          (N rows)
quality:  ->  quality_rule_config    (N rows, when engine = inline)
```

Every YAML key is named **exactly** after its target table column, so the
loader maps keys to columns with no translation.

---

## Onboarding a dataset

1. Copy `idee_config_template.yaml` to a new file for your dataset.
2. Fill in the `source`, `dataset`, and `columns` blocks. Every field is
   commented with its meaning and allowed values.
3. Choose a data quality engine in the `quality` block (see below).
4. Submit the file. The next framework run discovers and processes the dataset.

No code changes. No new notebook. No new job task. Configuration only.

### Required fields by load type

| `load_type` | Additional required fields |
|---|---|
| `FULL` | none |
| `INCREMENTAL` | `incremental_column` |
| `CDC` | `primary_key` |
| `SNAPSHOT` | `primary_key` |

---

## Data quality: choose your engine

Quality is **pluggable**. Set `quality.engine` to pick how this dataset is
validated:

| `engine` | Where rules live | Requires | Use when |
|---|---|---|---|
| `native` *(default)* | A separate, engineering-managed rules folder, referenced by path | `rules_path` | You want centralized, reusable rule packs and simple user configs |
| `great_expectations` | A GX expectation suite built and run inside Databricks | `suite_name` | You want GX's native validation and reporting |
| `inline` | Defined directly in the YAML file | `rules` | Quick starts or datasets with only a few checks |

The default `native` convention is one rules file per dataset:
`dq_rules/{object_id}.yml`. Users point at the file; they do not hand-author
rules. This keeps user configs simple and prevents accidental pipeline breakage.

**Quality rule actions:** `warn` (log only), `drop` (remove failing rows),
`quarantine` (route failing rows to a quarantine table), `fail` (stop the run).

---

## Source types supported

| `source_type` | `ingestion_method` | Notes |
|---|---|---|
| `cloud_files` | `autoloader` | Cloud file ingestion, incremental + schema-evolving |
| `jdbc` | `jdbc` | Relational sources (Oracle, SQL Server, etc.) |
| `lakeflow_connect` | `lakeflow_connect` | Managed Databricks connectors |
| `kafka` | `kafka` | Streaming ingestion |
| `api` | `api` | REST/API sources |

---

## Repository layout

```
.
├── idee_config_template.yaml   # Per-dataset onboarding config (copy this)
├── README.md                   # This file
├── DESIGN_NOTES.md             # What/why/how: the simplification decisions
└── dq_rules/                   # Engineering-managed native DQ rule packs
    └── {object_id}.yml         #   one rules file per dataset (native engine)
```

---

## Conventions and rules

- **IDs are stable.** `source_id` and `object_id` are unique and must never be
  reused or recycled — downstream rows and audit history key off them.
- **Never store secrets in config.** `connection_ref` holds a UC connection
  name or secret-scope reference, never a raw password or key.
- **Keys are not renamed.** The loader maps YAML keys to table columns by name.
- **Empty means N/A.** Leave a field as `""` when it does not apply (e.g.
  `base_path` for a non-file source).

---

## Next steps (not included in this lightweight build)

- `gold_model_config` for business aggregations (Gold layer).
- Governance/ownership metadata as a first-class object.
- Loader, validation, and generator implementation code.

These are intentionally out of scope for the compact core. See `DESIGN_NOTES.md`.
