# Testing & Validation Guide for iDEE MDEF Lightweight Framework

## Overview
This guide covers how to:
1. **Validate** YAML config files for schema correctness
2. **Parse** configs into metadata table rows
3. **Dry-run** the framework without executing against Databricks
4. **Test** individual components end-to-end

---

## Phase 1: YAML Schema Validation (Local)

### 1.1 Validate single config file

Create a Python validation script:

```python
import yaml
from pathlib import Path

def validate_config_file(yaml_path):
    """Validate a single dataset config against the lightweight model."""
    with open(yaml_path) as f:
        config = yaml.safe_load(f)
    
    errors = []
    
    # Check required top-level sections
    for section in ['source', 'dataset', 'columns', 'quality']:
        if section not in config:
            errors.append(f"Missing required section: {section}")
    
    # Validate source block
    src = config.get('source', {})
    required_source = ['source_id', 'source_name', 'source_type', 'ingestion_method', 'landing_required', 'connection_ref']
    for field in required_source:
        if not src.get(field):
            errors.append(f"source.{field}: required but missing or empty")
    
    # Validate source_type and ingestion_method enum
    valid_types = ['cloud_files', 'jdbc', 'lakeflow_connect', 'kafka', 'api']
    if src.get('source_type') not in valid_types:
        errors.append(f"source.source_type: '{src.get('source_type')}' not in {valid_types}")
    
    valid_methods = ['autoloader', 'jdbc', 'lakeflow_connect', 'kafka', 'api']
    if src.get('ingestion_method') not in valid_methods:
        errors.append(f"source.ingestion_method: '{src.get('ingestion_method')}' not in {valid_methods}")
    
    # Validate dataset block
    ds = config.get('dataset', {})
    required_dataset = ['object_id', 'source_id', 'object_name', 'source_path', 'load_type', 'bronze_table', 'active']
    for field in required_dataset:
        if not ds.get(field):
            errors.append(f"dataset.{field}: required but missing or empty")
    
    # Validate load_type and cross-field requirements
    load_type = ds.get('load_type', '')
    if load_type not in ['FULL', 'INCREMENTAL', 'CDC', 'SNAPSHOT']:
        errors.append(f"dataset.load_type: '{load_type}' not in ['FULL', 'INCREMENTAL', 'CDC', 'SNAPSHOT']")
    
    if load_type == 'INCREMENTAL' and not ds.get('incremental_column'):
        errors.append(f"dataset: load_type=INCREMENTAL requires incremental_column")
    
    if load_type in ['CDC', 'SNAPSHOT'] and not ds.get('primary_key'):
        errors.append(f"dataset: load_type={load_type} requires primary_key")
    
    # Check source_id matches
    if ds.get('source_id') != src.get('source_id'):
        errors.append(f"dataset.source_id ('{ds.get('source_id')}') does not match source.source_id ('{src.get('source_id')}')")
    
    # Validate columns block
    cols = config.get('columns', [])
    if not isinstance(cols, list) or len(cols) == 0:
        errors.append("columns: must be a non-empty list")
    
    for i, col in enumerate(cols):
        required_col = ['source_column', 'target_column', 'target_type', 'primary_key_indicator', 'trim_indicator', 'pii_classification', 'nullable', 'sequence', 'active']
        for field in required_col:
            if field not in col:
                errors.append(f"columns[{i}]: missing required field '{field}'")
        
        valid_types = ['STRING', 'BIGINT', 'DOUBLE', 'TIMESTAMP', 'DATE', 'BOOLEAN']
        if col.get('target_type') not in valid_types:
            errors.append(f"columns[{i}].target_type: '{col.get('target_type')}' not in {valid_types}")
        
        valid_pii = ['PII', 'SENSITIVE', 'PUBLIC']
        if col.get('pii_classification') not in valid_pii:
            errors.append(f"columns[{i}].pii_classification: '{col.get('pii_classification')}' not in {valid_pii}")
    
    # Validate quality block
    qual = config.get('quality', {})
    engine = qual.get('engine')
    if engine not in ['native', 'great_expectations', 'inline']:
        errors.append(f"quality.engine: '{engine}' not in ['native', 'great_expectations', 'inline']")
    
    if engine == 'native' and not qual.get('rules_path'):
        errors.append("quality: engine=native requires rules_path")
    
    if engine == 'great_expectations' and not qual.get('suite_name'):
        errors.append("quality: engine=great_expectations requires suite_name")
    
    if engine == 'inline':
        rules = qual.get('rules', [])
        if not isinstance(rules, list):
            errors.append("quality: engine=inline requires 'rules' to be a list")
        for j, rule in enumerate(rules):
            if 'rule_name' not in rule or 'rule_expression' not in rule:
                errors.append(f"quality.rules[{j}]: missing rule_name or rule_expression")
    
    return errors

if __name__ == '__main__':
    config_file = input("Enter path to config YAML: ")
    errors = validate_config_file(config_file)
    if errors:
        print(f"\n❌ VALIDATION FAILED ({len(errors)} errors):\n")
        for e in errors:
            print(f"  - {e}")
    else:
        print("\n✓ VALIDATION PASSED")
```

**Run it:**
```bash
python validate_config.py
# Enter path to config YAML: idee_config_template.yaml
```

### 1.2 Validate all configs in a directory

```python
from pathlib import Path
import glob

config_dir = "."  # or path to your config directory
for yaml_file in glob.glob(f"{config_dir}/**/*.yaml", recursive=True):
    errors = validate_config_file(yaml_file)
    status = "✓" if not errors else "✗"
    print(f"{status} {yaml_file}")
    if errors:
        for e in errors[:3]:  # Show first 3 errors
            print(f"    - {e}")
```

---

## Phase 2: Parsing Validation (Convert YAML → Table Rows)

### 2.1 Parse single config into metadata rows

```python
import yaml

def parse_config_to_rows(yaml_path):
    """Parse a config YAML into metadata table rows (dictionaries)."""
    with open(yaml_path) as f:
        config = yaml.safe_load(f)
    
    # source_config row (1 row)
    source_row = {
        'table': 'source_config',
        'row': config['source']
    }
    
    # object_config row (1 row)
    ds = config['dataset']
    object_row = {
        'table': 'object_config',
        'row': {k: v for k, v in ds.items() if k not in ['silver_table']}
        # (silver_table is Silver layer, not core onboarding)
    }
    
    # column_config rows (N rows)
    column_rows = []
    for col in config['columns']:
        col_row = {k: v for k, v in col.items()}  # Pass through as-is
        col_row['object_id'] = ds['object_id']     # Add FK
        column_rows.append({
            'table': 'column_config',
            'row': col_row
        })
    
    # quality_rule_config rows (N rows, only if engine='inline')
    quality_rows = []
    if config['quality'].get('engine') == 'inline':
        for rule in config['quality'].get('rules', []):
            rule_row = {k: v for k, v in rule.items()}
            rule_row['object_id'] = ds['object_id']
            rule_row['rule_id'] = f"{ds['object_id']}_{rule['rule_name'].replace(' ', '_').lower()}"
            quality_rows.append({
                'table': 'quality_rule_config',
                'row': rule_row
            })
    
    return [source_row, object_row] + [{'table': 'column_config', 'row': r} for r in column_rows] + quality_rows

if __name__ == '__main__':
    yaml_file = input("Enter path to config YAML: ")
    rows = parse_config_to_rows(yaml_file)
    
    print(f"\n📋 Parsed {len(rows)} metadata rows:\n")
    for item in rows:
        print(f"TABLE: {item['table']}")
        print(f"  {item['row']}")
        print()
```

**Output (dry-run):**
```
TABLE: source_config
  {'source_id': 'vendor_files', 'source_name': 'Vendor Sales Files', ...}

TABLE: object_config
  {'object_id': 'sales_orders', 'source_id': 'vendor_files', ...}

TABLE: column_config
  {'source_column': 'order_id', 'target_column': 'order_id', ...}

TABLE: column_config
  {'source_column': 'order_date', 'target_column': 'order_date', ...}
```

---

## Phase 3: Referential Integrity Validation

```python
def validate_referential_integrity(rows_list):
    """Check that all foreign keys point to valid primary keys."""
    errors = []
    
    # Build lookup of all source_ids and object_ids
    source_ids = set()
    object_ids = set()
    
    for item in rows_list:
        if item['table'] == 'source_config':
            source_ids.add(item['row'].get('source_id'))
        if item['table'] == 'object_config':
            object_ids.add(item['row'].get('object_id'))
    
    # Check all FKs
    for item in rows_list:
        if item['table'] == 'object_config':
            fk_source_id = item['row'].get('source_id')
            if fk_source_id not in source_ids:
                errors.append(f"object_config.source_id '{fk_source_id}' not found in source_config")
        
        if item['table'] in ['column_config', 'quality_rule_config']:
            fk_object_id = item['row'].get('object_id')
            if fk_object_id not in object_ids:
                errors.append(f"{item['table']}.object_id '{fk_object_id}' not found in object_config")
    
    return errors

# Usage:
errors = validate_referential_integrity(rows)
if errors:
    print(f"\n❌ Referential integrity errors:\n")
    for e in errors:
        print(f"  - {e}")
else:
    print("\n✓ All foreign keys valid")
```

---

## Phase 4: End-to-End Dry-Run (No Databricks)

### 4.1 Simulate the parsing + loading flow

```python
def dry_run(yaml_file):
    """Full dry-run: validate → parse → check referential integrity → display."""
    print(f"\n{'='*70}")
    print(f"DRY RUN: {yaml_file}")
    print(f"{'='*70}\n")
    
    # Step 1: Validate schema
    print("STEP 1: Schema validation...")
    errors = validate_config_file(yaml_file)
    if errors:
        print(f"  ❌ {len(errors)} errors found:")
        for e in errors:
            print(f"    - {e}")
        return False
    print("  ✓ Schema valid\n")
    
    # Step 2: Parse to rows
    print("STEP 2: Parse YAML to metadata rows...")
    rows = parse_config_to_rows(yaml_file)
    print(f"  ✓ {len(rows)} rows parsed:\n")
    for item in rows:
        print(f"    {item['table']}: {list(item['row'].keys())}")
    print()
    
    # Step 3: Check referential integrity
    print("STEP 3: Referential integrity check...")
    ri_errors = validate_referential_integrity(rows)
    if ri_errors:
        print(f"  ❌ {len(ri_errors)} errors found:")
        for e in ri_errors:
            print(f"    - {e}")
        return False
    print("  ✓ All foreign keys valid\n")
    
    # Step 4: Summary
    print("STEP 4: Summary")
    print(f"  Ready to load? YES ✓\n")
    print(f"  When executed in Databricks, this config will:")
    print(f"    1. Create/update {len([r for r in rows if r['table'] == 'source_config'])} source(s)")
    print(f"    2. Onboard {len([r for r in rows if r['table'] == 'object_config'])} dataset(s)")
    print(f"    3. Define {len([r for r in rows if r['table'] == 'column_config'])} column(s)")
    print(f"    4. Register {len([r for r in rows if r['table'] == 'quality_rule_config'])} quality rule(s)")
    print()
    return True

# Usage:
if __name__ == '__main__':
    yaml_file = input("Enter config YAML path: ")
    success = dry_run(yaml_file)
    exit(0 if success else 1)
```

---

## Phase 5: Test Against Databricks (Real Test)

### 5.1 Create DDLs for metadata tables

Run this **once per workspace**:

```sql
-- Create metadata tables in Databricks

CREATE TABLE IF NOT EXISTS metadata.source_config (
  source_id STRING NOT NULL,
  source_name STRING NOT NULL,
  source_type STRING NOT NULL,  -- cloud_files | jdbc | lakeflow_connect | kafka | api
  ingestion_method STRING NOT NULL,
  landing_required BOOLEAN NOT NULL,
  connection_ref STRING NOT NULL,
  base_path STRING,
  active BOOLEAN NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS metadata.object_config (
  object_id STRING NOT NULL,
  source_id STRING NOT NULL,
  object_name STRING NOT NULL,
  source_path STRING NOT NULL,
  file_format STRING,
  load_type STRING NOT NULL,  -- FULL | INCREMENTAL | CDC | SNAPSHOT
  primary_key STRING,
  incremental_column STRING,
  bronze_table STRING NOT NULL,
  active BOOLEAN NOT NULL,
  execution_order INT DEFAULT 0,
  parallel_group STRING,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_source FOREIGN KEY (source_id) REFERENCES metadata.source_config(source_id)
);

CREATE TABLE IF NOT EXISTS metadata.column_config (
  object_id STRING NOT NULL,
  source_column STRING NOT NULL,
  target_column STRING NOT NULL,
  target_type STRING NOT NULL,  -- STRING | BIGINT | DOUBLE | TIMESTAMP | DATE | BOOLEAN
  primary_key_indicator BOOLEAN NOT NULL,
  trim_indicator BOOLEAN NOT NULL,
  pii_classification STRING NOT NULL,  -- PII | SENSITIVE | PUBLIC
  nullable BOOLEAN NOT NULL,
  sequence INT NOT NULL,
  active BOOLEAN NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_object FOREIGN KEY (object_id) REFERENCES metadata.object_config(object_id)
);

CREATE TABLE IF NOT EXISTS metadata.quality_rule_config (
  rule_id STRING NOT NULL,
  object_id STRING NOT NULL,
  rule_name STRING NOT NULL,
  rule_expression STRING NOT NULL,
  action STRING NOT NULL,  -- warn | drop | quarantine | fail
  severity STRING NOT NULL,  -- informational | warning | error | critical
  active BOOLEAN NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_object FOREIGN KEY (object_id) REFERENCES metadata.object_config(object_id)
);

CREATE TABLE IF NOT EXISTS metadata.pipeline_audit (
  run_id STRING NOT NULL,
  object_id STRING NOT NULL,
  layer STRING NOT NULL,  -- landing | bronze | silver
  start_time TIMESTAMP NOT NULL,
  end_time TIMESTAMP,
  rows_read BIGINT,
  rows_written BIGINT,
  rows_rejected BIGINT,
  status STRING NOT NULL,  -- STARTED | SUCCESS | FAILED | SKIPPED
  error_message STRING,
  source_watermark STRING,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 5.2 Insert parsed rows

Once you've validated locally, insert to Databricks:

```python
from databricks.sql import sql

def insert_parsed_rows(spark, rows, dry_run=True):
    """Insert parsed rows into Databricks metadata tables."""
    for item in rows:
        table = item['table']
        row = item['row']
        
        # Build INSERT statement
        columns = ', '.join(row.keys())
        values = ', '.join([f"'{v}'" if isinstance(v, str) else str(v) for v in row.values()])
        stmt = f"INSERT INTO metadata.{table} ({columns}) VALUES ({values})"
        
        if dry_run:
            print(f"[DRY RUN] {stmt}\n")
        else:
            spark.sql(stmt)
            print(f"✓ Inserted into {table}")

# Usage
from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()

rows = parse_config_to_rows("idee_config_template.yaml")
insert_parsed_rows(spark, rows, dry_run=True)   # First dry run
insert_parsed_rows(spark, rows, dry_run=False)  # Then live
```

---

## Quick Test Checklist

- [ ] **Schema validation** — all YAML fields have correct types/enums
- [ ] **Referential integrity** — all FKs point to valid PKs
- [ ] **Dry-run parsing** — YAML → metadata rows without errors
- [ ] **Databricks DDLs** — metadata tables exist
- [ ] **Insert test** — sample rows insert without conflicts
- [ ] **Query validation** — can query back what was inserted

---

## Files in this repo

- `idee_config_template.yaml` — copy this and fill it out for each dataset
- `dq_rules/example_object_id.yml` — template for native DQ rules
- `README.md` — onboarding guide
- `DESIGN_NOTES.md` — why this model was built this way
