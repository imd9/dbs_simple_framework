import yaml
from pathlib import Path
import sys
import json

def validate_config_file(yaml_path):
    """Validate a single dataset config against the lightweight model."""
    try:
        with open(yaml_path) as f:
            config = yaml.safe_load(f)
    except FileNotFoundError:
        return [f"File not found: {yaml_path}"]
    except yaml.YAMLError as e:
        return [f"YAML parse error: {e}"]
    
    errors = []
    
    # Check required top-level sections
    for section in ['source', 'dataset', 'columns', 'quality']:
        if section not in config:
            errors.append(f"Missing required section: {section}")
    
    # Validate source block
    src = config.get('source', {})
    required_source = ['source_id', 'source_name', 'source_type', 'ingestion_method', 'landing_required', 'connection_ref']
    for field in required_source:
        if not src.get(field):
            errors.append(f"source.{field}: required but missing or empty")
    
    # Validate source_type and ingestion_method enum
    valid_types = ['cloud_files', 'jdbc', 'lakeflow_connect', 'kafka', 'api']
    if src.get('source_type') and src.get('source_type') not in valid_types:
        errors.append(f"source.source_type: '{src.get('source_type')}' not in {valid_types}")
    
    valid_methods = ['autoloader', 'jdbc', 'lakeflow_connect', 'kafka', 'api']
    if src.get('ingestion_method') and src.get('ingestion_method') not in valid_methods:
        errors.append(f"source.ingestion_method: '{src.get('ingestion_method')}' not in {valid_methods}")
    
    # Validate dataset block
    ds = config.get('dataset', {})
    required_dataset = ['object_id', 'source_id', 'object_name', 'source_path', 'load_type', 'bronze_table', 'active']
    for field in required_dataset:
        if ds.get(field) is None or (isinstance(ds.get(field), str) and not ds.get(field)):
            errors.append(f"dataset.{field}: required but missing or empty")
    
    # Validate load_type and cross-field requirements
    load_type = ds.get('load_type', '')
    if load_type and load_type not in ['FULL', 'INCREMENTAL', 'CDC', 'SNAPSHOT']:
        errors.append(f"dataset.load_type: '{load_type}' not in ['FULL', 'INCREMENTAL', 'CDC', 'SNAPSHOT']")
    
    if load_type == 'INCREMENTAL' and not ds.get('incremental_column'):
        errors.append(f"dataset: load_type=INCREMENTAL requires incremental_column")
    
    if load_type in ['CDC', 'SNAPSHOT'] and not ds.get('primary_key'):
        errors.append(f"dataset: load_type={load_type} requires primary_key")
    
    # Check source_id matches
    if ds.get('source_id') and src.get('source_id') and ds.get('source_id') != src.get('source_id'):
        errors.append(f"dataset.source_id ('{ds.get('source_id')}') does not match source.source_id ('{src.get('source_id')}')")
    
    # Validate columns block
    cols = config.get('columns', [])
    if not isinstance(cols, list) or len(cols) == 0:
        errors.append("columns: must be a non-empty list")
    else:
        for i, col in enumerate(cols):
            required_col = ['source_column', 'target_column', 'target_type', 'primary_key_indicator', 'trim_indicator', 'pii_classification', 'nullable', 'sequence', 'active']
            for field in required_col:
                if field not in col:
                    errors.append(f"columns[{i}]: missing required field '{field}'")
            
            valid_types = ['STRING', 'BIGINT', 'DOUBLE', 'TIMESTAMP', 'DATE', 'BOOLEAN']
            if col.get('target_type') and col.get('target_type') not in valid_types:
                errors.append(f"columns[{i}].target_type: '{col.get('target_type')}' not in {valid_types}")
            
            valid_pii = ['PII', 'SENSITIVE', 'PUBLIC']
            if col.get('pii_classification') and col.get('pii_classification') not in valid_pii:
                errors.append(f"columns[{i}].pii_classification: '{col.get('pii_classification')}' not in {valid_pii}")
    
    # Validate quality block
    qual = config.get('quality', {})
    engine = qual.get('engine')
    if engine and engine not in ['native', 'great_expectations', 'inline']:
        errors.append(f"quality.engine: '{engine}' not in ['native', 'great_expectations', 'inline']")
    
    if engine == 'native' and not qual.get('rules_path'):
        errors.append("quality: engine=native requires rules_path")
    
    if engine == 'great_expectations' and not qual.get('suite_name'):
        errors.append("quality: engine=great_expectations requires suite_name")
    
    if engine == 'inline':
        rules = qual.get('rules', [])
        if not isinstance(rules, list):
            errors.append("quality: engine=inline requires 'rules' to be a list")
        else:
            for j, rule in enumerate(rules):
                if 'rule_name' not in rule or 'rule_expression' not in rule:
                    errors.append(f"quality.rules[{j}]: missing rule_name or rule_expression")
    
    return errors


def parse_config_to_rows(yaml_path):
    """Parse a config YAML into metadata table rows (dictionaries)."""
    with open(yaml_path) as f:
        config = yaml.safe_load(f)
    
    rows = []
    
    # source_config row (1 row)
    source_row = {
        'table': 'source_config',
        'row': config['source']
    }
    rows.append(source_row)
    
    # object_config row (1 row)
    ds = config['dataset']
    object_row = {
        'table': 'object_config',
        'row': {k: v for k, v in ds.items() if k != 'silver_table'}
    }
    rows.append(object_row)
    
    # column_config rows (N rows)
    for col in config['columns']:
        if col.get('active', True):  # Only include active columns
            col_row = {k: v for k, v in col.items()}
            col_row['object_id'] = ds['object_id']
            rows.append({
                'table': 'column_config',
                'row': col_row
            })
    
    # quality_rule_config rows (N rows, only if engine='inline')
    if config['quality'].get('engine') == 'inline':
        for rule in config['quality'].get('rules', []):
            if rule.get('active', True):
                rule_row = {k: v for k, v in rule.items()}
                rule_row['object_id'] = ds['object_id']
                rule_row['rule_id'] = f"{ds['object_id']}_{rule['rule_name'].replace(' ', '_').replace('/', '_').lower()}"
                rows.append({
                    'table': 'quality_rule_config',
                    'row': rule_row
                })
    
    return rows


def validate_referential_integrity(rows_list):
    """Check that all foreign keys point to valid primary keys."""
    errors = []
    
    # Build lookup of all source_ids and object_ids
    source_ids = set()
    object_ids = set()
    
    for item in rows_list:
        if item['table'] == 'source_config':
            source_ids.add(item['row'].get('source_id'))
        if item['table'] == 'object_config':
            object_ids.add(item['row'].get('object_id'))
    
    # Check all FKs
    for item in rows_list:
        if item['table'] == 'object_config':
            fk_source_id = item['row'].get('source_id')
            if fk_source_id not in source_ids:
                errors.append(f"object_config.source_id '{fk_source_id}' not found in source_config")
        
        if item['table'] in ['column_config', 'quality_rule_config']:
            fk_object_id = item['row'].get('object_id')
            if fk_object_id not in object_ids:
                errors.append(f"{item['table']}.object_id '{fk_object_id}' not found in object_config")
    
    return errors


def dry_run(yaml_file):
    """Full dry-run: validate → parse → check referential integrity → display."""
    print(f"\n{'='*70}")
    print(f"DRY RUN: {yaml_file}")
    print(f"{'='*70}\n")
    
    # Step 1: Validate schema
    print("STEP 1: Schema validation...")
    errors = validate_config_file(yaml_file)
    if errors:
        print(f"  ❌ {len(errors)} errors found:")
        for e in errors:
            print(f"    - {e}")
        return False
    print("  ✅ Schema valid\n")
    
    # Step 2: Parse to rows
    print("STEP 2: Parse YAML to metadata rows...")
    rows = parse_config_to_rows(yaml_file)
    print(f"  ✅ {len(rows)} rows parsed:\n")
    for item in rows:
        cols = list(item['row'].keys())
        print(f"    {item['table']}: {cols}")
    print()
    
    # Step 3: Check referential integrity
    print("STEP 3: Referential integrity check...")
    ri_errors = validate_referential_integrity(rows)
    if ri_errors:
        print(f"  ❌ {len(ri_errors)} errors found:")
        for e in ri_errors:
            print(f"    - {e}")
        return False
    print("  ✅ All foreign keys valid\n")
    
    # Step 4: Summary
    print("STEP 4: Summary")
    print(f"  Ready to load? YES ✅\n")
    print(f"  When executed in Databricks, this config will:")
    print(f"    1. Create/update {len([r for r in rows if r['table'] == 'source_config'])} source(s)")
    print(f"    2. Onboard {len([r for r in rows if r['table'] == 'object_config'])} dataset(s)")
    print(f"    3. Define {len([r for r in rows if r['table'] == 'column_config'])} column(s)")
    print(f"    4. Register {len([r for r in rows if r['table'] == 'quality_rule_config'])} quality rule(s)")
    
    print(f"\n  Sample row details:")
    for item in rows[:3]:  # Show first 3 rows
        print(f"\n    {item['table']}:")
        for k, v in list(item['row'].items())[:5]:  # Show first 5 fields
            print(f"      {k}: {v}")
        if len(item['row']) > 5:
            print(f"      ... and {len(item['row']) - 5} more fields")
    
    print()
    return True

if __name__ == '__main__':
    if len(sys.argv) > 1:
        yaml_file = sys.argv[1]
    else:
        yaml_file = input("Enter config YAML path: ").strip()
    
    success = dry_run(yaml_file)
    sys.exit(0 if success else 1)
