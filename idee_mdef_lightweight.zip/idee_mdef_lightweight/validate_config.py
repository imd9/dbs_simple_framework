import yaml
from pathlib import Path
import sys

def validate_config_file(yaml_path):
    """Validate a single dataset config against the lightweight model."""
    try:
        with open(yaml_path) as f:
            config = yaml.safe_load(f)
    except FileNotFoundError:
        return [f"File not found: {yaml_path}"]
    except yaml.YAMLError as e:
        return [f"YAML parse error: {e}"]
    
    errors = []
    
    # Check required top-level sections
    for section in ['source', 'dataset', 'columns', 'quality']:
        if section not in config:
            errors.append(f"Missing required section: {section}")
    
    # Validate source block
    src = config.get('source', {})
    required_source = ['source_id', 'source_name', 'source_type', 'ingestion_method', 'landing_required', 'connection_ref']
    for field in required_source:
        if not src.get(field):
            errors.append(f"source.{field}: required but missing or empty")
    
    # Validate source_type and ingestion_method enum
    valid_types = ['cloud_files', 'jdbc', 'lakeflow_connect', 'kafka', 'api']
    if src.get('source_type') and src.get('source_type') not in valid_types:
        errors.append(f"source.source_type: '{src.get('source_type')}' not in {valid_types}")
    
    valid_methods = ['autoloader', 'jdbc', 'lakeflow_connect', 'kafka', 'api']
    if src.get('ingestion_method') and src.get('ingestion_method') not in valid_methods:
        errors.append(f"source.ingestion_method: '{src.get('ingestion_method')}' not in {valid_methods}")
    
    # Validate dataset block
    ds = config.get('dataset', {})
    required_dataset = ['object_id', 'source_id', 'object_name', 'source_path', 'load_type', 'bronze_table', 'active']
    for field in required_dataset:
        if ds.get(field) is None or (isinstance(ds.get(field), str) and not ds.get(field)):
            errors.append(f"dataset.{field}: required but missing or empty")
    
    # Validate load_type and cross-field requirements
    load_type = ds.get('load_type', '')
    if load_type and load_type not in ['FULL', 'INCREMENTAL', 'CDC', 'SNAPSHOT']:
        errors.append(f"dataset.load_type: '{load_type}' not in ['FULL', 'INCREMENTAL', 'CDC', 'SNAPSHOT']")
    
    if load_type == 'INCREMENTAL' and not ds.get('incremental_column'):
        errors.append(f"dataset: load_type=INCREMENTAL requires incremental_column")
    
    if load_type in ['CDC', 'SNAPSHOT'] and not ds.get('primary_key'):
        errors.append(f"dataset: load_type={load_type} requires primary_key")
    
    # Check source_id matches
    if ds.get('source_id') and src.get('source_id') and ds.get('source_id') != src.get('source_id'):
        errors.append(f"dataset.source_id ('{ds.get('source_id')}') does not match source.source_id ('{src.get('source_id')}')")
    
    # Validate columns block
    cols = config.get('columns', [])
    if not isinstance(cols, list) or len(cols) == 0:
        errors.append("columns: must be a non-empty list")
    else:
        for i, col in enumerate(cols):
            required_col = ['source_column', 'target_column', 'target_type', 'primary_key_indicator', 'trim_indicator', 'pii_classification', 'nullable', 'sequence', 'active']
            for field in required_col:
                if field not in col:
                    errors.append(f"columns[{i}]: missing required field '{field}'")
            
            valid_types = ['STRING', 'BIGINT', 'DOUBLE', 'TIMESTAMP', 'DATE', 'BOOLEAN']
            if col.get('target_type') and col.get('target_type') not in valid_types:
                errors.append(f"columns[{i}].target_type: '{col.get('target_type')}' not in {valid_types}")
            
            valid_pii = ['PII', 'SENSITIVE', 'PUBLIC']
            if col.get('pii_classification') and col.get('pii_classification') not in valid_pii:
                errors.append(f"columns[{i}].pii_classification: '{col.get('pii_classification')}' not in {valid_pii}")
    
    # Validate quality block
    qual = config.get('quality', {})
    engine = qual.get('engine')
    if engine and engine not in ['native', 'great_expectations', 'inline']:
        errors.append(f"quality.engine: '{engine}' not in ['native', 'great_expectations', 'inline']")
    
    if engine == 'native' and not qual.get('rules_path'):
        errors.append("quality: engine=native requires rules_path")
    
    if engine == 'great_expectations' and not qual.get('suite_name'):
        errors.append("quality: engine=great_expectations requires suite_name")
    
    if engine == 'inline':
        rules = qual.get('rules', [])
        if not isinstance(rules, list):
            errors.append("quality: engine=inline requires 'rules' to be a list")
        else:
            for j, rule in enumerate(rules):
                if 'rule_name' not in rule or 'rule_expression' not in rule:
                    errors.append(f"quality.rules[{j}]: missing rule_name or rule_expression")
    
    return errors

if __name__ == '__main__':
    if len(sys.argv) > 1:
        config_file = sys.argv[1]
    else:
        config_file = input("Enter path to config YAML: ").strip()
    
    errors = validate_config_file(config_file)
    if errors:
        print(f"\n❌ VALIDATION FAILED ({len(errors)} errors):\n")
        for e in errors:
            print(f"  - {e}")
        sys.exit(1)
    else:
        print("\n✅ VALIDATION PASSED")
        sys.exit(0)
